import { suggestArticles } from "@/server/repo/content";
import { resolveLocale } from "@/i18n";
import { handleError, json } from "@/server/http";

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const q = (url.searchParams.get("q") ?? "").slice(0, 80);
    const locale = resolveLocale(url.searchParams.get("locale"));
    const results = suggestArticles(locale, q, 6);
    return json({ ok: true, results });
  } catch (err) {
    return handleError(err);
  }
}
