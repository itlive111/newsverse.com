export const locales = ["uz", "en", "ru"] as const;
export type Locale = (typeof locales)[number];
export const defaultLocale: Locale = "uz";

export const localeNames: Record<Locale, string> = {
  uz: "O‘zbekcha",
  en: "English",
  ru: "Русский",
};

/** BCP-47 tags used for Intl formatting and <html lang>. */
export const localeTags: Record<Locale, string> = {
  uz: "uz-UZ",
  en: "en-GB",
  ru: "ru-RU",
};

export const localeFlags: Record<Locale, string> = { uz: "UZ", en: "EN", ru: "RU" };

export function isLocale(value: string | undefined | null): value is Locale {
  return !!value && (locales as readonly string[]).includes(value);
}

export function resolveLocale(value: string | undefined | null): Locale {
  return isLocale(value) ? value : defaultLocale;
}

type Entry = { uz: string; en: string; ru: string };

/**
 * Single source of truth for every UI string. Keeping all three languages on
 * the same row makes missing translations impossible to overlook.
 */
export const strings = {
  "brand.tagline": {
    uz: "Dunyodagi eng so‘nggi yangiliklar bir joyda!",
    en: "The world’s latest news, all in one place.",
    ru: "Самые свежие новости мира — в одном месте!",
  },
  "nav.home": { uz: "Bosh sahifa", en: "Home", ru: "Главная" },
  "nav.latest": { uz: "So‘nggi", en: "Latest", ru: "Последние" },
  "nav.trending": { uz: "Trendda", en: "Trending", ru: "В тренде" },
  "nav.search": { uz: "Qidiruv", en: "Search", ru: "Поиск" },
  "nav.bookmarks": { uz: "Saqlangan", en: "Saved", ru: "Сохранённые" },
  "nav.account": { uz: "Profil", en: "Account", ru: "Аккаунт" },
  "nav.admin": { uz: "Boshqaruv", en: "Admin", ru: "Админка" },
  "nav.login": { uz: "Kirish", en: "Sign in", ru: "Войти" },
  "nav.register": { uz: "Ro‘yxatdan o‘tish", en: "Sign up", ru: "Регистрация" },
  "nav.logout": { uz: "Chiqish", en: "Sign out", ru: "Выйти" },
  "nav.menu": { uz: "Menyu", en: "Menu", ru: "Меню" },
  "nav.categories": { uz: "Kategoriyalar", en: "Categories", ru: "Категории" },
  "nav.language": { uz: "Til", en: "Language", ru: "Язык" },
  "nav.theme": { uz: "Mavzu", en: "Theme", ru: "Тема" },

  "home.breaking": { uz: "Shoshilinch", en: "Breaking", ru: "Срочно" },
  "home.live": { uz: "JONLI", en: "LIVE", ru: "LIVE" },
  "home.featured": { uz: "Asosiy yangiliklar", en: "Top stories", ru: "Главные новости" },
  "home.latest": { uz: "So‘nggi yangiliklar", en: "Latest news", ru: "Последние новости" },
  "home.trending": { uz: "Trenddagi mavzular", en: "Trending now", ru: "Сейчас в тренде" },
  "home.mostRead": { uz: "Eng ko‘p o‘qilgan", en: "Most read", ru: "Самые читаемые" },
  "home.day": { uz: "Kun", en: "Day", ru: "День" },
  "home.week": { uz: "Hafta", en: "Week", ru: "Неделя" },
  "home.month": { uz: "Oy", en: "Month", ru: "Месяц" },
  "home.picks": { uz: "Muharrir tanlovi", en: "Editor’s picks", ru: "Выбор редакции" },
  "home.recommended": { uz: "Sizga tavsiya etamiz", en: "Recommended for you", ru: "Рекомендуем вам" },
  "home.local": { uz: "O‘zbekiston", en: "Uzbekistan", ru: "Узбекистан" },
  "home.world": { uz: "Dunyo", en: "World", ru: "Мир" },
  "home.video": { uz: "Video yangiliklar", en: "Video news", ru: "Видеоновости" },
  "home.tags": { uz: "Mashhur teglar", en: "Popular tags", ru: "Популярные теги" },
  "home.updated": { uz: "Yangilangan yangiliklar", en: "Recently updated", ru: "Недавно обновлённые" },
  "home.loadMore": { uz: "Yana yuklash", en: "Load more", ru: "Загрузить ещё" },
  "home.noMore": { uz: "Boshqa yangilik yo‘q", en: "No more stories", ru: "Больше новостей нет" },
  "home.personalizedHint": {
    uz: "Qiziqishlaringizga mos yangiliklar",
    en: "Matched to your interests",
    ru: "Подобрано по вашим интересам",
  },

  "widget.weather": { uz: "Ob-havo", en: "Weather", ru: "Погода" },
  "widget.markets": { uz: "Bozorlar", en: "Markets", ru: "Рынки" },
  "widget.sport": { uz: "Sport", en: "Sport", ru: "Спорт" },
  "widget.unavailable": {
    uz: "Ma’lumot manbasi sozlanmagan",
    en: "Data source not configured",
    ru: "Источник данных не настроен",
  },
  "widget.tashkent": { uz: "Toshkent", en: "Tashkent", ru: "Ташкент" },

  "newsletter.title": { uz: "Kunning muhim yangiliklari", en: "The day’s essential stories", ru: "Главное за день" },
  "newsletter.desc": {
    uz: "Har kuni ertalab tanlangan yangiliklar pochtangizda.",
    en: "A curated briefing in your inbox every morning.",
    ru: "Подборка главных новостей каждое утро на почте.",
  },
  "newsletter.placeholder": { uz: "Elektron pochta", en: "Email address", ru: "Электронная почта" },
  "newsletter.cta": { uz: "Obuna bo‘lish", en: "Subscribe", ru: "Подписаться" },
  "newsletter.ok": {
    uz: "Rahmat! Obunangiz qayd etildi.",
    en: "Thanks! Your subscription was recorded.",
    ru: "Спасибо! Подписка оформлена.",
  },
  "newsletter.invalid": { uz: "To‘g‘ri email kiriting.", en: "Enter a valid email.", ru: "Введите корректный email." },
  "newsletter.privacy": {
    uz: "Istalgan vaqtda obunadan chiqishingiz mumkin.",
    en: "You can unsubscribe at any time.",
    ru: "Вы можете отписаться в любое время.",
  },

  "common.readMore": { uz: "Batafsil", en: "Read more", ru: "Читать далее" },
  "common.minRead": { uz: "daqiqa o‘qish", en: "min read", ru: "мин чтения" },
  "common.published": { uz: "E’lon qilindi", en: "Published", ru: "Опубликовано" },
  "common.updated": { uz: "Yangilandi", en: "Updated", ru: "Обновлено" },
  "common.source": { uz: "Manba", en: "Source", ru: "Источник" },
  "common.original": { uz: "Asl manba", en: "Original report", ru: "Оригинал" },
  "common.aiSummary": { uz: "AI xulosasi", en: "AI summary", ru: "AI-резюме" },
  "common.aiTranslated": { uz: "AI tarjimasi", en: "AI translation", ru: "AI-перевод" },
  "common.unverifiedTranslation": {
    uz: "Mashina tarjimasi — inson tekshiruvi yo‘q",
    en: "Machine translation — not human-verified",
    ru: "Машинный перевод — без проверки человеком",
  },
  "common.onlyOriginal": {
    uz: "Bu tilga tarjima mavjud emas. Asl til ko‘rsatilmoqda.",
    en: "No translation for this language. Showing the original.",
    ru: "Перевода на этот язык нет. Показан оригинал.",
  },
  "common.demo": { uz: "Namuna", en: "Demo", ru: "Демо" },
  "common.loading": { uz: "Yuklanmoqda…", en: "Loading…", ru: "Загрузка…" },
  "common.error": { uz: "Xatolik yuz berdi", en: "Something went wrong", ru: "Произошла ошибка" },
  "common.retry": { uz: "Qayta urinish", en: "Try again", ru: "Повторить" },
  "common.save": { uz: "Saqlash", en: "Save", ru: "Сохранить" },
  "common.cancel": { uz: "Bekor qilish", en: "Cancel", ru: "Отмена" },
  "common.delete": { uz: "O‘chirish", en: "Delete", ru: "Удалить" },
  "common.edit": { uz: "Tahrirlash", en: "Edit", ru: "Изменить" },
  "common.view": { uz: "Ko‘rish", en: "View", ru: "Просмотр" },
  "common.all": { uz: "Barchasi", en: "All", ru: "Все" },
  "common.back": { uz: "Orqaga", en: "Back", ru: "Назад" },
  "common.next": { uz: "Keyingi", en: "Next", ru: "Далее" },
  "common.prev": { uz: "Oldingi", en: "Previous", ru: "Назад" },
  "common.of": { uz: "dan", en: "of", ru: "из" },
  "common.results": { uz: "natija", en: "results", ru: "результатов" },
  "common.noResults": { uz: "Hech narsa topilmadi", en: "Nothing found", ru: "Ничего не найдено" },
  "common.filter": { uz: "Filtr", en: "Filter", ru: "Фильтр" },
  "common.close": { uz: "Yopish", en: "Close", ru: "Закрыть" },
  "common.optional": { uz: "ixtiyoriy", en: "optional", ru: "необязательно" },
  "common.required": { uz: "majburiy", en: "required", ru: "обязательно" },
  "common.language": { uz: "Til", en: "Language", ru: "Язык" },

  "article.related": { uz: "Bog‘liq yangiliklar", en: "Related stories", ru: "Похожие новости" },
  "article.tags": { uz: "Teglar", en: "Tags", ru: "Теги" },
  "article.share": { uz: "Ulashish", en: "Share", ru: "Поделиться" },
  "article.copyLink": { uz: "Havolani nusxalash", en: "Copy link", ru: "Копировать ссылку" },
  "article.copied": { uz: "Nusxalandi", en: "Copied", ru: "Скопировано" },
  "article.save": { uz: "Saqlash", en: "Save", ru: "Сохранить" },
  "article.saved": { uz: "Saqlangan", en: "Saved", ru: "Сохранено" },
  "article.comments": { uz: "Izohlar", en: "Comments", ru: "Комментарии" },
  "article.noComments": {
    uz: "Hozircha izoh yo‘q. Fikringizni birinchi bo‘lib yozing.",
    en: "No comments yet. Be the first to share your view.",
    ru: "Комментариев пока нет. Будьте первым.",
  },
  "article.commentPlaceholder": { uz: "Fikringiz…", en: "Your comment…", ru: "Ваш комментарий…" },
  "article.commentSubmit": { uz: "Yuborish", en: "Post", ru: "Отправить" },
  "article.commentModeration": {
    uz: "Izohlar moderatsiyadan keyin ko‘rinadi.",
    en: "Comments appear after moderation.",
    ru: "Комментарии появятся после модерации.",
  },
  "article.loginToComment": {
    uz: "Izoh qoldirish uchun tizimga kiring.",
    en: "Sign in to join the discussion.",
    ru: "Войдите, чтобы оставить комментарий.",
  },
  "article.readingTime": { uz: "O‘qish vaqti", en: "Reading time", ru: "Время чтения" },
  "article.views": { uz: "ko‘rishlar", en: "views", ru: "просмотров" },
  "article.reasonFactual": { uz: "Faktik xato", en: "Factual error", ru: "Фактическая ошибка" },
  "article.reasonTranslation": { uz: "Tarjima xatosi", en: "Translation issue", ru: "Ошибка перевода" },
  "article.reasonCopyright": { uz: "Mualliflik huquqi", en: "Copyright / attribution", ru: "Авторские права" },
  "article.reasonOther": { uz: "Boshqa", en: "Other", ru: "Другое" },
  "article.report": { uz: "Xatolik haqida xabar berish", en: "Report an error", ru: "Сообщить об ошибке" },
  "article.reportSent": {
    uz: "Xabaringiz yuborildi. Rahmat!",
    en: "Report received. Thank you.",
    ru: "Сообщение отправлено. Спасибо.",
  },
  "article.corrections": { uz: "Tuzatishlar tarixi", en: "Correction history", ru: "История правок" },
  "article.print": { uz: "Chop etish", en: "Print", ru: "Печать" },
  "article.fontSize": { uz: "Shrift o‘lchami", en: "Text size", ru: "Размер текста" },
  "article.sourceNotice": {
    uz: "Bu material manba nashri tomonidan chop etilgan. To‘liq matn mualliflik huquqi ostida.",
    en: "This story is published by the source outlet. Full text remains copyrighted.",
    ru: "Материал опубликован источником. Полный текст защищён авторским правом.",
  },
  "article.aiNotice": {
    uz: "Xulosa sun’iy intellekt yordamida tayyorlangan va tahririyat ko‘rigidan o‘tgan.",
    en: "Summary generated with AI assistance and reviewed by the newsroom.",
    ru: "Резюме подготовлено с помощью ИИ и проверено редакцией.",
  },
  "article.opinion": { uz: "Fikr", en: "Opinion", ru: "Мнение" },
  "article.sponsored": { uz: "Reklama", en: "Sponsored", ru: "Реклама" },

  "search.title": { uz: "Qidiruv", en: "Search", ru: "Поиск" },
  "search.placeholder": { uz: "Yangilik, mavzu yoki manba…", en: "News, topic or source…", ru: "Новость, тема или источник…" },
  "search.filters": { uz: "Qidiruv filtrlari", en: "Search filters", ru: "Фильтры поиска" },
  "search.from": { uz: "Sanadan", en: "From", ru: "С"},
  "search.to": { uz: "Sanagacha", en: "To", ru: "По" },
  "search.category": { uz: "Kategoriya", en: "Category", ru: "Категория" },
  "search.source": { uz: "Manba", en: "Source", ru: "Источник" },
  "search.language": { uz: "Til", en: "Language", ru: "Язык" },
  "search.sortNewest": { uz: "Yangilari", en: "Newest", ru: "Сначала новые" },
  "search.sortRelevant": { uz: "Mosligi", en: "Relevance", ru: "По релевантности" },
  "search.empty": { uz: "So‘rovingizga mos yangilik topilmadi.", en: "No stories match your query.", ru: "По вашему запросу ничего не найдено." },
  "search.suggestions": { uz: "Takliflar", en: "Suggestions", ru: "Подсказки" },
  "search.trending": { uz: "Hozir qidirilmoqda", en: "Trending searches", ru: "Популярные запросы" },

  "auth.loginTitle": { uz: "Hisobingizga kiring", en: "Sign in to your account", ru: "Войдите в аккаунт" },
  "auth.registerTitle": { uz: "NewsVerse’ga qo‘shiling", en: "Join NewsVerse", ru: "Присоединяйтесь к NewsVerse" },
  "auth.email": { uz: "Elektron pochta", en: "Email", ru: "Электронная почта" },
  "auth.password": { uz: "Parol", en: "Password", ru: "Пароль" },
  "auth.name": { uz: "Ism", en: "Full name", ru: "Имя" },
  "auth.confirmPassword": { uz: "Parolni tasdiqlang", en: "Confirm password", ru: "Повторите пароль" },
  "auth.noAccount": { uz: "Hisobingiz yo‘qmi?", en: "No account yet?", ru: "Нет аккаунта?" },
  "auth.hasAccount": { uz: "Hisobingiz bormi?", en: "Already have an account?", ru: "Уже есть аккаунт?" },
  "auth.forgot": { uz: "Parolni unutdingizmi?", en: "Forgot password?", ru: "Забыли пароль?" },
  "auth.invalid": { uz: "Email yoki parol noto‘g‘ri.", en: "Invalid email or password.", ru: "Неверный email или пароль." },
  "auth.suspended": {
    uz: "Hisobingiz vaqtincha bloklangan.",
    en: "Your account is suspended.",
    ru: "Ваш аккаунт приостановлен.",
  },
  "auth.emailTaken": { uz: "Bu email allaqachon ro‘yxatdan o‘tgan.", en: "That email is already registered.", ru: "Этот email уже зарегистрирован." },
  "auth.weakPassword": {
    uz: "Parol kamida 8 belgidan iborat bo‘lsin.",
    en: "Password must be at least 8 characters.",
    ru: "Пароль должен быть не короче 8 символов.",
  },
  "auth.mismatch": { uz: "Parollar mos kelmadi.", en: "Passwords do not match.", ru: "Пароли не совпадают." },
  "auth.rateLimited": {
    uz: "Juda ko‘p urinish. Birozdan so‘ng qayta urinib ko‘ring.",
    en: "Too many attempts. Please try again shortly.",
    ru: "Слишком много попыток. Попробуйте позже.",
  },
  "auth.google": { uz: "Google bilan kirish", en: "Continue with Google", ru: "Войти через Google" },
  "auth.googleUnavailable": {
    uz: "Google kirish sozlanmagan (OAuth kalitlari yo‘q).",
    en: "Google sign-in is not configured (no OAuth credentials).",
    ru: "Вход через Google не настроен (нет OAuth-ключей).",
  },
  "auth.username": { uz: "Foydalanuvchi nomi", en: "Username", ru: "Имя пользователя" },
  "auth.usernameHint": {
    uz: "3–24 belgi: harflar, raqamlar va pastki chiziq",
    en: "3–24 characters: letters, numbers and underscore",
    ru: "3–24 символа: буквы, цифры и подчёркивание",
  },
  "auth.usernameTaken": {
    uz: "Bu foydalanuvchi nomi band.",
    en: "That username is already taken.",
    ru: "Это имя пользователя уже занято.",
  },
  "auth.identifier": { uz: "Email yoki foydalanuvchi nomi", en: "Email or username", ru: "Email или имя пользователя" },
  "auth.showPassword": { uz: "Parolni ko‘rsatish", en: "Show password", ru: "Показать пароль" },
  "auth.hidePassword": { uz: "Parolni yashirish", en: "Hide password", ru: "Скрыть пароль" },
  "auth.verifySent": {
    uz: "Tasdiqlash havolasi yuborildi. Bu muhitda u server jurnaliga yoziladi.",
    en: "A verification link was sent. In this environment it is written to the server log.",
    ru: "Ссылка подтверждения отправлена. В этой среде она пишется в журнал сервера.",
  },
  "auth.verifyOk": {
    uz: "Email muvaffaqiyatli tasdiqlandi.",
    en: "Your email is verified.",
    ru: "Ваш email подтверждён.",
  },
  "auth.verifyInvalid": {
    uz: "Tasdiqlash havolasi yaroqsiz yoki muddati tugagan.",
    en: "This verification link is invalid or has expired.",
    ru: "Ссылка подтверждения недействительна или истекла.",
  },
  "auth.resend": { uz: "Havolani qayta yuborish", en: "Resend verification link", ru: "Отправить ссылку снова" },
  "auth.resendSent": { uz: "Yangi havola yuborildi.", en: "A new link was sent.", ru: "Новая ссылка отправлена." },
  "auth.changePassword": { uz: "Parolni almashtirish", en: "Change password", ru: "Сменить пароль" },
  "auth.currentPassword": { uz: "Joriy parol", en: "Current password", ru: "Текущий пароль" },
  "auth.newPassword": { uz: "Yangi parol", en: "New password", ru: "Новый пароль" },
  "auth.passwordChanged": { uz: "Parol yangilandi.", en: "Password updated.", ru: "Пароль обновлён." },
  "auth.changeEmail": { uz: "Emailni almashtirish", en: "Change email", ru: "Сменить email" },
  "auth.checkEmail": {
    uz: "Tasdiqlash uchun yangi manzilga yuborilgan havolani oching.",
    en: "Open the link sent to the new address to confirm the change.",
    ru: "Откройте ссылку, отправленную на новый адрес, чтобы подтвердить изменение.",
  },
  "auth.emailChanged": { uz: "Email o‘zgartirildi.", en: "Email changed.", ru: "Email изменён." },
  "auth.resetTitle": { uz: "Parolni tiklash", en: "Reset your password", ru: "Сброс пароля" },
  "auth.resetSent": {
    uz: "Agar email mavjud bo‘lsa, tiklash havolasi yuborildi. (Pochta jo‘natuvchisi sozlanmagan bo‘lsa, havola serverda ko‘rinmaydi.)",
    en: "If the email exists, a reset link was created. (Without a mail provider configured, the link is written to the server console.)",
    ru: "Если email существует, ссылка создана. (Без настроенного почтового провайдера ссылка выводится в консоль сервера.)",
  },
  "auth.loggedOut": { uz: "Siz tizimdan chiqdingiz.", en: "You have been signed out.", ru: "Вы вышли из аккаунта." },

  "account.security": { uz: "Xavfsizlik", en: "Security", ru: "Безопасность" },
  "account.title": { uz: "Profil sozlamalari", en: "Profile settings", ru: "Настройки профиля" },
  "account.profile": { uz: "Profil", en: "Profile", ru: "Профиль" },
  "account.preferences": { uz: "Afzalliklar", en: "Preferences", ru: "Предпочтения" },
  "account.interests": { uz: "Qiziqishlar", en: "Interests", ru: "Интересы" },
  "account.interestsHint": {
    uz: "Tanlangan kategoriyalar bosh sahifada tavsiya etiladi.",
    en: "Selected categories shape your recommendations.",
    ru: "Выбранные категории влияют на рекомендации.",
  },
  "account.history": { uz: "O‘qish tarixi", en: "Reading history", ru: "История чтения" },
  "account.historyHint": {
    uz: "Tarixni istalgan vaqtda tozalashingiz mumkin.",
    en: "You can clear your history at any time.",
    ru: "Историю можно очистить в любое время.",
  },
  "account.clearHistory": { uz: "Tarixni tozalash", en: "Clear history", ru: "Очистить историю" },
  "account.export": { uz: "Ma’lumotlarni yuklab olish", en: "Export my data", ru: "Экспорт данных" },
  "account.delete": { uz: "Hisobni o‘chirish", en: "Delete account", ru: "Удалить аккаунт" },
  "account.deleteConfirm": {
    uz: "Hisob butunlay o‘chiriladi. Davom etasizmi?",
    en: "This permanently deletes your account. Continue?",
    ru: "Аккаунт будет удалён навсегда. Продолжить?",
  },
  "account.saved": { uz: "Saqlandi", en: "Saved", ru: "Сохранено" },
  "account.newsletter": { uz: "Axborotnomaga obuna", en: "Newsletter", ru: "Рассылка" },
  "account.notifications": { uz: "Bildirishnomalar", en: "Notifications", ru: "Уведомления" },
  "account.noHistory": { uz: "Tarix bo‘sh", en: "No reading history", ru: "История пуста" },
  "account.emailUnverified": {
    uz: "Email hali tasdiqlanmagan. Tasdiqlash havolasini qayta yuborishingiz mumkin.",
    en: "Your email is not verified yet. You can resend the verification link.",
    ru: "Ваш email ещё не подтверждён. Можно отправить ссылку повторно.",
  },
  "account.avatarUrl": { uz: "Profil rasmi havolasi", en: "Avatar URL", ru: "Ссылка на аватар" },
  "account.bio": { uz: "Qisqacha ma’lumot", en: "Short bio", ru: "Коротко о себе" },
  "account.save": { uz: "Saqlash", en: "Save changes", ru: "Сохранить" },
  "account.dangerZone": { uz: "Xavfli hudud", en: "Danger zone", ru: "Опасная зона" },
  "account.dangerHint": {
    uz: "Hisobni o‘chirsangiz, saqlangan maqolalar, tarix va izohlar ham o‘chiriladi.",
    en: "Deleting your account also removes bookmarks, history and comments.",
    ru: "Удаление аккаунта также удалит закладки, историю и комментарии.",
  },

  "bookmarks.title": { uz: "Saqlangan yangiliklar", en: "Saved stories", ru: "Сохранённые новости" },
  "bookmarks.folder": { uz: "Jild", en: "Folder", ru: "Папка" },
  "bookmarks.empty": {
    uz: "Hozircha saqlangan yangilik yo‘q. Maqoladagi “Saqlash” tugmasini bosing.",
    en: "Nothing saved yet. Use “Save” on any story.",
    ru: "Пока ничего не сохранено. Нажмите «Сохранить» в статье.",
  },
  "bookmarks.login": {
    uz: "Saqlanganlarni ko‘rish uchun tizimga kiring.",
    en: "Sign in to see your saved stories.",
    ru: "Войдите, чтобы увидеть сохранённое.",
  },

  "footer.about": { uz: "Biz haqimizda", en: "About", ru: "О нас" },
  "footer.contact": { uz: "Aloqa", en: "Contact", ru: "Контакты" },
  "footer.privacy": { uz: "Maxfiylik siyosati", en: "Privacy policy", ru: "Политика конфиденциальности" },
  "footer.terms": { uz: "Foydalanish shartlari", en: "Terms of use", ru: "Условия использования" },
  "footer.sources": { uz: "Manbalar va atributsiya", en: "Sources & attribution", ru: "Источники и атрибуция" },
  "footer.rss": { uz: "RSS lenta", en: "RSS feed", ru: "RSS-лента" },
  "footer.sitemap": { uz: "Sayt xaritasi", en: "Sitemap", ru: "Карта сайта" },
  "footer.rights": { uz: "Barcha huquqlar himoyalangan.", en: "All rights reserved.", ru: "Все права защищены." },
  "footer.editorial": {
    uz: "NewsVerse — mustaqil yangiliklar agregatori. Har bir material manbasi ko‘rsatiladi.",
    en: "NewsVerse is an independent news aggregator. Every story credits its publisher.",
    ru: "NewsVerse — независимый агрегатор новостей. У каждой новости указан источник.",
  },
  "footer.sections": { uz: "Bo‘limlar", en: "Sections", ru: "Разделы" },
  "footer.company": { uz: "Kompaniya", en: "Company", ru: "Компания" },
  "footer.follow": { uz: "Bizni kuzating", en: "Follow us", ru: "Мы в соцсетях" },
  "footer.newsletter": { uz: "Axborotnoma", en: "Newsletter", ru: "Рассылка" },

  "state.emptyTitle": { uz: "Hozircha bo‘sh", en: "Nothing here yet", ru: "Здесь пока пусто" },
  "state.emptyBody": {
    uz: "Bu bo‘limda hozircha material yo‘q. Keyinroq qayta tekshiring.",
    en: "There is no content in this section yet. Check back soon.",
    ru: "В этом разделе пока нет материалов. Загляните позже.",
  },
  "state.errorTitle": { uz: "Nimadir noto‘g‘ri ketdi", en: "Something went wrong", ru: "Что-то пошло не так" },
  "state.errorBody": {
    uz: "Sahifani yuklab bo‘lmadi. Qayta urinib ko‘ring.",
    en: "This page could not be loaded. Please try again.",
    ru: "Не удалось загрузить страницу. Попробуйте снова.",
  },
  "state.notFoundTitle": { uz: "Sahifa topilmadi", en: "Page not found", ru: "Страница не найдена" },
  "state.notFoundBody": {
    uz: "Havola eskirgan yoki sahifa ko‘chirilgan bo‘lishi mumkin.",
    en: "The link may be outdated or the page was moved.",
    ru: "Возможно, ссылка устарела или страница перемещена.",
  },
  "state.backHome": { uz: "Bosh sahifaga", en: "Back to home", ru: "На главную" },

  "category.title": { uz: "Kategoriya", en: "Category", ru: "Категория" },
  "category.stories": { uz: "yangilik", en: "stories", ru: "новостей" },
  "category.none": {
    uz: "Bu kategoriyada hozircha yangilik yo‘q.",
    en: "No stories in this category yet.",
    ru: "В этой категории пока нет новостей.",
  },

  "meta.homeTitle": { uz: "NewsVerse — dunyo yangiliklari", en: "NewsVerse — world news", ru: "NewsVerse — новости мира" },
  "meta.homeDesc": {
    uz: "O‘zbekiston va dunyo yangiliklari: siyosat, iqtisod, texnologiya, sport va boshqalar.",
    en: "Uzbekistan and world news: politics, business, technology, sport and more.",
    ru: "Новости Узбекистана и мира: политика, экономика, технологии, спорт и другое.",
  },

  "admin.title": { uz: "Boshqaruv paneli", en: "Admin dashboard", ru: "Панель управления" },
  "admin.overview": { uz: "Umumiy ko‘rinish", en: "Overview", ru: "Обзор" },
  "admin.articles": { uz: "Yangiliklar", en: "Articles", ru: "Новости" },
  "admin.sources": { uz: "Manbalar", en: "Sources", ru: "Источники" },
  "admin.automation": { uz: "Avtomatlashtirish", en: "Automation", ru: "Автоматизация" },
  "admin.categories": { uz: "Kategoriyalar", en: "Categories", ru: "Категории" },
  "admin.users": { uz: "Foydalanuvchilar", en: "Users", ru: "Пользователи" },
  "admin.comments": { uz: "Izohlar", en: "Comments", ru: "Комментарии" },
  "admin.newsletter": { uz: "Obunachilar", en: "Subscribers", ru: "Подписчики" },
  "admin.audit": { uz: "Audit jurnali", en: "Audit log", ru: "Журнал аудита" },
  "admin.settings": { uz: "Sozlamalar", en: "Settings", ru: "Настройки" },
  "admin.reports": { uz: "Shikoyatlar", en: "Reports", ru: "Жалобы" },
  "admin.backToSite": { uz: "Saytga qaytish", en: "Back to site", ru: "На сайт" },
  "admin.forbidden": { uz: "Ruxsat yo‘q", en: "Not authorized", ru: "Доступ запрещён" },
  "admin.forbiddenBody": {
    uz: "Bu bo‘limga kirish uchun administrator huquqi kerak.",
    en: "Administrator privileges are required for this section.",
    ru: "Для этого раздела нужны права администратора.",
  },
  "admin.stat.published": { uz: "Chop etilgan", en: "Published", ru: "Опубликовано" },
  "admin.stat.pending": { uz: "Ko‘rikda", en: "Awaiting review", ru: "На проверке" },
  "admin.stat.scheduled": { uz: "Rejalashtirilgan", en: "Scheduled", ru: "Запланировано" },
  "admin.stat.failedJobs": { uz: "Xato ishlar", en: "Failed jobs", ru: "Неудачные задачи" },
  "admin.stat.users": { uz: "Foydalanuvchilar", en: "Users", ru: "Пользователи" },
  "admin.stat.views": { uz: "Ko‘rishlar", en: "Views", ru: "Просмотры" },
  "admin.stat.commentsPending": { uz: "Kutilayotgan izohlar", en: "Pending comments", ru: "Комментарии на модерации" },
  "admin.stat.sources": { uz: "Faol manbalar", en: "Active sources", ru: "Активные источники" },
  "admin.chart.views": { uz: "Kunlik ko‘rishlar", en: "Daily views", ru: "Просмотры по дням" },
  "admin.chart.ingest": { uz: "Import qilingan maqolalar", en: "Articles ingested", ru: "Импортировано статей" },
  "admin.topArticles": { uz: "Eng ommabop maqolalar", en: "Top articles", ru: "Популярные статьи" },
  "admin.topCategories": { uz: "Ommabop kategoriyalar", en: "Top categories", ru: "Популярные категории" },
  "admin.recentActivity": { uz: "So‘nggi harakatlar", en: "Recent activity", ru: "Последние действия" },
  "admin.sourceHealth": { uz: "Manbalar holati", en: "Source health", ru: "Состояние источников" },
  "admin.newArticle": { uz: "Yangi maqola", en: "New article", ru: "Новая статья" },
  "admin.status": { uz: "Holat", en: "Status", ru: "Статус" },
  "admin.actions": { uz: "Amallar", en: "Actions", ru: "Действия" },
  "admin.publish": { uz: "Chop etish", en: "Publish", ru: "Опубликовать" },
  "admin.unpublish": { uz: "Bekor qilish", en: "Unpublish", ru: "Снять с публикации" },
  "admin.archive": { uz: "Arxivlash", en: "Archive", ru: "В архив" },
  "admin.restore": { uz: "Tiklash", en: "Restore", ru: "Восстановить" },
  "admin.approve": { uz: "Tasdiqlash", en: "Approve", ru: "Одобрить" },
  "admin.reject": { uz: "Rad etish", en: "Reject", ru: "Отклонить" },
  "admin.suspend": { uz: "Bloklash", en: "Suspend", ru: "Заблокировать" },
  "admin.reactivate": { uz: "Faollashtirish", en: "Reactivate", ru: "Разблокировать" },
  "admin.runNow": { uz: "Hozir ishga tushirish", en: "Run now", ru: "Запустить сейчас" },
  "admin.testFeed": { uz: "Lentani tekshirish", en: "Test feed", ru: "Проверить ленту" },
  "admin.saveSettings": { uz: "Sozlamalarni saqlash", en: "Save settings", ru: "Сохранить настройки" },
  "admin.saved": { uz: "Saqlandi", en: "Saved", ru: "Сохранено" },
  "admin.preview": { uz: "Ko‘rib chiqish", en: "Preview", ru: "Предпросмотр" },
  "admin.duplicates": { uz: "Dublikatlar", en: "Duplicates", ru: "Дубликаты" },
  "admin.merge": { uz: "Birlashtirish", en: "Merge", ru: "Объединить" },
  "admin.logs": { uz: "Jurnallar", en: "Logs", ru: "Журналы" },
  "admin.queue": { uz: "Navbat", en: "Queue", ru: "Очередь" },
  "admin.jobFailed": { uz: "Xato", en: "Failed", ru: "Ошибка" },
  "admin.jobQueued": { uz: "Navbatda", en: "Queued", ru: "В очереди" },
  "admin.jobRunning": { uz: "Bajarilmoqda", en: "Running", ru: "Выполняется" },
  "admin.jobSucceeded": { uz: "Bajarildi", en: "Succeeded", ru: "Выполнено" },
  "admin.retryJob": { uz: "Qayta urinish", en: "Retry", ru: "Повторить" },
  "admin.aiDisabled": {
    uz: "AI provayderi sozlanmagan — lokal xulosa rejimi yoqilgan.",
    en: "AI provider not configured — local extractive mode is active.",
    ru: "AI-провайдер не настроен — используется локальный режим.",
  },
  "admin.ingestionEnabled": { uz: "Avtomatik yig‘ish yoqilgan", en: "Automated ingestion enabled", ru: "Автосбор включён" },
  "admin.moderationMode": { uz: "Moderatsiya rejimi", en: "Moderation mode", ru: "Режим модерации" },
  "admin.modeAuto": { uz: "Avtomatik chop etish", en: "Auto-publish", ru: "Автопубликация" },
  "admin.modeReview": { uz: "Qo‘lda ko‘rik", en: "Manual review", ru: "Ручная проверка" },
  "admin.modeHybrid": { uz: "Gibrid (ishonchga qarab)", en: "Hybrid (by trust)", ru: "Гибридный (по доверию)" },
  "admin.noPermission": { uz: "Bu amal uchun ruxsat yo‘q.", en: "You do not have permission for this action.", ru: "Недостаточно прав для этого действия." },
} as const satisfies Record<string, Entry>;

export type TranslationKey = keyof typeof strings;

export function t(
  locale: Locale,
  key: TranslationKey,
  vars?: Record<string, string | number>,
): string {
  const entry: Entry | undefined = strings[key];
  let out = entry ? entry[locale] || entry.en : (key as string);
  if (vars) {
    for (const [k, v] of Object.entries(vars)) out = out.replaceAll(`{${k}}`, String(v));
  }
  return out;
}

export type TFn = (key: TranslationKey, vars?: Record<string, string | number>) => string;

export function createT(locale: Locale): TFn {
  return (key, vars) => t(locale, key, vars);
}

export function formatDate(value: string | Date, locale: Locale, withTime = true): string {
  const d = typeof value === "string" ? new Date(value) : value;
  if (Number.isNaN(d.getTime())) return "—";
  return new Intl.DateTimeFormat(localeTags[locale], {
    day: "numeric",
    month: "long",
    year: "numeric",
    ...(withTime ? { hour: "2-digit", minute: "2-digit" } : {}),
  }).format(d);
}

export function formatShortDate(value: string | Date, locale: Locale): string {
  const d = typeof value === "string" ? new Date(value) : value;
  if (Number.isNaN(d.getTime())) return "—";
  return new Intl.DateTimeFormat(localeTags[locale], {
    day: "numeric",
    month: "short",
  }).format(d);
}

export function formatNumber(value: number, locale: Locale): string {
  return new Intl.NumberFormat(localeTags[locale]).format(value);
}

const relativeUnits = [
  { unit: "year", ms: 31536000000 },
  { unit: "month", ms: 2592000000 },
  { unit: "week", ms: 604800000 },
  { unit: "day", ms: 86400000 },
  { unit: "hour", ms: 3600000 },
  { unit: "minute", ms: 60000 },
] as const;

export function relativeTime(value: string | Date, locale: Locale): string {
  const d = typeof value === "string" ? new Date(value) : value;
  if (Number.isNaN(d.getTime())) return "—";
  const diff = Date.now() - d.getTime();
  const rtf = new Intl.RelativeTimeFormat(localeTags[locale], { numeric: "auto" });
  if (diff < 60000) return rtf.format(0, "minute");
  for (const { unit, ms } of relativeUnits) {
    if (diff >= ms) return rtf.format(-Math.floor(diff / ms), unit);
  }
  return rtf.format(-1, "minute");
}

export function localeHref(locale: Locale, path = ""): string {
  const clean = path.startsWith("/") ? path : `/${path}`;
  return `/${locale}${clean === "/" ? "" : clean}`;
}
