import { get } from "@/server/db";
import { requireUser, isStaff } from "@/server/auth";
import { guardOrigin } from "@/server/adminGuard";
import { json, fail, parseBody, handleError } from "@/server/http";
import { commentSchema } from "@/lib/validation";
import { addComment } from "@/server/repo/content";
import { getBoolSetting } from "@/server/repo/settings";

export async function POST(request: Request) {
  try {
    guardOrigin(request);
    const user = await requireUser();
    if (!getBoolSetting("comments_enabled", true)) return fail("Comments are disabled", 403);
    const input = await parseBody(request, commentSchema);
    const article = get<{ id: string }>(
      "SELECT id FROM articles WHERE id = ? AND status = 'published' AND deleted_at IS NULL",
      input.articleId,
    );
    if (!article) return fail("Article not found", 404);
    const id = addComment(input.articleId, user.id, input.body, isStaff(user));
    return json({ ok: true, id, status: isStaff(user) ? "approved" : "pending" });
  } catch (err) {
    return handleError(err);
  }
}
