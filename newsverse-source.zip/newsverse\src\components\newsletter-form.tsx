"use client";

import { useState } from "react";
import { t, type Locale } from "@/i18n";

export function NewsletterForm({ locale, compact = false }: { locale: Locale; compact?: boolean }) {
  const [email, setEmail] = useState("");
  const [state, setState] = useState<"idle" | "loading" | "ok" | "error">("idle");
  const [message, setMessage] = useState("");

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
      setState("error");
      setMessage(t(locale, "newsletter.invalid"));
      return;
    }
    setState("loading");
    try {
      const res = await fetch("/api/newsletter", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ email, locale }),
      });
      if (!res.ok) throw new Error("failed");
      setState("ok");
      setMessage(t(locale, "newsletter.ok"));
      setEmail("");
    } catch {
      setState("error");
      setMessage(t(locale, "common.error"));
    }
  }

  return (
    <form onSubmit={submit} className={compact ? "" : "max-w-lg"}>
      <div className="flex flex-col gap-2 sm:flex-row">
        <label className="sr-only" htmlFor="newsletter-email">{t(locale, "newsletter.placeholder")}</label>
        <input
          id="newsletter-email"
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder={t(locale, "newsletter.placeholder")}
          className="input flex-1 !rounded-full"
          autoComplete="email"
        />
        <button type="submit" className="btn-primary shrink-0" disabled={state === "loading"}>
          {state === "loading" ? t(locale, "common.loading") : t(locale, "newsletter.cta")}
        </button>
      </div>
      <p role="status" className={`mt-2 text-xs ${state === "ok" ? "text-emerald-400" : state === "error" ? "text-brand" : "subtle"}`}>
        {message || t(locale, "newsletter.privacy")}
      </p>
    </form>
  );
}
