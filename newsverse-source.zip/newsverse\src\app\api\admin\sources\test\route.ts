import { guardAdmin } from "@/server/adminGuard";
import { json, fail, parseBody } from "@/server/http";
import { sourceTestSchema } from "@/lib/validation";
import { fetchFeed } from "@/server/ingest/rss";

export async function POST(request: Request) {
  try {
    await guardAdmin(request);
    const input = await parseBody(request, sourceTestSchema);
    const feed = await fetchFeed(input.feedUrl);
    return json({
      ok: true,
      title: feed.title.slice(0, 120),
      siteUrl: feed.siteUrl,
      items: feed.items.length,
      sample: feed.items.slice(0, 3).map((i) => ({ title: i.title.slice(0, 140), publishedAt: i.publishedAt })),
    });
  } catch (err) {
    return fail((err as Error).message, 400);
  }
}
