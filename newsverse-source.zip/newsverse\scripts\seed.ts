import { ensureBootstrapped } from "../src/server/db/bootstrap";
import { all, dbPath } from "../src/server/db";

ensureBootstrapped();
const articles = all<{ c: number }>("SELECT COUNT(*) AS c FROM articles")[0]?.c ?? 0;
const sources = all<{ c: number }>("SELECT COUNT(*) AS c FROM sources")[0]?.c ?? 0;
const categories = all<{ c: number }>("SELECT COUNT(*) AS c FROM categories")[0]?.c ?? 0;
console.log(`Seeded ${dbPath()}`);
console.log(`${categories} categories · ${sources} sources · ${articles} articles (demonstration content is labelled in the UI).`);
