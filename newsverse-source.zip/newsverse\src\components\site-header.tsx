import Link from "next/link";
import { getCurrentUser, isAdmin, isStaff } from "@/server/auth";
import { listCategories } from "@/server/repo/content";
import { getSetting } from "@/server/repo/settings";
import { formatDate, t, type Locale } from "@/i18n";
import { LanguageSwitcher } from "@/components/language-switcher";
import { ThemeToggle } from "@/components/theme-toggle";
import { HeaderSearch } from "@/components/header-search";
import { MobileMenu } from "@/components/mobile-menu";
import { CategoryRail } from "@/components/category-rail";
import { LogoutButton } from "@/components/logout-button";
import { IconUser } from "@/components/icons";
import { BrandLogo } from "@/components/brand-logo";

const PRIMARY = ["uzbekistan", "world", "politics", "business", "technology", "ai", "sports"];

export async function SiteHeader({ locale }: { locale: Locale }) {
  const user = await getCurrentUser();
  const categories = listCategories(locale);
  const primary = categories.filter((c) => PRIMARY.includes(c.slug));
  const today = formatDate(new Date(), locale, false);
  const siteName = getSetting("site_name", "NewsVerse");

  return (
    <header className="sticky top-0 z-40 border-b backdrop-blur-xl" style={{ borderColor: "var(--line)", background: "color-mix(in srgb, var(--bg) 86%, transparent)" }}>
      <div className="hidden border-b sm:block" style={{ borderColor: "var(--line)" }}>
        <div className="container-nv flex h-9 items-center justify-between text-[11px] subtle">
          <div className="flex items-center gap-2">
            <span className="inline-flex h-1.5 w-1.5 rounded-full bg-brand" />
            <time dateTime={new Date().toISOString()}>{today}</time>
            <span aria-hidden className="mx-1">·</span>
            <span>{t(locale, "brand.tagline")}</span>
          </div>
          <div className="flex items-center gap-2">
            {user ? (
              <>
                <Link href={`/${locale}/saved`} className="hover:text-brand">{t(locale, "nav.bookmarks")}</Link>
                <span aria-hidden>·</span>
                <Link href={`/${locale}/account`} className="font-semibold hover:text-brand">{user.name}</Link>
                {isStaff(user) && (
                  <>
                    <span aria-hidden>·</span>
                    <Link href={`/${locale}/admin`} className="font-semibold text-brand">{t(locale, "nav.admin")}</Link>
                  </>
                )}
                <LogoutButton locale={locale} />
              </>
            ) : (
              <>
                <Link href={`/${locale}/login`} className="hover:text-brand">{t(locale, "nav.login")}</Link>
                <span aria-hidden>·</span>
                <Link href={`/${locale}/register`} className="font-semibold hover:text-brand">{t(locale, "nav.register")}</Link>
              </>
            )}
          </div>
        </div>
      </div>

      <div className="container-nv relative flex h-16 items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <MobileMenu
            locale={locale}
            categories={categories.map((c) => ({ slug: c.slug, name: c.name }))}
            signedIn={!!user}
            isStaff={isAdmin(user)}
            displayName={user?.name ?? null}
          />
          <BrandLogo href={`/${locale}`} size="md" compactWordmark />
        </div>

        <nav aria-label={t(locale, "nav.categories")} className="hidden items-center gap-1 lg:flex">
          {primary.map((c) => (
            <Link
              key={c.slug}
              href={`/${locale}/category/${c.slug}`}
              className="rounded-full px-2.5 py-1.5 text-[13px] font-semibold transition hover:bg-brand/10 hover:text-brand"
            >
              {c.name}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-1.5">
          <div className="hidden sm:block">
            <HeaderSearch locale={locale} placeholder={t(locale, "search.placeholder")} label={t(locale, "nav.search")} />
          </div>
          <LanguageSwitcher current={locale} label={t(locale, "nav.language")} />
          <div className="hidden sm:block"><ThemeToggle label={t(locale, "nav.theme")} /></div>
          <Link
            href={user ? `/${locale}/account` : `/${locale}/login`}
            aria-label={user ? t(locale, "nav.account") : t(locale, "nav.login")}
            className="flex h-9 w-9 items-center justify-center rounded-full bg-brand text-white transition hover:bg-brand-600"
          >
            <IconUser size={17} />
          </Link>
        </div>
      </div>

      <CategoryRail locale={locale} categories={categories.map((c) => ({ slug: c.slug, name: c.name, icon: c.icon, color: c.color }))} allLabel={t(locale, "nav.latest")} />
    </header>
  );
}
