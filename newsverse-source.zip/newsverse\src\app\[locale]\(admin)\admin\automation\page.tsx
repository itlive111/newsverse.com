import { adminGate } from "@/server/adminPage";
import { notFound } from "next/navigation";
import { formatDate, isLocale, t } from "@/i18n";
import { getAllSettings } from "@/server/repo/settings";
import { listAlerts, listIngestionLogs, listJobs } from "@/server/repo/admin";
import { jobStats, schedulerInfo } from "@/server/ingest/jobs";
import { SettingsForm, type SettingField } from "@/components/admin/settings-form";
import { ActionButton } from "@/components/admin/action-button";
import { AdminSection, EmptyRow, StatCard, StatusBadge, Td, Th } from "@/components/admin/ui";

export const dynamic = "force-dynamic";

export default async function AdminAutomation({ params }: { params: Promise<{ locale: string }> }) {
  const { locale: raw } = await params;
  if (!isLocale(raw)) notFound();
  const locale = raw;
  await adminGate();
  const settings = getAllSettings();
  const jobs = listJobs();
  const logs = listIngestionLogs(40);
  const alerts = listAlerts();
  const stats = jobStats();
  const scheduler = schedulerInfo();

  const fields: SettingField[] = [
    { key: "ingest_enabled", label: t(locale, "admin.ingestionEnabled"), type: "checkbox", hint: "Enable scheduled collection" },
    { key: "auto_ingest_enabled", label: "Automatic ingestion", type: "checkbox", hint: "Queue sources automatically" },
    {
      key: "moderation_mode",
      label: t(locale, "admin.moderationMode"),
      type: "select",
      options: [
        { value: "review", label: t(locale, "admin.modeReview") },
        { value: "hybrid", label: t(locale, "admin.modeHybrid") },
        { value: "auto", label: t(locale, "admin.modeAuto") },
      ],
    },
    { key: "auto_publish_trust", label: "Minimum source trust for auto-publish (1–5)", type: "number" },
    { key: "ingest_max_items_per_run", label: "Max items per source per run", type: "number" },
    { key: "breaking_keywords", label: "Breaking-news keywords (comma separated)", type: "textarea" },
    { key: "ai_enabled", label: "AI assistance", type: "checkbox", hint: "Summaries, translation drafts, classification" },
    { key: "notify_on_failure", label: "Alert on repeated failures", type: "checkbox", hint: "Records an alert for administrators" },
    { key: "failure_alert_threshold", label: "Consecutive failures before alert", type: "number" },
  ];

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-2">
        <div>
          <h1 className="font-display text-2xl font-black tracking-tight">{t(locale, "admin.automation")}</h1>
          <p className="text-xs subtle">
            Scheduler: {scheduler.running ? `running · tick ${Math.round(scheduler.intervalMs / 1000)}s` : "not running"} · last tick{" "}
            {scheduler.lastTickAt ? formatDate(scheduler.lastTickAt, locale) : "—"}
          </p>
        </div>
        <ActionButton endpoint="/api/cron/tick" label={t(locale, "admin.runNow")} variant="primary" busyLabel={t(locale, "admin.jobRunning")} />
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCard label={t(locale, "admin.jobQueued")} value={stats.queued} />
        <StatCard label={t(locale, "admin.jobRunning")} value={stats.running} />
        <StatCard label={t(locale, "admin.jobSucceeded")} value={stats.succeeded} />
        <StatCard label={t(locale, "admin.jobFailed")} value={stats.failed} accent />
      </div>

      {alerts.length > 0 && (
        <AdminSection title="Alerts">
          <ul className="space-y-1 text-xs">
            {alerts.map((a: Record<string, string>, i: number) => (
              <li key={i} className="text-brand">
                {a.message} <span className="text-[10px] subtle">{formatDate(a.created_at, locale)}</span>
              </li>
            ))}
          </ul>
        </AdminSection>
      )}

      <AdminSection title={t(locale, "admin.settings")}>
        <SettingsForm locale={locale} fields={fields} initial={settings} />
        <p className="mt-3 text-[11px] subtle">
          AI providers are configured with server-side environment variables only. When they are absent, summaries fall back
          to the publisher&apos;s permitted excerpt and translations are labelled as unavailable rather than invented.
        </p>
      </AdminSection>

      <AdminSection title={t(locale, "admin.queue")}>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr>
                <Th>Job</Th>
                <Th>Source</Th>
                <Th>{t(locale, "admin.status")}</Th>
                <Th>Attempts</Th>
                <Th>Next run</Th>
                <Th>{t(locale, "admin.actions")}</Th>
              </tr>
            </thead>
            <tbody>
              {jobs.slice(0, 30).map((j: Record<string, string | number | null>) => (
                <tr key={String(j.id)} className="border-t" style={{ borderColor: "var(--line)" }}>
                  <Td className="font-mono text-[10px]">{String(j.type)}</Td>
                  <Td className="subtle">{String(j.source_name ?? "—")}</Td>
                  <Td><StatusBadge status={String(j.status)} /></Td>
                  <Td>{String(j.attempts)}/{String(j.max_attempts)}</Td>
                  <Td className="subtle">{j.next_run_at ? formatDate(String(j.next_run_at), locale) : "—"}</Td>
                  <Td>
                    {j.status === "failed" ? (
                      <ActionButton endpoint={`/api/admin/jobs/${j.id}/retry`} label={t(locale, "admin.retryJob")} />
                    ) : (
                      <span className="text-[10px] subtle">—</span>
                    )}
                  </Td>
                </tr>
              ))}
              {!jobs.length && <EmptyRow colSpan={6} text={t(locale, "common.noResults")} />}
            </tbody>
          </table>
        </div>
      </AdminSection>

      <AdminSection title={t(locale, "admin.logs")}>
        <ul className="max-h-80 space-y-1 overflow-y-auto text-[11px]">
          {logs.map((l: Record<string, string>, i: number) => (
            <li key={i} className="flex gap-2 border-t pt-1 first:border-0 first:pt-0" style={{ borderColor: "var(--line)" }}>
              <span className="whitespace-nowrap subtle">{formatDate(l.created_at, locale)}</span>
              <span className={l.level === "error" ? "text-brand" : l.level === "warn" ? "text-amber-300" : "subtle"}>[{l.level}]</span>
              <span className="min-w-0 break-words">{l.source_name ? `${l.source_name}: ` : ""}{l.message}</span>
            </li>
          ))}
          {!logs.length && <li className="subtle">{t(locale, "common.noResults")}</li>}
        </ul>
      </AdminSection>
    </div>
  );
}
