# Database backups and restore

The entire application state — articles, translations, users, sessions, jobs, settings — lives in
one SQLite file (`DATABASE_PATH`, default `data/newsverse.db`) plus its WAL files.

## Consistent online backup

`VACUUM INTO` produces a consistent snapshot while the server keeps running:

```bash
mkdir -p backups
node -e '
const { DatabaseSync } = require("node:sqlite");
const db = new DatabaseSync(process.env.DATABASE_PATH || "./data/newsverse.db");
const out = `backups/newsverse-${new Date().toISOString().replace(/[:.]/g, "-")}.db`;
db.exec(`VACUUM INTO '${out}'`);
console.log("wrote", out);
'
```

Cron example (daily 03:15, keep 14 days):

```cron
15 3 * * * cd /srv/newsverse && /usr/bin/node scripts/backup.js >> /var/log/newsverse-backup.log 2>&1
```

Copy snapshots off the host (object storage, another disk). A backup on the same disk does not
survive disk loss.

## Restore

```bash
docker compose stop web         # or: systemctl stop newsverse
cp backups/newsverse-2026-10-30T03-15-00-000Z.db data/newsverse.db
rm -f data/newsverse.db-wal data/newsverse.db-shm
docker compose start web        # or: systemctl start newsverse
curl -fsS http://localhost:3000/api/health
```

Verify after restore: `/uz` loads, an article opens, `/uz/admin` shows articles and sources.

## Restore drill checklist

- [ ] Stop the service so nothing writes during the copy
- [ ] Remove stale `-wal` / `-shm` files
- [ ] Start, then check `/api/health` reports `ok: true` and a sensible article count
- [ ] Sign in as an administrator
- [ ] Confirm the scheduler is running (Admin → Automation)

## Before upgrades

Take a snapshot and record the current commit/build. Migrations run automatically at boot and are
recorded in `_migrations`; a failed migration aborts in a transaction and leaves the schema intact,
but a verified backup is still the safe rollback.

## Retention and privacy

Deleting an account removes its sessions, bookmarks, history, comments and reports (see
`/api/account/delete`). Backups made before deletion still contain that data until they expire, so
keep the retention window in your privacy policy.
