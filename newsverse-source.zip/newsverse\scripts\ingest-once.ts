/**
 * Runs one collection pass over every enabled source, outside the web server.
 * Useful for cron, CI smoke tests and local debugging.
 */
import { ensureBootstrapped } from "../src/server/db/bootstrap";
import { all } from "../src/server/db";
import { ingestSource } from "../src/server/ingest/pipeline";

async function main() {
  ensureBootstrapped();
  const sources = all<{ id: string; name: string }>("SELECT id, name FROM sources WHERE enabled = 1 ORDER BY name");
  if (!sources.length) {
    console.log("No enabled sources. Add one in the admin panel first.");
    return;
  }
  for (const source of sources) {
    process.stdout.write(`${source.name}: `);
    try {
      const result = await ingestSource(source.id);
      console.log(
        `fetched ${result.fetched} · accepted ${result.accepted} · duplicates ${result.duplicates} · published ${result.published} · pending ${result.pending}` +
          (result.error ? ` · error: ${result.error}` : ""),
      );
    } catch (err) {
      console.log(`failed — ${(err as Error).message}`);
    }
  }
}

main();
