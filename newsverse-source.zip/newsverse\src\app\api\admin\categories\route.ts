import { guardAdmin } from "@/server/adminGuard";
import { json, parseBody, handleError } from "@/server/http";
import { categorySchema } from "@/lib/validation";
import { upsertCategory } from "@/server/repo/admin";
import { audit } from "@/server/auth";

export async function POST(request: Request) {
  try {
    const user = await guardAdmin(request);
    const input = await parseBody(request, categorySchema);
    const id = upsertCategory(input);
    audit({ actor: user, action: "category.upsert", entity: "category", entityId: id, meta: { slug: input.slug } });
    return json({ ok: true, id });
  } catch (err) {
    return handleError(err);
  }
}
