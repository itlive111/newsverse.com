import { NextResponse } from "next/server";
import { ZodError } from "zod";
import { AuthError } from "@/server/auth";

export function json(data: unknown, status = 200): NextResponse {
  return NextResponse.json(data, {
    status,
    headers: { "cache-control": "no-store" },
  });
}

export function fail(message: string, status = 400, extra?: Record<string, unknown>): NextResponse {
  return json({ ok: false, error: message, ...extra }, status);
}

export async function parseBody<T>(request: Request, schema: { parse: (v: unknown) => T }): Promise<T> {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    throw new HttpError(400, "Invalid JSON body");
  }
  return schema.parse(body);
}

export class HttpError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

export function handleError(err: unknown): NextResponse {
  if (err instanceof AuthError) return fail(err.message, err.status);
  if (err instanceof HttpError) return fail(err.message, err.status);
  if (err instanceof ZodError) {
    return fail("Validation failed", 422, {
      issues: err.issues.map((i) => ({ path: i.path.join("."), message: i.message })),
    });
  }
  console.error("[newsverse] api error:", err);
  return fail("Internal server error", 500);
}
