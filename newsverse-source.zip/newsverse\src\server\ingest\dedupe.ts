import { sha256 } from "@/server/lib/text";

const STOPWORDS = new Set([
  "the", "a", "an", "and", "or", "of", "to", "in", "on", "for", "with", "as", "at",
  "by", "from", "is", "are", "was", "were", "be", "been", "it", "its", "this", "that",
  "va", "ham", "bilan", "uchun", "bu", "bir", "da", "dan", "ning", "yangi", "как",
  "и", "в", "на", "с", "по", "что", "это", "для", "из", "не", "о", "об",
]);

/** Lowercase, strip accents/punctuation, collapse whitespace. */
export function normalizeTitle(title: string): string {
  return title
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[‘’ʻ`"“”«»]/g, "")
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function titleTokens(title: string): string[] {
  return normalizeTitle(title)
    .split(" ")
    .filter((w) => w.length > 2 && !STOPWORDS.has(w));
}

export function titleHash(title: string): string {
  return sha256(titleTokens(title).sort().join(" "));
}

/** Jaccard similarity of title token sets, 0..1. */
export function titleSimilarity(a: string, b: string): number {
  const ta = new Set(titleTokens(a));
  const tb = new Set(titleTokens(b));
  if (!ta.size || !tb.size) return 0;
  let intersection = 0;
  for (const token of ta) if (tb.has(token)) intersection += 1;
  return intersection / (ta.size + tb.size - intersection);
}

/**
 * Cheap, deterministic "event key" used to group coverage of the same event
 * across publishers. Not a semantic model — it groups on shared rare tokens.
 */
export function eventKey(title: string, topN = 3): string {
  const freq = new Map<string, number>();
  for (const token of titleTokens(title)) freq.set(token, (freq.get(token) ?? 0) + 1);
  const ranked = [...freq.entries()]
    .filter(([token]) => token.length > 3)
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
    .slice(0, topN)
    .map(([token]) => token)
    .sort();
  return ranked.length ? sha256(ranked.join("|")).slice(0, 16) : "";
}

/** Titles sharing >= 55% of tokens are treated as the same story. */
export const NEAR_DUPLICATE_THRESHOLD = 0.55;

export function isNearDuplicate(a: string, b: string): boolean {
  return titleSimilarity(a, b) >= NEAR_DUPLICATE_THRESHOLD;
}
