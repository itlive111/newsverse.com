import Link from "next/link";
import type { ArticleCard } from "@/server/repo/content";
import { articlePath } from "@/lib/ui";
import { t, type Locale } from "@/i18n";

export function BreakingTicker({ articles, locale }: { articles: ArticleCard[]; locale: Locale }) {
  if (!articles.length) return null;
  const items = [...articles, ...articles];
  return (
    <div className="border-y bg-brand/[0.06]" style={{ borderColor: "var(--line)" }}>
      <div className="container-nv flex items-center gap-3 py-2.5">
        <span className="badge-breaking shrink-0">
          <span className="h-1.5 w-1.5 rounded-full bg-white animate-pulseDot" />
          {t(locale, "home.live")}
        </span>
        <span className="hidden shrink-0 text-[11px] font-bold uppercase tracking-widest text-brand sm:inline">
          {t(locale, "home.breaking")}
        </span>
        <div className="group relative flex-1 overflow-hidden">
          <div className="flex w-max animate-ticker gap-10 group-hover:[animation-play-state:paused]">
            {items.map((article, index) => (
              <Link
                key={`${article.id}-${index}`}
                href={articlePath(locale, article.slug)}
                className="whitespace-nowrap text-[13px] font-medium hover:text-brand"
              >
                {article.title}
                {article.source_name && <span className="ml-2 text-[11px] subtle">{article.source_name}</span>}
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
