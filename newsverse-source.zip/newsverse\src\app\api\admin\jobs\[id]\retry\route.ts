import { guardAdmin } from "@/server/adminGuard";
import { json, handleError } from "@/server/http";
import { retryJob } from "@/server/repo/admin";
import { audit } from "@/server/auth";

type Ctx = { params: Promise<{ id: string }> };

export async function POST(request: Request, ctx: Ctx) {
  try {
    const user = await guardAdmin(request);
    const { id } = await ctx.params;
    retryJob(id);
    audit({ actor: user, action: "job.retry", entity: "job", entityId: id });
    return json({ ok: true });
  } catch (err) {
    return handleError(err);
  }
}
