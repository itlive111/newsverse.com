import { ensureBootstrapped } from "@/server/db/bootstrap";
import { startScheduler } from "@/server/ingest/jobs";

let started = false;

/**
 * One-time server bootstrap: migrate/seed the database, then start the
 * durable scheduler loop. Safe to call more than once per process.
 */
export async function bootstrapServer(): Promise<void> {
  if (started) return;
  started = true;
  ensureBootstrapped();
  startScheduler();
}
