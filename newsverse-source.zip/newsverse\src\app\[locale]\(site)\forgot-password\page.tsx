import type { Metadata } from "next";
import { resolveLocale, t, type Locale } from "@/i18n";
import { ForgotForm } from "@/components/auth-forms";

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const locale = resolveLocale((await params).locale);
  return { title: t(locale, "auth.resetTitle"), robots: { index: false } };
}

export default async function ForgotPage({ params }: { params: Promise<{ locale: string }> }) {
  const locale = resolveLocale((await params).locale) as Locale;
  return (
    <div className="container-nv max-w-md py-12">
      <h1 className="font-display text-3xl font-extrabold">{t(locale, "auth.resetTitle")}</h1>
      <p className="mt-2 text-sm subtle">{t(locale, "auth.resetSent")}</p>
      <div className="card mt-6 p-6">
        <ForgotForm locale={locale} />
      </div>
    </div>
  );
}
