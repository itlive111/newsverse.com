import { get, run, nowIso } from "@/server/db";
import { audit, clientIpFromHeaders, rateLimit, requireUser, verifyPassword } from "@/server/auth";
import { guardOrigin } from "@/server/adminGuard";
import { json, fail, parseBody, handleError } from "@/server/http";
import { emailChangeSchema } from "@/lib/validation";
import { issueToken, logVerificationLink, verificationLink } from "@/server/lib/verification";

/**
 * Starts an e-mail change. The address is not switched until the user clicks
 * the verification link sent to the NEW address, so a hijacked session cannot
 * silently move the account.
 */
export async function POST(request: Request) {
  try {
    guardOrigin(request);
    const user = await requireUser();
    const ip = clientIpFromHeaders(request.headers) ?? "unknown";
    if (!rateLimit(`emailchange:${user.id}:${ip}`, 5, 60 * 60 * 1000)) return fail("rate_limited", 429);

    const input = await parseBody(request, emailChangeSchema);
    const row = get<{ password_hash: string; email: string }>("SELECT password_hash, email FROM users WHERE id = ?", user.id);
    if (!row || !verifyPassword(input.password, row.password_hash)) return fail("invalid_credentials", 400);
    if (input.newEmail === row.email.toLowerCase()) return fail("email_taken", 409);
    if (get("SELECT id FROM users WHERE email = ? COLLATE NOCASE AND id <> ?", input.newEmail, user.id)) {
      return fail("email_taken", 409);
    }

    const token = issueToken(user.id, "email_change", { email: input.newEmail });
    run("UPDATE users SET pending_email = ?, updated_at = ? WHERE id = ?", input.newEmail, nowIso(), user.id);
    logVerificationLink(input.newEmail, verificationLink(token));
    audit({ actor: user, action: "auth.email_change_requested", entity: "user", entityId: user.id });
    return json({ ok: true, sent: true });
  } catch (err) {
    return handleError(err);
  }
}
