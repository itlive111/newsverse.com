import { adminGate } from "@/server/adminPage";
import { notFound } from "next/navigation";
import { formatDate, isLocale, t } from "@/i18n";
import { listSubscribers } from "@/server/repo/admin";
import { getBoolSetting } from "@/server/repo/settings";
import { AdminSection, EmptyRow, StatCard, StatusBadge, Td, Th } from "@/components/admin/ui";

export const dynamic = "force-dynamic";

export default async function AdminNewsletter({ params }: { params: Promise<{ locale: string }> }) {
  const { locale: raw } = await params;
  if (!isLocale(raw)) notFound();
  const locale = raw;
  await adminGate("admin");
  const subscribers = listSubscribers();
  const active = subscribers.filter((s: Record<string, unknown>) => !s.unsubscribed_at).length;

  return (
    <div className="space-y-4">
      <h1 className="font-display text-2xl font-black tracking-tight">{t(locale, "admin.newsletter")}</h1>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        <StatCard label="Subscribers" value={active} accent />
        <StatCard label="Unsubscribed" value={subscribers.length - active} />
        <StatCard label="Signup enabled" value={getBoolSetting("newsletter_enabled", true) ? "yes" : "no"} />
      </div>

      <AdminSection
        title={t(locale, "admin.newsletter")}
        action={<span className="text-[11px] subtle">Export is not enabled in this deployment; query the database for a full export.</span>}
      >
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead><tr><Th>{t(locale, "auth.email")}</Th><Th>{t(locale, "common.language")}</Th><Th>Confirmed</Th><Th>{t(locale, "admin.status")}</Th><Th>Joined</Th></tr></thead>
            <tbody>
              {subscribers.map((s: Record<string, string>, i: number) => (
                <tr key={`${s.email}-${i}`} className="border-t" style={{ borderColor: "var(--line)" }}>
                  <Td className="break-all">{s.email}</Td>
                  <Td className="uppercase subtle">{s.locale}</Td>
                  <Td className="subtle">{s.confirmed === "1" || s.confirmed ? "yes" : "no"}</Td>
                  <Td><StatusBadge status={s.unsubscribed_at ? "archived" : "active"} /></Td>
                  <Td className="whitespace-nowrap subtle">{formatDate(s.created_at, locale)}</Td>
                </tr>
              ))}
              {!subscribers.length && <EmptyRow colSpan={5} text={t(locale, "common.noResults")} />}
            </tbody>
          </table>
        </div>
      </AdminSection>
    </div>
  );
}
