import type { Metadata } from "next";
import { notFound } from "next/navigation";
import "../globals.css";
import { isLocale, localeTags, locales, resolveLocale, t, localeNames } from "@/i18n";
import { ThemeScript } from "@/components/theme-script";
import { siteUrl } from "@/lib/ui";

const site = siteUrl();

export function generateStaticParams() {
  return locales.map((locale) => ({ locale }));
}

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const { locale: raw } = await params;
  const locale = resolveLocale(raw);
  const languages: Record<string, string> = {};
  for (const l of locales) languages[l] = `/${l}`;
  languages["x-default"] = "/uz";
  return {
    metadataBase: new URL(site),
    title: {
      default: t(locale, "meta.homeTitle"),
      template: `%s · NewsVerse`,
    },
    description: t(locale, "meta.homeDesc"),
    applicationName: "NewsVerse",
    alternates: { canonical: `/${locale}`, languages },
    openGraph: {
      type: "website",
      siteName: "NewsVerse",
      title: t(locale, "meta.homeTitle"),
      description: t(locale, "meta.homeDesc"),
      locale: localeTags[locale],
      url: `/${locale}`,
      images: [{ url: "/brand/og.png", width: 1200, height: 630, alt: "NewsVerse" }],
    },
    twitter: {
      card: "summary_large_image",
      title: t(locale, "meta.homeTitle"),
      description: t(locale, "meta.homeDesc"),
      images: ["/brand/og.png"],
    },
    robots: { index: true, follow: true },
    icons: { icon: "/brand/icon-192.png", apple: "/brand/icon-512.png" },
    manifest: "/manifest.webmanifest",
    other: { "content-language": localeNames[locale] },
  };
}

export default async function LocaleLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: Promise<{ locale: string }>;
}) {
  const { locale: raw } = await params;
  if (!isLocale(raw)) notFound();
  const locale = raw;
  return (
    <html lang={localeTags[locale]} suppressHydrationWarning>
      <body className="min-h-screen antialiased">
        <ThemeScript />
        <a
          href="#main"
          className="sr-only focus:not-sr-only focus:fixed focus:left-3 focus:top-3 focus:z-[100] focus:rounded-lg focus:bg-brand focus:px-4 focus:py-2 focus:text-sm focus:font-semibold focus:text-white"
        >
          {t(locale, "nav.home")}
        </a>
        {children}
      </body>
    </html>
  );
}
