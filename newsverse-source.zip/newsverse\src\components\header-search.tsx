"use client";

import { useState } from "react";
import { IconSearch, IconClose } from "@/components/icons";
import { SearchBox } from "@/components/search-box";
import type { Locale } from "@/i18n";

export function HeaderSearch({
  locale,
  placeholder,
  label,
}: {
  locale: Locale;
  placeholder: string;
  label: string;
}) {
  const [open, setOpen] = useState(false);
  return (
    <div className="flex items-center gap-2">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-label={label}
        aria-expanded={open}
        className="flex h-9 w-9 items-center justify-center rounded-full border text-[color:var(--muted)] transition hover:border-brand hover:text-brand"
        style={{ borderColor: "var(--line)" }}
      >
        {open ? <IconClose size={16} /> : <IconSearch size={16} />}
      </button>
      {open && (
        <div className="absolute inset-x-0 top-full z-50 border-b p-3 lg:relative lg:inset-auto lg:top-auto lg:w-72 lg:border-0 lg:p-0" style={{ background: "var(--bg)", borderColor: "var(--line)" }}>
          <SearchBox locale={locale} placeholder={placeholder} label={label} size="sm" autoFocus />
        </div>
      )}
    </div>
  );
}
