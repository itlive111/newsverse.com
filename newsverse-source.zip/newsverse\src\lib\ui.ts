function toPlainText(content: string): string {
  return content
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<\/(p|div|h[1-6]|li|blockquote)>/gi, "\n\n")
    .replace(/<[^>]*>/g, " ")
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'")
    .replace(/[ \t]+/g, " ")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

export function paragraphs(content: string | null | undefined): string[] {
  if (!content) return [];
  const text = toPlainText(content);
  if (!text) return [];
  const blocks = text.split(/\n{2,}/).map((b) => b.trim()).filter(Boolean);
  if (blocks.length <= 1) {
    // Single long block: split into readable paragraphs at sentence boundaries.
    const sentences = text.match(/[^.!?]+[.!?]+["”’]?/g) ?? [text];
    const out: string[] = [];
    let current = "";
    for (const sentence of sentences) {
      current += sentence;
      if (current.length > 320) {
        out.push(current.trim());
        current = "";
      }
    }
    if (current.trim()) out.push(current.trim());
    return out;
  }
  return blocks;
}

export function siteUrl(path = ""): string {
  const base = (process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000").replace(/\/$/, "");
  const clean = path.startsWith("/") ? path : `/${path}`;
  return `${base}${clean === "/" ? "" : clean}`;
}

export function articlePath(locale: string, slug: string): string {
  return `/${locale}/news/${slug}`;
}

export function categoryPath(locale: string, slug: string): string {
  return `/${locale}/category/${slug}`;
}

export function initials(name: string): string {
  return name
    .split(/\s+/)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase() ?? "")
    .join("");
}

export function readingLabel(minutes: number, suffix: string): string {
  return `${minutes} ${suffix}`;
}

export function pluralUz(count: number): string {
  return count === 1 ? "yangilik" : "yangilik";
}
