import { describe, expect, test } from "vitest";
import { eventKey, normalizeTitle, titleHash, titleSimilarity } from "@/server/ingest/dedupe";

describe("duplicate detection", () => {
  test("normalizes punctuation and case", () => {
    expect(normalizeTitle("Apple’s New iPhone — Review!")).toBe("apples new iphone review");
  });

  test("identical titles hash identically regardless of word order", () => {
    expect(titleHash("Central bank raises interest rates")).toBe(titleHash("interest rates central bank raises"));
  });

  test("near-duplicate headlines score high", () => {
    const score = titleSimilarity(
      "Central bank raises interest rates for third time this year",
      "Central bank raises interest rates for a third time in 2026",
    );
    expect(score).toBeGreaterThan(0.5);
  });

  test("unrelated headlines score low", () => {
    const score = titleSimilarity(
      "Central bank raises interest rates",
      "National team wins the cup final",
    );
    expect(score).toBeLessThan(0.2);
  });

  test("event key is deterministic and ignores stopwords", () => {
    const a = eventKey("The president meets the chancellor in Berlin");
    expect(a).toBe(eventKey("President meets chancellor in Berlin"));
    expect(a.length).toBeGreaterThan(0);
  });
});
