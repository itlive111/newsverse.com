import type { MetadataRoute } from "next";
import { siteUrl } from "@/lib/ui";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      {
        userAgent: "*",
        allow: "/",
        disallow: [
          "/api/",
          "/admin",
          "/*/admin",
          "/*/account",
          "/*/saved",
          "/*/search",
          "/*/login",
          "/*/register",
          "/reset-password",
          "/*/reset-password",
          "/*/forgot-password",
        ],
      },
    ],
    sitemap: siteUrl("/sitemap.xml"),
    host: siteUrl(),
  };
}
