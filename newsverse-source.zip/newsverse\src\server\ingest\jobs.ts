import crypto from "node:crypto";
import { all, get, run, nowIso } from "@/server/db";
import { ensureBootstrapped } from "@/server/db/bootstrap";
import { getBoolSetting, getNumberSetting } from "@/server/repo/settings";
import { ingestSource, logIngestion, type SourceRow } from "@/server/ingest/pipeline";

export type JobStatus = "queued" | "running" | "succeeded" | "failed";

export type JobRow = {
  id: string;
  type: string;
  source_id: string | null;
  status: JobStatus;
  attempts: number;
  max_attempts: number;
  next_run_at: string;
  locked_at: string | null;
  last_error: string | null;
  payload: string | null;
  idempotency_key: string | null;
  created_at: string;
  updated_at: string;
  finished_at: string | null;
};

/* -------------------------------------------------------------------------- */
/* Queue                                                                      */
/* -------------------------------------------------------------------------- */

export function enqueueJob(opts: {
  type: string;
  sourceId?: string | null;
  idempotencyKey?: string | null;
  payload?: Record<string, unknown>;
  nextRunAt?: string;
  maxAttempts?: number;
}): string | null {
  ensureBootstrapped();
  if (opts.idempotencyKey) {
    const existing = get<{ id: string }>("SELECT id FROM jobs WHERE idempotency_key = ?", opts.idempotencyKey);
    if (existing) return null;
  }
  const id = crypto.randomUUID();
  const now = nowIso();
  run(
    `INSERT INTO jobs (id, type, source_id, status, attempts, max_attempts, next_run_at, payload, idempotency_key, created_at, updated_at)
     VALUES (?,?,?, 'queued', 0, ?, ?, ?, ?, ?, ?)`,
    id, opts.type, opts.sourceId ?? null, opts.maxAttempts ?? 4, opts.nextRunAt ?? now,
    opts.payload ? JSON.stringify(opts.payload) : null, opts.idempotencyKey ?? null, now, now,
  );
  return id;
}

function backoffIso(attempts: number): string {
  const minutes = Math.min(60, Math.pow(2, Math.max(1, attempts)) * 2);
  return new Date(Date.now() + minutes * 60000).toISOString();
}

function raiseAlert(message: string, severity: "warning" | "critical"): void {
  run(
    "INSERT INTO alerts (id, kind, severity, message, created_at) VALUES (?,?,?,?,?)",
    crypto.randomUUID(), "ingestion", severity, message.slice(0, 400), nowIso(),
  );
}

/** Claims and executes up to `limit` due jobs. Safe to call from cron or the scheduler. */
export async function runDueJobs(limit = 2): Promise<{ ran: number; failed: number }> {
  let ran = 0;
  let failed = 0;
  for (let i = 0; i < limit; i += 1) {
    const job = get<JobRow>(
      "SELECT * FROM jobs WHERE status = 'queued' AND next_run_at <= ? ORDER BY next_run_at ASC LIMIT 1",
      nowIso(),
    );
    if (!job) break;
    const claimed = run(
      "UPDATE jobs SET status = 'running', locked_at = ?, attempts = attempts + 1, updated_at = ? WHERE id = ? AND status = 'queued'",
      nowIso(), nowIso(), job.id,
    );
    if (claimed.changes === 0) continue;
    ran += 1;
    try {
      await executeJob({ ...job, attempts: job.attempts + 1 });
      run("UPDATE jobs SET status = 'succeeded', finished_at = ?, locked_at = NULL, updated_at = ?, last_error = NULL WHERE id = ?", nowIso(), nowIso(), job.id);
    } catch (err) {
      failed += 1;
      const message = (err as Error).message.slice(0, 400);
      const attempts = job.attempts + 1;
      if (attempts >= job.max_attempts) {
        run("UPDATE jobs SET status = 'failed', finished_at = ?, locked_at = NULL, last_error = ?, updated_at = ? WHERE id = ?", nowIso(), message, nowIso(), job.id);
        logIngestion({ sourceId: job.source_id, jobId: job.id, level: "error", message: `Job failed permanently: ${message}` });
        raiseAlert(`Ingestion job failed after ${attempts} attempts: ${message}`, "critical");
      } else {
        run("UPDATE jobs SET status = 'queued', next_run_at = ?, locked_at = NULL, last_error = ?, updated_at = ? WHERE id = ?", backoffIso(attempts), message, nowIso(), job.id);
        logIngestion({ sourceId: job.source_id, jobId: job.id, level: "warn", message: `Job attempt ${attempts} failed, retrying: ${message}` });
      }
    }
  }
  return { ran, failed };
}

async function executeJob(job: JobRow): Promise<void> {
  if (job.type === "ingest_source") {
    if (!job.source_id) throw new Error("Job missing source_id");
    const result = await ingestSource(job.source_id, job.id);
    const source = get<SourceRow>("SELECT * FROM sources WHERE id = ?", job.source_id);
    triggersourceHealthAlert(source);
    if (!source) return;
    if (result.error) throw new Error(result.error);
    return;
  }
  throw new Error(`Unknown job type: ${job.type}`);
}

function triggersourceHealthAlert(source: SourceRow | undefined): void {
  if (!source) return;
  const threshold = getNumberSetting("failure_alert_threshold", 3);
  if (source.consecutive_failures >= threshold && getBoolSetting("notify_on_failure", true)) {
    const existing = get<{ id: string }>(
      "SELECT id FROM alerts WHERE kind = 'source_health' AND message LIKE ? AND resolved_at IS NULL",
      `%${source.name}%`,
    );
    if (!existing) {
      raiseAlert(`Source "${source.name}" failed ${source.consecutive_failures} times in a row: ${source.last_error ?? "unknown error"}`, "warning");
    }
  }
}

/* -------------------------------------------------------------------------- */
/* Scheduler                                                                  */
/* -------------------------------------------------------------------------- */

const SCHEDULER_INTERVAL_MS = Number(process.env.INGEST_TICK_MS ?? 20000);

type SchedulerGlobal = {
  timer?: NodeJS.Timeout;
  startedAt?: string;
  lastTickAt?: string;
  busy?: boolean;
  lastResult?: { enqueued: number; ran: number; failed: number };
  ticks?: number;
};

const g = globalThis as unknown as { __nvScheduler?: SchedulerGlobal };
function state(): SchedulerGlobal {
  g.__nvScheduler ??= {};
  return g.__nvScheduler;
}

/** Enqueues due sources, then processes queued jobs. No browser involvement. */
export async function schedulerTick(): Promise<{ enqueued: number; ran: number; failed: number }> {
  ensureBootstrapped();
  const s = state();
  s.lastTickAt = nowIso();
  s.ticks = (s.ticks ?? 0) + 1;
  let enqueued = 0;
  if (!getBoolSetting("ingest_enabled", true)) {
    const result = { enqueued, ran: 0, failed: 0 };
    s.lastResult = result;
    return result;
  }
  const sources = all<SourceRow>("SELECT * FROM sources WHERE enabled = 1");
  for (const source of sources) {
    const locked = get(
      "SELECT 1 AS x FROM jobs WHERE source_id = ? AND status IN ('queued','running')",
      source.id,
    );
    if (locked) continue;
    const dueAt = source.last_run_at
      ? new Date(source.last_run_at).getTime() + source.interval_minutes * 60000
      : 0;
    if (dueAt > Date.now()) continue;
    const hourBucket = new Date().toISOString().slice(0, 13);
    const id = enqueueJob({
      type: "ingest_source",
      sourceId: source.id,
      idempotencyKey: `ingest:${source.id}:${hourBucket}`,
    });
    if (id) enqueued += 1;
  }
  const { ran, failed } = await runDueJobs(Number(process.env.INGEST_MAX_JOBS_PER_TICK ?? 2));
  const result = { enqueued, ran, failed };
  s.lastResult = result;
  return result;
}

export function startScheduler(): void {
  const s = state();
  if (s.timer) return;
  if (process.env.INGEST_AUTO_START === "0") return;
  if (process.env.NEXT_PHASE === "phase-production-build") return;
  s.startedAt = nowIso();
  s.timer = setInterval(() => {
    if (s.busy) return;
    s.busy = true;
    schedulerTick()
      .catch((err) => console.error("[newsverse] scheduler tick failed:", err))
      .finally(() => {
        s.busy = false;
      });
  }, SCHEDULER_INTERVAL_MS);
  s.timer.unref?.();
  setTimeout(() => {
    schedulerTick().catch((err) => console.error("[newsverse] initial tick failed:", err));
  }, 2500).unref?.();
  console.log(`[newsverse] scheduler started (every ${Math.round(SCHEDULER_INTERVAL_MS / 1000)}s)`);
}

export function schedulerInfo() {
  const s = state();
  return {
    running: !!s.timer,
    startedAt: s.startedAt ?? null,
    lastTickAt: s.lastTickAt ?? null,
    lastResult: s.lastResult ?? null,
    ticks: s.ticks ?? 0,
    intervalMs: SCHEDULER_INTERVAL_MS,
  };
}

export function jobStats() {
  const rows = all<{ status: string; c: number }>("SELECT status, COUNT(*) AS c FROM jobs GROUP BY status");
  const stats: Record<string, number> = { queued: 0, running: 0, succeeded: 0, failed: 0 };
  for (const row of rows) stats[row.status] = row.c;
  return stats;
}
