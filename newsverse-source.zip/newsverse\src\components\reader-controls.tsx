"use client";

import { useEffect, useState } from "react";
import { t, type Locale } from "@/i18n";

export function ReaderControls({ locale }: { locale: Locale }) {
  const [size, setSize] = useState(17);

  useEffect(() => {
    const saved = Number(localStorage.getItem("nv_font") || "17");
    if (saved >= 14 && saved <= 24) setSize(saved);
  }, []);

  useEffect(() => {
    document.documentElement.style.setProperty("--reader-font", `${size}px`);
    try {
      localStorage.setItem("nv_font", String(size));
    } catch { /* ignore */ }
  }, [size]);

  return (
    <div className="no-print flex items-center gap-1 text-[11px] subtle">
      <span className="mr-1 uppercase tracking-wider">{t(locale, "article.fontSize")}</span>
      <button
        type="button"
        onClick={() => setSize((s) => Math.max(14, s - 1))}
        aria-label="A−"
        className="h-7 w-7 rounded border text-xs font-bold hover:border-brand hover:text-brand"
        style={{ borderColor: "var(--line)" }}
      >
        A−
      </button>
      <button
        type="button"
        onClick={() => setSize((s) => Math.min(24, s + 1))}
        aria-label="A+"
        className="h-7 w-7 rounded border text-xs font-bold hover:border-brand hover:text-brand"
        style={{ borderColor: "var(--line)" }}
      >
        A+
      </button>
      <button type="button" onClick={() => window.print()} className="ml-1 rounded border px-2 py-1 hover:border-brand hover:text-brand" style={{ borderColor: "var(--line)" }}>
        {t(locale, "article.print")}
      </button>
    </div>
  );
}
