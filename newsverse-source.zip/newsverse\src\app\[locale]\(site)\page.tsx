import Link from "next/link";
import { resolveLocale, t, formatNumber, type Locale } from "@/i18n";
import { getCurrentUser } from "@/server/auth";
import {
  getBreaking,
  getMostRead,
  getPersonalized,
  getRecentlyUpdated,
  getTrending,
  getEditorsPicks,
  listArticles,
  listCategories,
  listTagsWithCounts,
  listVideos,
} from "@/server/repo/content";
import { getBoolSetting } from "@/server/repo/settings";
import { ArticleCard, VideoCard } from "@/components/article-card";
import { BreakingTicker } from "@/components/breaking-ticker";
import { HeroCarousel } from "@/components/hero-carousel";
import { SearchBox } from "@/components/search-box";
import { SectionHeader, Panel, EmptyState } from "@/components/layout-parts";
import { NewsletterForm } from "@/components/newsletter-form";
import { CategoryIcon, IconChart, IconEye } from "@/components/icons";

type Range = "day" | "week" | "month";

export default async function HomePage({
  params,
  searchParams,
}: {
  params: Promise<{ locale: string }>;
  searchParams: Promise<{ range?: string }>;
}) {
  const locale = resolveLocale((await params).locale) as Locale;
  const range = ((await searchParams).range as Range) || "day";
  const user = await getCurrentUser();

  const breaking = getBreaking(locale, 6);
  const featured = listArticles({ locale, limit: 5 });
  const latest = listArticles({ locale, limit: 25, offset: 0 });
  const trending = getTrending(locale, 5);
  const mostRead = getMostRead(locale, range, 5);
  const picks = getEditorsPicks(locale, 3);
  const local = listArticles({ locale, categorySlug: "uzbekistan", limit: 4 });
  const world = listArticles({ locale, categorySlug: "world", limit: 4 });
  const videos = listVideos(locale, 4);
  const tags = listTagsWithCounts(12);
  const updated = getRecentlyUpdated(locale, 4);
  const categories = listCategories(locale);

  let interests: string[] = [];
  try {
    interests = user ? (JSON.parse(user.interests) as string[]) : [];
  } catch {
    interests = [];
  }
  const personalized = interests.length ? getPersonalized(locale, interests, 6) : [];
  const marketsOn = getBoolSetting("markets_widget", false);

  const hero = featured.slice(0, 4);
  const feed = latest.filter((a) => !hero.some((h) => h.id === a.id)).slice(0, 9);
  const sidebarLatest = latest.slice(4, 9);

  if (!latest.length) {
    return (
      <div className="container-nv py-16">
        <EmptyState
          title={t(locale, "state.emptyTitle")}
          body={t(locale, "state.emptyBody")}
          icon={<CategoryIcon name="globe" size={22} />}
        />
      </div>
    );
  }

  return (
    <div>
      <BreakingTicker articles={breaking} locale={locale} />

      <div className="container-nv">
        <section className="grid gap-5 py-6 lg:grid-cols-12">
          <div className="space-y-5 lg:col-span-8">
            <HeroCarousel articles={hero} locale={locale} />
            <div className="grid gap-4 sm:grid-cols-2">
              {latest.slice(5, 7).map((article) => (
                <ArticleCard key={article.id} article={article} locale={locale} variant="large" />
              ))}
            </div>
          </div>
          <aside className="lg:col-span-4">
            <Panel title={t(locale, "home.latest")} className="mb-4">
              <div className="space-y-3">
                {sidebarLatest.map((article) => (
                  <ArticleCard key={article.id} article={article} locale={locale} variant="compact" />
                ))}
              </div>
            </Panel>
            <Panel title={t(locale, "home.trending")}>
              <ol className="space-y-3">
                {trending.map((article, index) => (
                  <li key={article.id} className="flex gap-3">
                    <span className="font-display text-xl font-black leading-none text-brand/70">
                      {String(index + 1).padStart(2, "0")}
                    </span>
                    <div>
                      <Link href={`/${locale}/news/${article.slug}`} className="line-clamp-2 text-sm font-semibold leading-snug hover:text-brand">
                        {article.title}
                      </Link>
                      <p className="mt-1 inline-flex items-center gap-1 text-[10px] uppercase tracking-wide subtle">
                        <IconEye size={11} /> {formatNumber(article.view_count, locale)}
                      </p>
                    </div>
                  </li>
                ))}
              </ol>
              <Link href={`/${locale}/trending`} className="mt-3 inline-block text-xs font-semibold text-brand hover:underline">
                {t(locale, "nav.trending")} →
              </Link>
            </Panel>
          </aside>
        </section>

        <section className="pb-8">
          <div className="card grid gap-4 p-4 sm:grid-cols-[1fr_auto] sm:items-center sm:p-5">
            <SearchBox locale={locale} placeholder={t(locale, "search.placeholder")} label={t(locale, "nav.search")} size="md" />
            <div className="flex flex-wrap gap-1.5">
              {tags.slice(0, 6).map((tag) => (
                <Link key={tag.slug} href={`/${locale}/search?tag=${tag.slug}`} className="chip hover:border-brand hover:text-brand">
                  #{tag.name}
                </Link>
              ))}
            </div>
          </div>
        </section>

        <section className="grid gap-6 pb-10 lg:grid-cols-12">
          <div className="lg:col-span-8">
            <SectionHeader
              title={t(locale, "home.latest")}
              href={`/${locale}/latest`}
              linkLabel={t(locale, "common.readMore")}
            />
            <div className="grid gap-4 sm:grid-cols-2">
              {feed.map((article) => (
                <ArticleCard key={article.id} article={article} locale={locale} />
              ))}
            </div>
            <div className="mt-5 text-center">
              <Link href={`/${locale}/latest`} className="btn-ghost">{t(locale, "home.loadMore")}</Link>
            </div>
          </div>
          <aside className="space-y-4 lg:col-span-4">
            <Panel title={t(locale, "home.mostRead")}>
              <div className="mb-3 flex gap-1">
                {(["day", "week", "month"] as Range[]).map((r) => (
                  <Link
                    key={r}
                    href={`?range=${r}`}
                    className={`rounded-full px-3 py-1 text-[11px] font-bold uppercase tracking-wide ${
                      range === r ? "bg-brand text-white" : "subtle hover:text-brand"
                    }`}
                  >
                    {t(locale, `home.${r}` as "home.day" | "home.week" | "home.month")}
                  </Link>
                ))}
              </div>
              <ol className="space-y-2.5">
                {mostRead.map((article, i) => (
                  <li key={article.id} className="flex gap-2 text-sm">
                    <span className="font-bold text-brand">{i + 1}</span>
                    <Link href={`/${locale}/news/${article.slug}`} className="line-clamp-2 font-medium hover:text-brand">
                      {article.title}
                    </Link>
                  </li>
                ))}
              </ol>
            </Panel>

            {marketsOn && (
              <Panel title={t(locale, "widget.markets")}>
                <p className="text-xs subtle">{t(locale, "widget.unavailable")}</p>
              </Panel>
            )}

            {updated.length > 0 && (
              <Panel title={t(locale, "home.updated")}>
                <div className="space-y-3">
                  {updated.map((article) => (
                    <ArticleCard key={article.id} article={article} locale={locale} variant="compact" />
                  ))}
                </div>
              </Panel>
            )}

            <Panel title={t(locale, "newsletter.title")}>
              <p className="mb-3 text-xs subtle">{t(locale, "newsletter.desc")}</p>
              <NewsletterForm locale={locale} compact />
            </Panel>
          </aside>
        </section>

        {personalized.length > 0 && (
          <section className="pb-10">
            <SectionHeader title={t(locale, "home.recommended")} hint={t(locale, "home.personalizedHint")} />
            <div className="no-scrollbar flex gap-4 overflow-x-auto pb-2">
              {personalized.map((article) => (
                <ArticleCard key={article.id} article={article} locale={locale} variant="rail" />
              ))}
            </div>
          </section>
        )}

        {picks.length > 0 && (
          <section className="pb-10">
            <SectionHeader title={t(locale, "home.picks")} />
            <div className="grid gap-4 md:grid-cols-3">
              {picks.map((article) => (
                <ArticleCard key={article.id} article={article} locale={locale} />
              ))}
            </div>
          </section>
        )}

        <section className="grid gap-8 pb-10 lg:grid-cols-2">
          <div>
            <SectionHeader
              title={t(locale, "home.local")}
              href={`/${locale}/category/uzbekistan`}
              linkLabel={t(locale, "common.all")}
            />
            {local.length ? (
              <div className="space-y-3">
                {local.slice(0, 1).map((a) => <ArticleCard key={a.id} article={a} locale={locale} variant="large" />)}
                {local.slice(1).map((a) => <ArticleCard key={a.id} article={a} locale={locale} variant="compact" />)}
              </div>
            ) : (
              <EmptyState title={t(locale, "state.emptyTitle")} body={t(locale, "category.none")} icon={<CategoryIcon name="flag" size={20} />} />
            )}
          </div>
          <div>
            <SectionHeader
              title={t(locale, "home.world")}
              href={`/${locale}/category/world`}
              linkLabel={t(locale, "common.all")}
            />
            {world.length ? (
              <div className="space-y-3">
                {world.slice(0, 1).map((a) => <ArticleCard key={a.id} article={a} locale={locale} variant="large" />)}
                {world.slice(1).map((a) => <ArticleCard key={a.id} article={a} locale={locale} variant="compact" />)}
              </div>
            ) : (
              <EmptyState title={t(locale, "state.emptyTitle")} body={t(locale, "category.none")} icon={<CategoryIcon name="globe" size={20} />} />
            )}
          </div>
        </section>

        {videos.length > 0 && (
          <section className="pb-10">
            <SectionHeader title={t(locale, "home.video")} />
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {videos.map((article) => (
                <VideoCard key={article.id} article={article} locale={locale} />
              ))}
            </div>
          </section>
        )}

        <section className="pb-14">
          <SectionHeader title={t(locale, "home.tags")} />
          <div className="flex flex-wrap gap-2">
            {tags.map((tag) => (
              <Link key={tag.slug} href={`/${locale}/search?tag=${tag.slug}`} className="chip hover:border-brand hover:text-brand">
                #{tag.name} <span className="text-[10px] opacity-60">{tag.count}</span>
              </Link>
            ))}
          </div>
        </section>

        <section className="pb-14">
          <SectionHeader title={t(locale, "nav.categories")} />
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-4">
            {categories.map((c) => (
              <Link
                key={c.slug}
                href={`/${locale}/category/${c.slug}`}
                className="card card-hover flex items-center gap-2.5 px-3.5 py-3 text-sm font-semibold"
              >
                <span className="flex h-8 w-8 items-center justify-center rounded-lg" style={{ background: `${c.color ?? "#FF1538"}1a`, color: c.color ?? "#FF1538" }}>
                  <CategoryIcon name={c.icon} size={16} />
                </span>
                {c.name}
              </Link>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
