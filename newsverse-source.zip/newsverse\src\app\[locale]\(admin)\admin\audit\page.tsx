import { adminGate } from "@/server/adminPage";
import { notFound } from "next/navigation";
import { formatDate, isLocale, t } from "@/i18n";
import { listAudit } from "@/server/repo/admin";
import { AdminSection, EmptyRow, Td, Th } from "@/components/admin/ui";

export const dynamic = "force-dynamic";

export default async function AdminAudit({ params }: { params: Promise<{ locale: string }> }) {
  const { locale: raw } = await params;
  if (!isLocale(raw)) notFound();
  const locale = raw;
  await adminGate("admin");
  const rows = listAudit(200);

  return (
    <div className="space-y-4">
      <div>
        <h1 className="font-display text-2xl font-black tracking-tight">{t(locale, "admin.audit")}</h1>
        <p className="text-xs subtle">
          Every privileged mutation is recorded with the acting account, target and timestamp. Logs are append-only.
        </p>
      </div>

      <AdminSection>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead><tr><Th>Time</Th><Th>Actor</Th><Th>Action</Th><Th>Entity</Th><Th>Meta</Th></tr></thead>
            <tbody>
              {rows.map((row: Record<string, string>, i: number) => (
                <tr key={row.id ?? i} className="border-t" style={{ borderColor: "var(--line)" }}>
                  <Td className="whitespace-nowrap subtle">{formatDate(row.created_at, locale)}</Td>
                  <Td className="break-all subtle">{row.actor_email ?? "system"}</Td>
                  <Td className="font-semibold">{row.action}</Td>
                  <Td className="subtle">{row.entity ?? "—"} {row.entity_id ? row.entity_id.slice(0, 8) : ""}</Td>
                  <Td className="max-w-xs break-all text-[10px] subtle">{row.meta ?? "—"}</Td>
                </tr>
              ))}
              {!rows.length && <EmptyRow colSpan={5} text={t(locale, "common.noResults")} />}
            </tbody>
          </table>
        </div>
      </AdminSection>
    </div>
  );
}
