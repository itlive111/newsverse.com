"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { IconSearch } from "@/components/icons";
import type { Locale } from "@/i18n";

type Suggestion = { title: string; slug: string; category_slug: string | null };

export function SearchBox({
  locale,
  placeholder,
  label,
  initial = "",
  size = "md",
  autoFocus = false,
}: {
  locale: Locale;
  placeholder: string;
  label: string;
  initial?: string;
  size?: "sm" | "md" | "lg";
  autoFocus?: boolean;
}) {
  const [value, setValue] = useState(initial);
  const [results, setResults] = useState<Suggestion[]>([]);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const router = useRouter();
  const boxRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (value.trim().length < 2) {
      setResults([]);
      return;
    }
    const controller = new AbortController();
    const timer = setTimeout(async () => {
      setLoading(true);
      try {
        const res = await fetch(
          `/api/search/suggest?q=${encodeURIComponent(value)}&locale=${locale}`,
          { signal: controller.signal },
        );
        const data = (await res.json()) as { results?: Suggestion[] };
        setResults(data.results ?? []);
        setOpen(true);
      } catch { /* aborted */ } finally {
        setLoading(false);
      }
    }, 220);
    return () => {
      controller.abort();
      clearTimeout(timer);
    };
  }, [value, locale]);

  useEffect(() => {
    function onClick(event: MouseEvent) {
      if (boxRef.current && !boxRef.current.contains(event.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  function submit(event: React.FormEvent) {
    event.preventDefault();
    const q = value.trim();
    setOpen(false);
    router.push(`/${locale}/search${q ? `?q=${encodeURIComponent(q)}` : ""}`);
  }

  const heights = { sm: "h-10 text-sm", md: "h-12 text-[15px]", lg: "h-14 text-base" };

  return (
    <div ref={boxRef} className="relative w-full">
      <form role="search" onSubmit={submit} className="relative">
        <IconSearch
          size={19}
          className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-[color:var(--muted)]"
        />
        <input
          type="search"
          value={value}
          autoFocus={autoFocus}
          onChange={(e) => setValue(e.target.value)}
          onFocus={() => results.length && setOpen(true)}
          placeholder={placeholder}
          aria-label={label}
          className={`w-full rounded-full border pl-12 pr-24 outline-none transition focus:border-brand ${heights[size]}`}
          style={{ background: "var(--surface)", borderColor: "var(--line)", color: "var(--text)" }}
        />
        <button
          type="submit"
          className="absolute right-1.5 top-1/2 -translate-y-1/2 rounded-full bg-brand px-4 py-2 text-xs font-bold uppercase tracking-wide text-white transition hover:bg-brand-600"
        >
          {label}
        </button>
      </form>
      {open && (
        <div
          className="absolute left-0 right-0 z-40 mt-2 overflow-hidden rounded-xl border shadow-card"
          style={{ background: "var(--surface)", borderColor: "var(--line)" }}
        >
          {loading && <p className="px-4 py-3 text-xs subtle">…</p>}
          {!loading && results.length === 0 && (
            <p className="px-4 py-3 text-xs subtle">{label}: 0</p>
          )}
          {results.map((r) => (
            <button
              key={`${r.slug}-${r.title}`}
              type="button"
              onClick={() => {
                setOpen(false);
                router.push(`/${locale}/news/${r.slug}`);
              }}
              className="block w-full border-b px-4 py-2.5 text-left text-sm last:border-0 hover:text-brand"
              style={{ borderColor: "var(--line)" }}
            >
              {r.title}
              {r.category_slug && (
                <span className="ml-2 text-[10px] uppercase tracking-wide subtle">{r.category_slug}</span>
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
