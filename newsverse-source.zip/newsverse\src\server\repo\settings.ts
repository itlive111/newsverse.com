import { get, run, nowIso } from "@/server/db";
import { ensureBootstrapped } from "@/server/db/bootstrap";
import { DEFAULT_SETTINGS } from "@/server/db/seed";

export function getSetting(key: string, fallback = ""): string {
  ensureBootstrapped();
  const row = get<{ value: string }>("SELECT value FROM settings WHERE key = ?", key);
  return row?.value ?? DEFAULT_SETTINGS[key] ?? fallback;
}

export function getBoolSetting(key: string, fallback = false): boolean {
  const value = getSetting(key, fallback ? "1" : "0");
  return value === "1" || value.toLowerCase() === "true";
}

export function getNumberSetting(key: string, fallback: number): number {
  const value = Number(getSetting(key, String(fallback)));
  return Number.isFinite(value) ? value : fallback;
}

export function setSetting(key: string, value: string): void {
  const existing = get("SELECT key FROM settings WHERE key = ?", key);
  if (existing) {
    run("UPDATE settings SET value = ?, updated_at = ? WHERE key = ?", value, nowIso(), key);
  } else {
    run("INSERT INTO settings (key, value, updated_at) VALUES (?,?,?)", key, value, nowIso());
  }
}

export function getAllSettings(): Record<string, string> {
  ensureBootstrapped();
  const rows = get<any[]>("SELECT key, value FROM settings") ?? [];
  const out: Record<string, string> = { ...DEFAULT_SETTINGS };
  for (const row of rows) out[row.key] = row.value;
  return out;
}
