/** Applies the saved theme before first paint to avoid a flash. */
export function ThemeScript() {
  const script = `(function(){try{var t=localStorage.getItem('nv_theme');if(!t){t='dark';}document.documentElement.classList.toggle('light',t==='light');}catch(e){}})();`;
  return <script dangerouslySetInnerHTML={{ __html: script }} />;
}
