import { all, get } from "@/server/db";
import { requireUser } from "@/server/auth";
import { json, handleError } from "@/server/http";

/** GDPR-style personal data export: only the caller's own data, never secrets. */
export async function GET() {
  try {
    const user = await requireUser();
    const profile = get<{ id: string; email: string; name: string; locale: string; role: string; created_at: string }>(
      "SELECT id, email, name, locale, role, created_at FROM users WHERE id = ?",
      user.id,
    );
    const bookmarks = all("SELECT article_id, folder, created_at FROM bookmarks WHERE user_id = ?", user.id);
    const history = all("SELECT article_id, read_at FROM reading_history WHERE user_id = ?", user.id);
    const comments = all("SELECT article_id, body, status, created_at FROM comments WHERE user_id = ?", user.id);
    const payload = {
      exported_at: new Date().toISOString(),
      account: profile,
      bookmarks,
      reading_history: history,
      comments,
    };
    return new Response(JSON.stringify(payload, null, 2), {
      headers: {
        "content-type": "application/json",
        "content-disposition": `attachment; filename="newsverse-export-${user.id.slice(0, 8)}.json"`,
        "cache-control": "no-store",
      },
    });
  } catch (err) {
    return handleError(err);
  }
}
