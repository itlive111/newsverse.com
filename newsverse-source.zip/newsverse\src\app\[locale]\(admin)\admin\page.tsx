import { adminGate } from "@/server/adminPage";
import Link from "next/link";
import { notFound } from "next/navigation";
import { formatDate, formatNumber, isLocale, t } from "@/i18n";
import {
  adminStats, duplicateCandidates, recentAudit, sourceHealth, topArticles, topCategories, viewsSeries,
} from "@/server/repo/admin";
import { getBoolSetting, getSetting } from "@/server/repo/settings";
import { schedulerInfo } from "@/server/ingest/jobs";
import { AdminSection, Bars, StatCard, StatusBadge, Td, Th } from "@/components/admin/ui";
import { ActionButton } from "@/components/admin/action-button";

export const dynamic = "force-dynamic";

export default async function AdminOverview({ params }: { params: Promise<{ locale: string }> }) {
  const { locale: raw } = await params;
  if (!isLocale(raw)) notFound();
  const locale = raw;
  await adminGate("moderator");

  const stats = adminStats();
  const series = viewsSeries(14);
  const series30 = viewsSeries(30);
  const top = topArticles(6, locale);
  const categories = topCategories(6);
  const sources = sourceHealth();
  const audit = recentAudit(8);
  const duplicates = duplicateCandidates(5);
  const scheduler = schedulerInfo();
  const aiEnabled = getBoolSetting("ai_enabled", false);
  const autoPublish = getSetting("moderation_mode", "review");
  const views30 = series30.reduce((sum, day) => sum + day.views, 0);
  const articles30 = series30.reduce((sum, day) => sum + day.articles, 0);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-black tracking-tight">{t(locale, "admin.title")}</h1>
          <p className="text-xs subtle">
            {t(locale, "admin.ingestionEnabled")}: {getBoolSetting("auto_ingest_enabled", true) ? "on" : "off"} ·{" "}
            {t(locale, "admin.moderationMode")}: {autoPublish} · {scheduler.running ? "scheduler running" : "scheduler idle"}
          </p>
        </div>
        <div className="flex gap-2">
          <Link href={`/${locale}/admin/articles/new`} className="btn-primary !py-1.5 !text-xs">{t(locale, "admin.newArticle")}</Link>
          <ActionButton endpoint="/api/cron/tick" method="POST" label={t(locale, "admin.runNow")} variant="ghost" busyLabel="…" />
        </div>
      </div>

      {!aiEnabled && (
        <div className="rounded-xl border border-amber-500/30 bg-amber-500/5 p-3 text-xs">
          <strong className="text-amber-300">{t(locale, "admin.aiDisabled")}</strong>{" "}
          — {t(locale, "article.aiNotice")}
        </div>
      )}
      {stats.alerts > 0 && (
        <div className="rounded-xl border p-3 text-xs" style={{ borderColor: "var(--line)" }}>
          <span className="text-brand">⚠ {stats.alerts} unresolved ingestion alerts</span>{" "}
          <Link href={`/${locale}/admin/automation`} className="underline">{t(locale, "admin.automation")}</Link>
        </div>
      )}

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4 xl:grid-cols-6">
        <StatCard label={t(locale, "common.published")} value={formatNumber(stats.published, locale)} accent />
        <StatCard label="Pending review" value={formatNumber(stats.pending, locale)} hint={t(locale, "admin.status")} />
        <StatCard label="Scheduled" value={formatNumber(stats.scheduled, locale)} />
        <StatCard label="Failed jobs" value={formatNumber(stats.failedJobs, locale)} hint={`${stats.queuedJobs} queued`} />
        <StatCard label={t(locale, "admin.users")} value={formatNumber(stats.users, locale)} hint={`${stats.activeUsers} active sessions`} />
        <StatCard label="Views (24h)" value={formatNumber(stats.views24h, locale)} hint={`${formatNumber(stats.viewsTotal, locale)} total`} />
        <StatCard label={t(locale, "admin.comments")} value={formatNumber(stats.pendingComments, locale)} hint="pending" />
        <StatCard label={t(locale, "admin.sources")} value={formatNumber(stats.sources, locale)} hint={`${stats.sourcesFailing} failing`} />
        <StatCard label={t(locale, "admin.reports")} value={formatNumber(stats.openReports, locale)} hint="open" />
        <StatCard label={t(locale, "admin.newsletter")} value={formatNumber(stats.subscribers, locale)} />
        <StatCard label="30-day views" value={formatNumber(views30, locale)} />
        <StatCard label="30-day articles" value={formatNumber(articles30, locale)} />
      </div>

      <div className="grid gap-4 xl:grid-cols-[1.4fr_1fr]">
        <AdminSection title={t(locale, "admin.chart.views")}>
          <Bars data={series} label={`Daily views over ${series.length} days`} />
          <p className="mt-3 text-[11px] subtle">
            Views are counted from recorded page events, not estimates. Bars show the last 14 days.
          </p>
        </AdminSection>

        <AdminSection title={t(locale, "admin.topCategories")}>
          <ul className="space-y-2">
            {categories.map((c) => {
              const max = Math.max(1, ...categories.map((x) => x.views));
              return (
                <li key={c.slug}>
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold">{c.slug}</span>
                    <span className="subtle">{formatNumber(c.views, locale)} views · {c.count}</span>
                  </div>
                  <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-white/5">
                    <div className="h-full rounded-full bg-brand" style={{ width: `${(c.views / max) * 100}%` }} />
                  </div>
                </li>
              );
            })}
            {!categories.length && <li className="text-xs subtle">{t(locale, "common.noResults")}</li>}
          </ul>
        </AdminSection>
      </div>

      <div className="grid gap-4 xl:grid-cols-2">
        <AdminSection title={t(locale, "admin.topArticles")} action={<Link href={`/${locale}/admin/articles`} className="text-[11px] underline">{t(locale, "admin.articles")}</Link>}>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead><tr><Th>{t(locale, "admin.title")}</Th><Th>Views</Th><Th>{t(locale, "admin.status")}</Th></tr></thead>
              <tbody>
                {top.map((a) => (
                  <tr key={a.id} className="border-t" style={{ borderColor: "var(--line)" }}>
                    <Td><Link href={`/${locale}/admin/articles/${a.id}`} className="line-clamp-2 hover:text-brand">{a.title ?? "—"}</Link></Td>
                    <Td>{formatNumber(a.views, locale)}</Td>
                    <Td><StatusBadge status={a.status} /></Td>
                  </tr>
                ))}
                {!top.length && <tr><Td className="subtle">—</Td><Td>0</Td><Td>—</Td></tr>}
              </tbody>
            </table>
          </div>
        </AdminSection>

        <AdminSection title={t(locale, "admin.sourceHealth")} action={<Link href={`/${locale}/admin/sources`} className="text-[11px] underline">{t(locale, "admin.sources")}</Link>}>
          <ul className="space-y-2 text-xs">
            {sources.slice(0, 6).map((s) => (
              <li key={s.id} className="flex items-center justify-between gap-2 border-t pt-2 first:border-0 first:pt-0" style={{ borderColor: "var(--line)" }}>
                <div className="min-w-0">
                  <p className="truncate font-semibold">{s.name}</p>
                  <p className="text-[10px] subtle">
                    {s.last_ok_at ? formatDate(s.last_ok_at, locale) : "never"} · {s.total_items} items
                  </p>
                </div>
                {s.consecutive_failures > 0 ? <span className="text-brand">fail ×{s.consecutive_failures}</span> : <StatusBadge status={s.enabled ? "active" : "archived"} />}
              </li>
            ))}
            {!sources.length && <li className="subtle">{t(locale, "common.noResults")}</li>}
          </ul>
        </AdminSection>
      </div>

      <div className="grid gap-4 xl:grid-cols-2">
        <AdminSection title={t(locale, "admin.recentActivity")}>
          <ul className="space-y-2 text-xs">
            {audit.map((a, i) => (
              <li key={i} className="flex items-start justify-between gap-3 border-t pt-2 first:border-0 first:pt-0" style={{ borderColor: "var(--line)" }}>
                <div>
                  <p><strong>{a.action}</strong> <span className="subtle">{a.entity} {a.entity_id?.slice(0, 8)}</span></p>
                  <p className="text-[10px] subtle">{a.actor_email ?? "system"}</p>
                </div>
                <span className="whitespace-nowrap text-[10px] subtle">{formatDate(a.created_at, locale)}</span>
              </li>
            ))}
            {!audit.length && <li className="subtle">{t(locale, "common.noResults")}</li>}
          </ul>
        </AdminSection>

        <AdminSection title={t(locale, "admin.duplicates")}>
          {duplicates.length ? (
            <ul className="space-y-3 text-xs">
              {Object.entries(
                duplicates.reduce<Record<string, { title: string; items: typeof duplicates }>>((acc, row) => {
                  if (!row.event_key) return acc;
                  acc[row.event_key] ??= { title: row.title, items: [] };
                  acc[row.event_key].items.push(row);
                  return acc;
                }, {}),
              ).map(([key, group]) => (
                <li key={key} className="border-t pt-2 first:border-0 first:pt-0" style={{ borderColor: "var(--line)" }}>
                  <p className="font-semibold">{group.title}</p>
                  <p className="text-[10px] subtle">
                    {group.items.length} reports of the same event · {group.items.map((i) => i.source_name ?? "—").join(", ")}
                  </p>
                  <div className="mt-1 flex flex-wrap gap-2">
                    {group.items.slice(0, 4).map((i) => (
                      <Link key={i.id} href={`/${locale}/admin/articles/${i.id}`} className="text-[10px] underline">
                        {i.id.slice(0, 8)}
                      </Link>
                    ))}
                  </div>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-xs subtle">{t(locale, "common.noResults")}</p>
          )}
        </AdminSection>
      </div>
    </div>
  );
}
