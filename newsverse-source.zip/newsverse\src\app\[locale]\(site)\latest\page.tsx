import type { Metadata } from "next";
import { resolveLocale, t, type Locale } from "@/i18n";
import { countArticles, getBreaking, listArticles } from "@/server/repo/content";
import { ArticleCard } from "@/components/article-card";
import { BreakingTicker } from "@/components/breaking-ticker";
import { EmptyState, Pagination, SectionHeader } from "@/components/layout-parts";

type Props = { params: Promise<{ locale: string }>; searchParams: Promise<{ page?: string }> };
const PAGE_SIZE = 15;

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const locale = resolveLocale((await params).locale);
  return {
    title: t(locale, "home.latest"),
    description: t(locale, "meta.homeDesc"),
    alternates: { canonical: `/${locale}/latest` },
  };
}

export default async function LatestPage({ params, searchParams }: Props) {
  const locale = resolveLocale((await params).locale) as Locale;
  const page = Math.max(1, Number((await searchParams).page) || 1);
  const articles = listArticles({ locale, limit: PAGE_SIZE, offset: (page - 1) * PAGE_SIZE });
  const total = countArticles({ locale });
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const breaking = getBreaking(locale, 5);

  return (
    <div>
      <BreakingTicker articles={breaking} locale={locale} />
      <div className="container-nv py-6">
        <SectionHeader title={t(locale, "home.latest")} hint={`${total} ${t(locale, "category.stories")}`} />
        {articles.length === 0 ? (
          <EmptyState title={t(locale, "state.emptyTitle")} body={t(locale, "state.emptyBody")} />
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {articles.map((article) => (
              <ArticleCard key={article.id} article={article} locale={locale} />
            ))}
          </div>
        )}
        <Pagination
          basePath={`/${locale}/latest`}
          page={page}
          totalPages={totalPages}
          prevLabel={t(locale, "common.prev")}
          nextLabel={t(locale, "common.next")}
        />
      </div>
    </div>
  );
}
