import crypto from "node:crypto";
import { cookies, headers } from "next/headers";
import { get, run, nowIso } from "@/server/db";
import { ensureBootstrapped } from "@/server/db/bootstrap";
import type { Locale } from "@/i18n";

export const SESSION_COOKIE = "nv_session";
export const SESSION_TTL_DAYS = 30;
export const ADMIN_ROLES = ["super_admin", "admin", "editor", "moderator"] as const;
export const STAFF_ROLES = ["super_admin", "admin", "editor", "moderator", "author"] as const;

export type Role = "reader" | "author" | "moderator" | "editor" | "admin" | "super_admin";

export const ROLE_RANK: Record<Role, number> = {
  reader: 0,
  author: 1,
  moderator: 2,
  editor: 3,
  admin: 4,
  super_admin: 5,
};

export type SessionUser = {
  id: string;
  email: string;
  name: string;
  username: string | null;
  role: Role;
  locale: Locale;
  status: string;
  avatar_url: string | null;
  interests: string;
  email_verified: number;
};

/* -------------------------------------------------------------------------- */
/* Passwords (scrypt, no native dependency)                                   */
/* -------------------------------------------------------------------------- */

export { hashPassword, verifyPassword } from "@/server/password";

export function hashIp(ip: string): string {
  const secret = process.env.APP_SECRET || "newsverse-dev-secret";
  return crypto.createHmac("sha256", secret).update(ip).digest("hex").slice(0, 32);
}

/* -------------------------------------------------------------------------- */
/* Sessions                                                                   */
/* -------------------------------------------------------------------------- */

export async function createSession(userId: string): Promise<void> {
  ensureBootstrapped();
  const token = crypto.randomBytes(32).toString("base64url");
  const id = crypto.createHash("sha256").update(token).digest("hex");
  const expires = new Date(Date.now() + SESSION_TTL_DAYS * 86400000);
  const hdrs = await headers();
  run(
    "INSERT INTO sessions (id, user_id, expires_at, created_at, user_agent, ip_hash) VALUES (?,?,?,?,?,?)",
    id, userId, expires.toISOString(), nowIso(),
    (hdrs.get("user-agent") ?? "").slice(0, 250),
    hashIp(clientIpFromHeaders(hdrs) ?? "unknown"),
  );
  const store = await cookies();
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    expires,
  });
}

export async function destroySession(): Promise<void> {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (token) {
    const id = crypto.createHash("sha256").update(token).digest("hex");
    run("DELETE FROM sessions WHERE id = ?", id);
  }
  store.set(SESSION_COOKIE, "", { httpOnly: true, path: "/", maxAge: 0 });
}

export async function getCurrentUser(): Promise<SessionUser | null> {
  ensureBootstrapped();
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  const id = crypto.createHash("sha256").update(token).digest("hex");
  const row = get<SessionUser & { expires_at: string }>(
    `SELECT u.id, u.email, u.name, u.username, u.role, u.locale, u.status, u.avatar_url, u.interests,
            u.email_verified, s.expires_at
     FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.id = ?`,
    id,
  );
  if (!row) return null;
  if (new Date(row.expires_at).getTime() < Date.now() || row.status !== "active") return null;
  return row;
}

export async function requireUser(): Promise<SessionUser> {
  const user = await getCurrentUser();
  if (!user) throw new AuthError("unauthorized", 401);
  return user;
}

export async function requireAdmin(minRole: Role = "editor"): Promise<SessionUser> {
  const user = await requireUser();
  if (!hasRole(user, minRole)) throw new AuthError("forbidden", 403);
  return user;
}

/** Rank check used for role-scoped authorization (moderator < editor < admin < super_admin). */
export function hasRole(user: { role: string } | null | undefined, minRole: Role): boolean {
  if (!user) return false;
  const rank = ROLE_RANK[user.role as Role];
  return typeof rank === "number" && rank >= ROLE_RANK[minRole];
}

/** True for every role that may open the admin application. */
export function isAdmin(user: { role: string } | null | undefined): boolean {
  return !!user && (ADMIN_ROLES as readonly string[]).includes(user.role);
}

export function isStaff(user: { role: string } | null | undefined): boolean {
  return !!user && (STAFF_ROLES as readonly string[]).includes(user.role);
}

export class AuthError extends Error {
  status: number;
  constructor(message: string, status = 403) {
    super(message);
    this.status = status;
  }
}

/* -------------------------------------------------------------------------- */
/* Request helpers                                                            */
/* -------------------------------------------------------------------------- */

type HeadersLike = { get(name: string): string | null };

export function clientIpFromHeaders(hdrs: HeadersLike): string | null {
  const forwarded = hdrs.get("x-forwarded-for");
  if (forwarded) return forwarded.split(",")[0]!.trim();
  return hdrs.get("x-real-ip");
}

/** Rejects cross-site state-changing requests (CSRF defense in depth). */
export function isSameOrigin(request: Request): boolean {
  const origin = request.headers.get("origin");
  const secFetchSite = request.headers.get("sec-fetch-site");
  if (secFetchSite && !["same-origin", "same-site", "none"].includes(secFetchSite)) return false;
  if (!origin) return true; // non-browser clients / same-origin form posts without Origin
  const allowed = new Set<string>();
  for (const value of (process.env.ALLOWED_ORIGINS ?? "").split(",")) {
    if (value.trim()) allowed.add(value.trim().replace(/\/$/, ""));
  }
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL;
  if (siteUrl) allowed.add(siteUrl.replace(/\/$/, ""));
  try {
    const requestOrigin = new URL(request.url).origin;
    allowed.add(requestOrigin);
  } catch { /* ignore */ }
  return allowed.has(origin.replace(/\/$/, ""));
}

/* -------------------------------------------------------------------------- */
/* Rate limiting (in-process sliding window; use Redis for multi-instance)     */
/* -------------------------------------------------------------------------- */

const buckets = new Map<string, { count: number; resetAt: number }>();

export function rateLimit(key: string, limit: number, windowMs: number): boolean {
  const now = Date.now();
  const entry = buckets.get(key);
  if (!entry || entry.resetAt < now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs });
    return true;
  }
  entry.count += 1;
  if (buckets.size > 5000) {
    for (const [k, v] of buckets) if (v.resetAt < now) buckets.delete(k);
  }
  return entry.count <= limit;
}

/* -------------------------------------------------------------------------- */
/* Audit log                                                                  */
/* -------------------------------------------------------------------------- */

export function audit(params: {
  actor?: { id: string; email: string } | null;
  action: string;
  entity?: string;
  entityId?: string;
  meta?: Record<string, unknown>;
  ipHash?: string;
}): void {
  run(
    "INSERT INTO audit_logs (id, actor_user_id, actor_email, action, entity, entity_id, meta, ip_hash, created_at) VALUES (?,?,?,?,?,?,?,?,?)",
    crypto.randomUUID(), params.actor?.id ?? null, params.actor?.email ?? null, params.action,
    params.entity ?? null, params.entityId ?? null,
    params.meta ? JSON.stringify(params.meta) : null, params.ipHash ?? null, nowIso(),
  );
}
