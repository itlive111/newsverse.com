import { notFound } from "next/navigation";
import type { Role } from "@/server/auth";
import { getCurrentUser, hasRole } from "@/server/auth";

/**
 * Page-level gate for every admin route.
 *
 * A layout is not enough: Next renders layouts and pages concurrently, so a
 * redirect thrown in the layout can still stream the page's data payload.
 * Each admin page therefore refuses to read data until this check passes.
 */
export async function adminGate(minRole: Role = "editor") {
  const user = await getCurrentUser();
  if (!hasRole(user, minRole)) notFound();
  return user;
}
