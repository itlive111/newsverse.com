import Link from "next/link";
import { defaultLocale, t } from "@/i18n";
import { IconGlobe } from "@/components/icons";

export default function NotFound() {
  const locale = defaultLocale;
  return (
    <div className="container-nv flex flex-col items-center justify-center py-24 text-center">
      <span className="flex h-16 w-16 items-center justify-center rounded-full bg-brand/10 text-brand">
        <IconGlobe size={30} />
      </span>
      <h1 className="mt-4 font-display text-4xl font-extrabold">404</h1>
      <p className="mt-2 text-lg font-semibold">{t(locale, "state.notFoundTitle")}</p>
      <p className="mt-1 max-w-md text-sm subtle">{t(locale, "state.notFoundBody")}</p>
      <p className="mt-2 max-w-md text-xs subtle">
        Страница не найдена · Page not found · Sahifa topilmadi
      </p>
      <Link href={`/${locale}`} className="btn-primary mt-6">{t(locale, "state.backHome")}</Link>
    </div>
  );
}
