import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { resolveLocale, t, formatDate, type Locale } from "@/i18n";
import { getCurrentUser, hasRole } from "@/server/auth";
import { get } from "@/server/db";
import { listBookmarks, listCategories, listHistory } from "@/server/repo/content";
import { ArticleCard } from "@/components/article-card";
import { Panel, SectionHeader } from "@/components/layout-parts";
import { ProfileForm, InterestsForm, DangerZone, SecuritySection } from "@/components/account-forms";
import { LogoutButton } from "@/components/logout-button";
import { initials } from "@/lib/ui";

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const locale = resolveLocale((await params).locale);
  return { title: t(locale, "account.title"), robots: { index: false } };
}

export default async function AccountPage({
  params,
  searchParams,
}: {
  params: Promise<{ locale: string }>;
  searchParams: Promise<{ verify?: string }>;
}) {
  const locale = resolveLocale((await params).locale) as Locale;
  const { verify } = await searchParams;
  const user = await getCurrentUser();
  if (!user) redirect(`/${locale}/login?next=${encodeURIComponent(`/${locale}/account`)}`);

  const profile = get<{
    bio: string | null;
    pending_email: string | null;
    notification_prefs: string;
    email_verified_at: string | null;
  }>("SELECT bio, pending_email, notification_prefs, email_verified_at FROM users WHERE id = ?", user.id);

  let notify = { email: true, breaking: false, comments: true };
  try {
    const parsed = JSON.parse(profile?.notification_prefs ?? "{}") as Partial<typeof notify>;
    notify = { ...notify, ...parsed };
  } catch { /* defaults */ }

  const categories = listCategories(locale);
  const history = listHistory(user.id, locale, 12);
  const bookmarks = listBookmarks(user.id, locale);
  let interests: string[] = [];
  try {
    interests = JSON.parse(user.interests) as string[];
  } catch {
    interests = [];
  }

  return (
    <div className="container-nv py-8">
      <header className="flex flex-wrap items-center justify-between gap-4 border-b pb-6" style={{ borderColor: "var(--line)" }}>
        <div className="flex items-center gap-3">
          <span className="flex h-14 w-14 items-center justify-center overflow-hidden rounded-full bg-brand/15 text-lg font-black text-brand">
            {user.avatar_url ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={user.avatar_url} alt="" className="h-full w-full object-cover" />
            ) : (
              initials(user.name)
            )}
          </span>
          <div>
            <h1 className="font-display text-2xl font-extrabold">{user.name}</h1>
            <p className="text-xs subtle">
              @{user.username ?? user.email.split("@")[0]} · {user.email} · {user.role}
              {user.email_verified ? " · ✓" : ""}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {(hasRole(user, "moderator") || user.role === "author") && (
            <Link href={`/${locale}/admin`} className="btn-primary !text-xs">{t(locale, "nav.admin")}</Link>
          )}
          <LogoutButton locale={locale} className="btn-ghost !text-xs" />
        </div>
      </header>

      {verify === "ok" && (
        <p className="mt-4 rounded-lg bg-emerald-500/10 px-3 py-2 text-xs text-emerald-400">{t(locale, "auth.verifyOk")}</p>
      )}
      {(verify === "invalid" || verify === "taken") && (
        <p className="mt-4 rounded-lg bg-brand/10 px-3 py-2 text-xs text-brand">{t(locale, "auth.verifyInvalid")}</p>
      )}

      <div className="mt-6 grid gap-6 lg:grid-cols-[1.4fr_1fr]">
        <div className="space-y-6">
          <Panel title={t(locale, "account.profile")}>
            <ProfileForm
              locale={locale}
              initial={{
                name: user.name,
                username: user.username ?? "",
                bio: profile?.bio ?? "",
                avatar_url: user.avatar_url ?? "",
                locale: user.locale,
                notify_email: notify.email,
                notify_breaking: notify.breaking,
                notify_comments: notify.comments,
              }}
            />
          </Panel>

          <Panel title={t(locale, "account.security")}>
            <SecuritySection
              locale={locale}
              verified={!!user.email_verified || !!profile?.email_verified_at}
              pendingEmail={profile?.pending_email ?? null}
            />
          </Panel>

          <Panel title={t(locale, "account.interests")}>
            <InterestsForm locale={locale} categories={categories.map((c) => ({ slug: c.slug, name: c.name }))} initial={interests} />
          </Panel>

          <Panel title={t(locale, "account.history")}>
            <p className="text-xs subtle">{t(locale, "account.historyHint")}</p>
            <div className="mt-3 space-y-3">
              {history.length === 0 && <p className="text-xs subtle">{t(locale, "account.noHistory")}</p>}
              {history.map((article) => (
                <ArticleCard key={article.id} article={article} locale={locale} variant="compact" />
              ))}
            </div>
          </Panel>
        </div>

        <div className="space-y-6">
          <Panel title={t(locale, "bookmarks.title")}>
            <p className="text-3xl font-black text-brand">{bookmarks.length}</p>
            <Link href={`/${locale}/saved`} className="mt-2 inline-block text-xs font-semibold text-brand hover:underline">
              {t(locale, "bookmarks.title")} →
            </Link>
          </Panel>
          <Panel title={t(locale, "account.newsletter")}>
            <p className="text-xs subtle">{t(locale, "newsletter.desc")}</p>
            <Link href={`/${locale}`} className="mt-3 inline-block text-xs font-semibold text-brand hover:underline">
              {t(locale, "newsletter.cta")} →
            </Link>
          </Panel>
          <Panel title={t(locale, "account.dangerZone")}>
            <DangerZone locale={locale} />
          </Panel>
          <p className="text-[11px] subtle">{formatDate(new Date(), locale)}</p>
        </div>
      </div>
    </div>
  );
}
