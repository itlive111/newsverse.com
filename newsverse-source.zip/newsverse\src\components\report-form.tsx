"use client";

import { useState } from "react";
import { t, type Locale } from "@/i18n";

export function ReportForm({ articleId, locale }: { articleId: string; locale: Locale }) {
  const [open, setOpen] = useState(false);
  const [reason, setReason] = useState("factual_error");
  const [details, setDetails] = useState("");
  const [done, setDone] = useState(false);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    try {
      await fetch("/api/reports", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ articleId, reason, details }),
      });
      setDone(true);
      setOpen(false);
    } catch { /* keep form open on network failure */ }
  }

  return (
    <div className="no-print mt-4">
      <button type="button" onClick={() => setOpen((v) => !v)} className="text-xs underline decoration-brand/50 underline-offset-4 subtle hover:text-brand">
        {t(locale, "article.report")}
      </button>
      {done && <p className="mt-2 text-xs text-emerald-400">{t(locale, "article.reportSent")}</p>}
      {open && (
        <form onSubmit={submit} className="mt-3 rounded-xl border p-4" style={{ borderColor: "var(--line)" }}>
          <label htmlFor="report-reason" className="label">{t(locale, "article.report")}</label>
          <select id="report-reason" value={reason} onChange={(e) => setReason(e.target.value)} className="input mb-2">
            <option value="factual_error">{t(locale, "article.reasonFactual")}</option>
            <option value="translation">{t(locale, "article.reasonTranslation")}</option>
            <option value="copyright">{t(locale, "article.reasonCopyright")}</option>
            <option value="other">{t(locale, "article.reasonOther")}</option>
          </select>
          <textarea
            value={details}
            onChange={(e) => setDetails(e.target.value)}
            rows={3}
            maxLength={2000}
            className="input"
            placeholder="…"
          />
          <button type="submit" className="btn-primary mt-2">{t(locale, "article.commentSubmit")}</button>
        </form>
      )}
    </div>
  );
}
