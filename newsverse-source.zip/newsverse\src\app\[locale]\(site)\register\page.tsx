import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { resolveLocale, t, type Locale } from "@/i18n";
import { getCurrentUser } from "@/server/auth";
import { RegisterForm } from "@/components/auth-forms";
import { BrandLogo } from "@/components/brand-logo";

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const locale = resolveLocale((await params).locale);
  return { title: t(locale, "auth.registerTitle"), robots: { index: false } };
}

export default async function RegisterPage({ params }: { params: Promise<{ locale: string }> }) {
  const locale = resolveLocale((await params).locale) as Locale;
  const user = await getCurrentUser();
  if (user) redirect(`/${locale}/account`);
  return (
    <div className="container-nv grid max-w-4xl gap-8 py-12 md:grid-cols-2 md:items-center">
      <div>
        <span className="mb-4 block">
          <BrandLogo size="lg" />
        </span>
        <h1 className="mt-2 font-display text-3xl font-extrabold leading-tight">{t(locale, "auth.registerTitle")}</h1>
        <ul className="mt-4 space-y-2 text-sm subtle">
          <li>· {t(locale, "bookmarks.title")}</li>
          <li>· {t(locale, "account.interests")}</li>
          <li>· {t(locale, "home.recommended")}</li>
          <li>· {t(locale, "account.notifications")}</li>
        </ul>
        <p className="mt-6 text-xs subtle">{t(locale, "newsletter.privacy")}</p>
      </div>
      <div className="card p-6">
        <RegisterForm locale={locale} />
      </div>
    </div>
  );
}
