# Acceptance test log

Executed on Windows 11, Node 24.19.0, Chromium not used (no visual/interaction tests requested).
Commands were run against **`npm start` (production build)** unless noted.

## Automated checks

| Check | Command | Result |
| --- | --- | --- |
| TypeScript | `npx tsc --noEmit` | Pass (0 errors) |
| Unit tests | `npx vitest run` | Pass — 5 files, 34 tests |
| Production build | `npm run build` | Pass — 108 pages generated |
| Backup script | `node scripts/backup.js /tmp/nv-backups` | Pass — 1228 KB dump written |

Unit coverage: translation completeness (every key in uz/en/ru), locale fallback, number/date
formatting, slugify (Latin apostrophes + Cyrillic), HTML stripping, URL canonicalization, XML
escaping, paragraph splitting, scrypt hashing, duplicate detection (hash, similarity, event key),
Zod schemas (short titles, unsupported locales, non-http URLs, weak passwords).

## Acceptance criteria

| # | Criterion | Verification | Result |
| --- | --- | --- | --- |
| 1 | Installs and builds | `npm ci`-equivalent install, `npm run build` | Pass |
| 2 | Homepage loads without runtime errors | `GET /uz /en /ru` → 200, `<title>` rendered | Pass |
| 3 | UZ/EN/RU switching | Each locale serves its own translated page, metadata and hreflang; RU article without translation shows "Показан оригинал. (EN)" | Pass |
| 4 | Register, sign in, sign out | Registered `reader@example.com`, logged in, admin session cookie issued, bookmark saved, logout endpoint exercised | Pass |
| 5 | Unauthorized users cannot access admin | Anonymous → 307 to login; reader account → 403 page with **zero** admin data in the RSC payload; admin APIs return 401 for anonymous, 403 for foreign Origin | Pass |
| 6 | Admin can create, edit, publish | Created and published an article via `POST /api/admin/articles`; it rendered at `/en/news/...` and `/uz/news/...` | Pass |
| 7 | RSS/API ingestion retrieves genuine articles | Scheduler collected from BBC, Guardian, Al Jazeera, TechCrunch, Ars Technica, Gazeta.uz, Daryo.uz, UzA, Meduza — 303 articles, real titles/images | Pass |
| 8 | Jobs run independently of browser visits | Logs show collections at 08:59, 09:11, 09:15 UTC with no browser open; 14 succeeded jobs, 0 failed after retries | Pass |
| 9 | Duplicate handling | Unit tests for URL/title-hash/similarity/event-key; live dedupe ran on every collection ("0 duplicates" reported where feeds had none) | Pass (logic + unit tests) |
| 10 | Images and source attribution | Imported Daryo.uz article: `Manba` block, publisher link, og:image from publisher CDN | Pass |
| 11 | Failed jobs logged and retryable | Kun.uz feed returned 404 → 3 retries with backoff, `ingestion_logs` warn/error rows, admin Automation shows failed job + Retry action | Pass |
| 12 | Search, categories, bookmarks, pagination | `/en/search?q=Wales|economy|iPhone` return results; category/latest/trending pages 200; bookmark API saved for a signed-in reader; latest uses page params | Pass |
| 13 | Responsive layouts | Tailwind responsive classes throughout; **not visually verified** on devices in this environment | Not verified |
| 14 | SEO metadata and sitemap | `sitemap.xml` (localized alternates), `robots.txt`, `feed.xml`, OpenGraph, `NewsArticle` + `BreadcrumbList` JSON-LD, manifest | Pass |
| 15 | Secrets stay on server | AI keys/APP_SECRET/CRON_SECRET read only in server modules; health endpoint exposes only `enabled` + reason | Pass (code inspection + health output) |
| 16 | Persistence survives restart | 303 articles / 2 users before and after a full stop → rebuild → start | Pass |

## Additional checks

- `GET /api/health` → `{ok:true, database:"up", migrations:2, publishedArticles:255, ai:{enabled:false,reason:"missing_api_key"}, scheduler:{running:true}}`
- Newsletter signup → `{"ok":true,"created":true}`
- Bookmark without session → 401; with reader session → `{"ok":true,"saved":true}`
- Cross-origin admin mutation with a valid admin cookie but `Origin: https://evil.example` → 403
- `robots.txt` blocks `/api/`, `/*/admin`, `/*/account`, `/*/saved`, `/*/search`, `/*/login`, `/*/register`, `/*/reset-password`
- View recording: `POST /api/views` returned `counted:true` and incremented both the event table and `articles.view_count`

## Account upgrade tests (Infinity X)

Executed against `npm run dev` after migration `003_auth_upgrade.sql` (applied without data loss).

| Check | Result |
| --- | --- |
| Register with username `dilnoza_k` | 200, session created, verification token logged |
| Verification link from server log | 307 → `/uz/account?verify=ok`; `email_verified=1`, `email_verified_at` set |
| Login with **username** instead of e-mail | 200 |
| Change password | 200; old password → 401, new password → 200 |
| Change e-mail | 200; link to new address → 307 verify ok; e-mail updated, `pending_email` cleared |
| Promote account to moderator (super admin) | 200 |
| Moderator opens `/uz/admin`, `/admin/comments`, `/admin/reports` | 200 with content |
| Moderator opens `/uz/admin/settings`, `/admin/users`, `/admin/articles` | No user/settings data in the response; settings API → 403 |
| Admin tries to grant `super_admin` | 403 (no privilege escalation) |
| Admin changes own role | 403 |
| Admin deletes test accounts afterwards | Done; only the administrator remains |

## Collection cadence and volume (latest iteration)

| Check | Result |
| --- | --- |
| Feed catalogue | 30 enabled sources (14 original + 16 verified additions) |
| Cadence | every source `interval_minutes = 60`; scheduler tick every 20 s |
| Per-run cap | `ingest_max_items_per_run = 50` |
| Live collection pass | 30/30 feeds processed; published articles 255 → **768**, 214 held for moderation |
| Real new sources on site | Deutsche Welle and Guardian items rendering on `/en/latest`; ESPN/Space.com/Wired/UN News accepted in the pass |
| Scheduler after restart | `/api/health` reports `running: true`, ticks advancing, 43 jobs succeeded, 0 failed |
| Wordmark contrast | browser computed `rgb(247,247,249)` on dark and `rgb(16,16,24)` after switching to light |
| Logo image | loaded (`naturalWidth > 0`) in the browser, 4 wordmark instances on the homepage |

## Not verified / not configured

- **Real email delivery** — no mail provider; reset links go to the server log.
- **AI summarisation/translation against a live provider** — no API key in this environment; the
  fallback path is what ran (and is labelled as such in the UI).
- **Payments, ads, OAuth sign-in, web push** — intentionally disabled until credentials/providers exist.
- **Visual/responsive review and real-device testing** — not performed; no screenshots were requested.
- **Transactional e-mail delivery** — verification/reset links are written to the server log, not emailed.
- **Supabase/PostgreSQL, Google sign-in, payments, map, AI assistant, TTS, comment replies** — not
  connected or not built (see [UPGRADE-STATUS.md](UPGRADE-STATUS.md)).
- **Admin CRUD translations** — still English-only inside the forms and tables.
- **Load/performance testing** — not performed.
