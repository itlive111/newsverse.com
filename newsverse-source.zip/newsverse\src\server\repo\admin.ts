import crypto from "node:crypto";
import { all, get, run, tx, nowIso } from "@/server/db";
import { ensureBootstrapped } from "@/server/db/bootstrap";
import { slugify, recordingTimeMinutes, uniqueSlug, truncate } from "@/server/lib/text";
import { ROLE_RANK, type SessionUser } from "@/server/auth";
import { HttpError } from "@/server/http";
import type { ArticleInput, SourceInput } from "@/lib/validation";
import type { Locale } from "@/i18n";

/* -------------------------------------------------------------------------- */
/* Dashboard                                                                  */
/* -------------------------------------------------------------------------- */

export function adminStats() {
  ensureBootstrapped();
  const one = (sql: string, ...p: unknown[]) => get<{ c: number }>(sql, ...p)?.c ?? 0;
  return {
    published: one("SELECT COUNT(*) AS c FROM articles WHERE status = 'published' AND deleted_at IS NULL"),
    pending: one("SELECT COUNT(*) AS c FROM articles WHERE status = 'pending'"),
    draft: one("SELECT COUNT(*) AS c FROM articles WHERE status = 'draft'"),
    scheduled: one("SELECT COUNT(*) AS c FROM articles WHERE status = 'scheduled'"),
    archived: one("SELECT COUNT(*) AS c FROM articles WHERE status = 'archived'"),
    failedJobs: one("SELECT COUNT(*) AS c FROM jobs WHERE status = 'failed'"),
    queuedJobs: one("SELECT COUNT(*) AS c FROM jobs WHERE status = 'queued'"),
    users: one("SELECT COUNT(*) AS c FROM users"),
    activeUsers: one("SELECT COUNT(DISTINCT user_id) AS c FROM sessions WHERE expires_at > ?", nowIso()),
    views24h: one("SELECT COUNT(*) AS c FROM article_views WHERE viewed_at >= ?", new Date(Date.now() - 86400000).toISOString()),
    viewsTotal: one("SELECT COUNT(*) AS c FROM article_views"),
    pendingComments: one("SELECT COUNT(*) AS c FROM comments WHERE status = 'pending'"),
    sources: one("SELECT COUNT(*) AS c FROM sources WHERE enabled = 1"),
    sourcesFailing: one("SELECT COUNT(*) AS c FROM sources WHERE consecutive_failures > 0"),
    openReports: one("SELECT COUNT(*) AS c FROM reports WHERE status = 'open'"),
    subscribers: one("SELECT COUNT(*) AS c FROM newsletter_subscribers WHERE unsubscribed_at IS NULL"),
    alerts: one("SELECT COUNT(*) AS c FROM alerts WHERE resolved_at IS NULL"),
  };
}

export function viewsSeries(days = 14): { day: string; views: number; articles: number }[] {
  ensureBootstrapped();
  const since = new Date(Date.now() - days * 86400000).toISOString();
  const views = all<{ day: string; c: number }>(
    "SELECT substr(viewed_at, 1, 10) AS day, COUNT(*) AS c FROM article_views WHERE viewed_at >= ? GROUP BY day",
    since,
  );
  const articles = all<{ day: string; c: number }>(
    "SELECT substr(created_at, 1, 10) AS day, COUNT(*) AS c FROM articles WHERE created_at >= ? GROUP BY day",
    since,
  );
  const viewMap = new Map(views.map((v) => [v.day, v.c]));
  const articleMap = new Map(articles.map((a) => [a.day, a.c]));
  const out: { day: string; views: number; articles: number }[] = [];
  for (let i = days - 1; i >= 0; i -= 1) {
    const day = new Date(Date.now() - i * 86400000).toISOString().slice(0, 10);
    out.push({ day, views: viewMap.get(day) ?? 0, articles: articleMap.get(day) ?? 0 });
  }
  return out;
}

export function topArticles(limit = 6, locale: Locale = "en") {
  return all<{ id: string; title: string; views: number; status: string; slug: string }>(
    `SELECT a.id, a.view_count AS views, a.status, COALESCE(t.title, o.title) AS title, COALESCE(t.slug, o.slug) AS slug
     FROM articles a
     LEFT JOIN article_translations t ON t.article_id = a.id AND t.locale = ?
     LEFT JOIN article_translations o ON o.article_id = a.id AND o.locale = a.original_locale
     WHERE a.deleted_at IS NULL ORDER BY a.view_count DESC LIMIT ?`,
    locale, limit,
  );
}

export function topCategories(limit = 6) {
  return all<{ slug: string; name: string; views: number; count: number }>(
    `SELECT c.slug, c.name_i18n AS name, COALESCE(SUM(a.view_count), 0) AS views, COUNT(a.id) AS count
     FROM categories c LEFT JOIN articles a ON a.category_id = c.id AND a.status = 'published'
     GROUP BY c.id ORDER BY views DESC, count DESC LIMIT ?`,
    limit,
  );
}

export function sourceHealth() {
  return all<{
    id: string; name: string; enabled: number; last_run_at: string | null; last_ok_at: string | null;
    consecutive_failures: number; last_error: string | null; trust: number; moderation: string; total_items: number;
    category_slug: string; feed_url: string; interval_minutes: number; locale: string;
  }>("SELECT * FROM sources ORDER BY enabled DESC, name ASC");
}

export function recentAudit(limit = 12) {
  return all<{ actor_email: string | null; action: string; entity: string | null; entity_id: string | null; created_at: string }>(
    "SELECT actor_email, action, entity, entity_id, created_at FROM audit_logs ORDER BY created_at DESC LIMIT ?",
    limit,
  );
}

/* -------------------------------------------------------------------------- */
/* Articles                                                                   */
/* -------------------------------------------------------------------------- */

export type AdminArticleRow = {
  id: string; status: string; published_at: string | null; updated_at: string; created_at: string;
  original_locale: string; title: string; slug: string; source_name: string | null; source_url: string | null;
  category_slug: string | null; is_demo: number; is_ai_assisted: number; view_count: number; quality_score: number;
  scheduled_for: string | null; image_url: string | null; is_breaking: number; video_url: string | null;
};

export function listAdminArticles(filters: { status?: string; q?: string; limit?: number; offset?: number }) {
  ensureBootstrapped();
  let where = "a.deleted_at IS NULL";
  const params: unknown[] = ["en"];
  if (filters.status && filters.status !== "all") {
    where += " AND a.status = ?";
    params.push(filters.status);
  }
  if (filters.q) {
    where += " AND (LOWER(COALESCE(t.title,o.title)) LIKE ? OR LOWER(COALESCE(a.source_name,'')) LIKE ?)";
    const like = `%${filters.q.toLowerCase()}%`;
    params.push(like, like);
  }
  const limit = Math.min(filters.limit ?? 40, 200);
  const offset = filters.offset ?? 0;
  const rows = all<AdminArticleRow>(
    `SELECT a.id, a.status, a.published_at, a.updated_at, a.created_at, a.original_locale, a.source_name,
            a.source_url, a.is_demo, a.is_ai_assisted, a.view_count, a.quality_score, a.scheduled_for,
            a.image_url, a.is_breaking, a.video_url,
            COALESCE(t.title, o.title) AS title, COALESCE(t.slug, o.slug) AS slug, c.slug AS category_slug
     FROM articles a
     LEFT JOIN article_translations t ON t.article_id = a.id AND t.locale = ?
     LEFT JOIN article_translations o ON o.article_id = a.id AND o.locale = a.original_locale
     LEFT JOIN categories c ON c.id = a.category_id
     WHERE ${where} ORDER BY a.created_at DESC LIMIT ? OFFSET ?`,
    ...params, limit, offset,
  );
  const total = get<{ c: number }>(
    `SELECT COUNT(*) AS c FROM articles a
     LEFT JOIN article_translations t ON t.article_id = a.id AND t.locale = 'en'
     LEFT JOIN article_translations o ON o.article_id = a.id AND o.locale = a.original_locale
     WHERE ${where}`,
    ...params.slice(1),
  )?.c ?? 0;
  return { rows, total };
}

export function getAdminArticle(id: string) {
  ensureBootstrapped();
  const article = get<any>("SELECT * FROM articles WHERE id = ?", id);
  if (!article) return null;
  const translations = all<any>("SELECT * FROM article_translations WHERE article_id = ?", id);
  const tags = all<{ name: string }>(
    "SELECT tg.name FROM article_tags at JOIN tags tg ON tg.id = at.tag_id WHERE at.article_id = ?",
    id,
  );
  const source = article.source_id ? get<any>("SELECT * FROM sources WHERE id = ?", article.source_id) : null;
  const logs = all<any>(
    "SELECT level, message, created_at FROM ingestion_logs WHERE source_id = ? ORDER BY created_at DESC LIMIT 8",
    article.source_id ?? "",
  );
  return { article, translations, tags: tags.map((t) => t.name), source, logs };
}

function ensureTranslationSlug(locale: Locale, base: string, ignoreArticleId: string): string {
  return uniqueSlug(slugify(base), (candidate) =>
    !!get(
      "SELECT 1 AS x FROM article_translations WHERE locale = ? AND slug = ? AND article_id <> ?",
      locale, candidate, ignoreArticleId,
    ),
  );
}

export function createArticle(input: ArticleInput, actor: SessionUser): string {
  ensureBootstrapped();
  const category = get<{ id: string }>("SELECT id FROM categories WHERE slug = ?", input.categorySlug);
  const id = crypto.randomUUID();
  const now = nowIso();
  const publishedAt = input.status === "published" ? now : null;
  const original = input.translations[0];
  const body = input.translations.map((t) => t.content).join("\n");
  tx(() => {
    run(
      `INSERT INTO articles (id, category_id, author_user_id, status, published_at, scheduled_for, original_locale,
         image_url, image_credit, source_name, source_url, is_breaking, is_opinion, is_sponsored, is_ai_assisted,
         quality_score, reading_minutes, created_at, updated_at)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,0,?,?,?,?)`,
      id, category?.id ?? null, actor.id, input.status, publishedAt,
      input.status === "scheduled" ? input.scheduledFor ?? null : null, original.locale,
      input.imageUrl || null, input.imageCredit || null, input.sourceName || null, input.sourceUrl || null,
      input.isBreaking ? 1 : 0, input.isOpinion ? 1 : 0, input.isSponsored ? 1 : 0,
      70, recordingTimeMinutes(body), now, now,
    );
    for (const tr of input.translations) {
      run(
        `INSERT INTO article_translations (id, article_id, locale, slug, title, subtitle, summary, content, is_machine, is_original, created_at, updated_at)
         VALUES (?,?,?,?,?,?,?,?,0,?,?,?)`,
        crypto.randomUUID(), id, tr.locale, ensureTranslationSlug(tr.locale, tr.title, id),
        truncate(tr.title, 180), tr.subtitle || null, truncate(tr.summary, 500), tr.content || null,
        tr.locale === original.locale ? 1 : 0, now, now,
      );
    }
    attachTags(id, input.tags);
  });
  auditArticle(actor, "article.create", id, { status: input.status, title: original.title });
  return id;
}

export function updateArticle(id: string, input: ArticleInput, actor: SessionUser): void {
  ensureBootstrapped();
  const existing = get<any>("SELECT * FROM articles WHERE id = ?", id);
  if (!existing) throw new Error("Article not found");
  const category = get<{ id: string }>("SELECT id FROM categories WHERE slug = ?", input.categorySlug);
  const now = nowIso();
  const publishedAt = input.status === "published" ? existing.published_at ?? now : existing.published_at;
  const body = input.translations.map((t) => t.content).join("\n");
  tx(() => {
    run(
      `UPDATE articles SET category_id = ?, status = ?, published_at = ?, scheduled_for = ?, image_url = ?, image_credit = ?,
        source_name = ?, source_url = ?, is_breaking = ?, is_opinion = ?, is_sponsored = ?, reading_minutes = ?, updated_at = ?
       WHERE id = ?`,
      category?.id ?? null, input.status, publishedAt,
      input.status === "scheduled" ? input.scheduledFor ?? null : null,
      input.imageUrl || null, input.imageCredit || null, input.sourceName || null, input.sourceUrl || null,
      input.isBreaking ? 1 : 0, input.isOpinion ? 1 : 0, input.isSponsored ? 1 : 0,
      recordingTimeMinutes(body), now, id,
    );
    for (const tr of input.translations) {
      const current = get<{ id: string; slug: string }>(
        "SELECT id, slug FROM article_translations WHERE article_id = ? AND locale = ?",
        id, tr.locale,
      );
      if (current) {
        // Keep the published slug stable for SEO unless the article is a draft.
        const slug = existing.status === "draft" && !existing.published_at
          ? ensureTranslationSlug(tr.locale, tr.title, id)
          : current.slug;
        run(
          "UPDATE article_translations SET slug = ?, title = ?, subtitle = ?, summary = ?, content = ?, updated_at = ? WHERE id = ?",
          slug, truncate(tr.title, 180), tr.subtitle || null, truncate(tr.summary, 500), tr.content || null, now, current.id,
        );
      } else {
        run(
          `INSERT INTO article_translations (id, article_id, locale, slug, title, subtitle, summary, content, is_machine, is_original, created_at, updated_at)
           VALUES (?,?,?,?,?,?,?,?,0,0,?,?)`,
          crypto.randomUUID(), id, tr.locale, ensureTranslationSlug(tr.locale, tr.title, id),
          truncate(tr.title, 180), tr.subtitle || null, truncate(tr.summary, 500), tr.content || null, now, now,
        );
      }
    }
    run("DELETE FROM article_tags WHERE article_id = ?", id);
    attachTags(id, input.tags);
  });
  auditArticle(actor, "article.update", id, { status: input.status });
}

function attachTags(articleId: string, tags: string): void {
  for (const raw of tags.split(",").map((t) => t.trim()).filter(Boolean).slice(0, 8)) {
    const slug = slugify(raw, 40);
    let tag = get<{ id: string }>("SELECT id FROM tags WHERE slug = ?", slug);
    if (!tag) {
      const tagId = crypto.randomUUID();
      run("INSERT INTO tags (id, slug, name) VALUES (?,?,?)", tagId, slug, truncate(raw, 40));
      tag = { id: tagId };
    }
    run("INSERT OR IGNORE INTO article_tags (article_id, tag_id) VALUES (?,?)", articleId, tag.id);
  }
}

export function setArticleStatus(
  id: string,
  action: "publish" | "unpublish" | "archive" | "restore" | "approve" | "reject" | "delete",
  actor: SessionUser,
): void {
  const now = nowIso();
  const article = get<any>("SELECT * FROM articles WHERE id = ?", id);
  if (!article) throw new Error("Article not found");
  switch (action) {
    case "publish":
    case "approve":
      run("UPDATE articles SET status = 'published', published_at = COALESCE(published_at, ?), deleted_at = NULL, updated_at = ? WHERE id = ?", now, now, id);
      break;
    case "unpublish":
      run("UPDATE articles SET status = 'draft', updated_at = ? WHERE id = ?", now, id);
      break;
    case "archive":
      run("UPDATE articles SET status = 'archived', updated_at = ? WHERE id = ?", now, id);
      break;
    case "restore":
      run("UPDATE articles SET status = 'draft', deleted_at = NULL, updated_at = ? WHERE id = ?", now, id);
      break;
    case "reject":
      run("UPDATE articles SET status = 'archived', moderation_note = 'Rejected during review', updated_at = ? WHERE id = ?", now, id);
      break;
    case "delete":
      run("UPDATE articles SET deleted_at = ?, status = 'archived', updated_at = ? WHERE id = ?", now, now, id);
      break;
  }
  auditArticle(actor, `article.${action}`, id, { previousStatus: article.status });
}

export function mergeDuplicate(primaryId: string, duplicateId: string, actor: SessionUser): void {
  if (primaryId === duplicateId) throw new Error("Cannot merge an article into itself");
  const primary = get<any>("SELECT * FROM articles WHERE id = ?", primaryId);
  const duplicate = get<any>("SELECT * FROM articles WHERE id = ?", duplicateId);
  if (!primary || !duplicate) throw new Error("Article not found");
  tx(() => {
    run(
      "UPDATE articles SET event_key = COALESCE(?, event_key), status = 'archived', moderation_note = ?, updated_at = ? WHERE id = ?",
      primary.event_key, `Merged into ${primaryId}`, nowIso(), duplicateId,
    );
    run(
      "UPDATE articles SET is_breaking = MAX(is_breaking, ?), quality_score = MAX(quality_score, ?) WHERE id = ?",
      duplicate.is_breaking, duplicate.quality_score, primaryId,
    );
  });
  auditArticle(actor, "article.merge", primaryId, { mergedFrom: duplicateId });
}

export function duplicateCandidates(limit = 20) {
  return all<{ id: string; title: string; event_key: string; source_name: string | null }>(
    `SELECT a.id, COALESCE(t.title,o.title) AS title, a.event_key, a.source_name
     FROM articles a
     LEFT JOIN article_translations t ON t.article_id = a.id AND t.locale = 'en'
     LEFT JOIN article_translations o ON o.article_id = a.id AND o.locale = a.original_locale
     WHERE a.event_key IN (
       SELECT event_key FROM articles WHERE event_key IS NOT NULL AND deleted_at IS NULL
       GROUP BY event_key HAVING COUNT(*) > 1
     ) AND a.deleted_at IS NULL ORDER BY a.event_key, a.created_at DESC LIMIT ?`,
    limit,
  );
}

function auditArticle(actor: SessionUser, action: string, id: string, meta?: Record<string, unknown>): void {
  run(
    "INSERT INTO audit_logs (id, actor_user_id, actor_email, action, entity, entity_id, meta, created_at) VALUES (?,?,?,?,?,?,?,?)",
    crypto.randomUUID(), actor.id, actor.email, action, "article", id, meta ? JSON.stringify(meta) : null, nowIso(),
  );
}

/* -------------------------------------------------------------------------- */
/* Sources                                                                    */
/* -------------------------------------------------------------------------- */

export function createSource(input: SourceInput) {
  const now = nowIso();
  const id = crypto.randomUUID();
  run(
    `INSERT INTO sources (id, name, type, feed_url, site_url, category_slug, locale, enabled, interval_minutes, trust, moderation, consecutive_failures, total_items, created_at, updated_at)
     VALUES (?,?, 'rss', ?,?,?,?,?,?,?,?,0,0,?,?)`,
    id, input.name, input.feedUrl, input.siteUrl || null, input.categorySlug, input.locale,
    input.enabled ? 1 : 0, input.intervalMinutes, input.trust, input.moderation, now, now,
  );
  return id;
}

export function updateSource(id: string, patch: Partial<SourceInput>) {
  const current = get<any>("SELECT * FROM sources WHERE id = ?", id);
  if (!current) throw new Error("Source not found");
  run(
    `UPDATE sources SET name = ?, feed_url = ?, site_url = ?, category_slug = ?, locale = ?, enabled = ?,
       interval_minutes = ?, trust = ?, moderation = ?, updated_at = ? WHERE id = ?`,
    patch.name ?? current.name,
    patch.feedUrl ?? current.feed_url,
    patch.siteUrl ?? current.site_url,
    patch.categorySlug ?? current.category_slug,
    patch.locale ?? current.locale,
    patch.enabled === undefined ? current.enabled : patch.enabled ? 1 : 0,
    patch.intervalMinutes ?? current.interval_minutes,
    patch.trust ?? current.trust,
    patch.moderation ?? current.moderation,
    nowIso(), id,
  );
}

/* -------------------------------------------------------------------------- */
/* Users, comments, categories, settings, audits                              */
/* -------------------------------------------------------------------------- */

export function listUsers(q = "") {
  ensureBootstrapped();
  const like = `%${q.toLowerCase()}%`;
  return all<{
    id: string; email: string; name: string; role: string; status: string; locale: string;
    created_at: string; last_seen: string | null; comments: number;
  }>(
    `SELECT u.id, u.email, u.name, u.role, u.status, u.locale, u.created_at,
            (SELECT MAX(created_at) FROM sessions s WHERE s.user_id = u.id) AS last_seen,
            (SELECT COUNT(*) FROM comments c WHERE c.user_id = u.id) AS comments
     FROM users u WHERE LOWER(u.email) LIKE ? OR LOWER(u.name) LIKE ?
     ORDER BY u.created_at DESC LIMIT 200`,
    like, like,
  );
}

export function updateUser(id: string, patch: { role?: string; status?: string }, actor: SessionUser): void {
  const target = get<any>("SELECT * FROM users WHERE id = ?", id);
  if (!target) throw new Error("User not found");
  if (target.id === actor.id && (patch.role || patch.status)) {
    throw new HttpError(403, "You cannot change your own role or status");
  }

  // Privilege escalation guard: an actor may only manage accounts below their
  // own rank, and may never grant a role at or above their own (super_admin
  // is the only role that can do either).
  const actorRank = ROLE_RANK[actor.role as keyof typeof ROLE_RANK] ?? 0;
  const targetRank = ROLE_RANK[target.role as keyof typeof ROLE_RANK] ?? 0;
  if (actor.role !== "super_admin" && (targetRank >= actorRank || (patch.role && (ROLE_RANK[patch.role as keyof typeof ROLE_RANK] ?? 0) >= actorRank))) {
    throw new HttpError(403, "Insufficient privileges for this account change");
  }
  if (target.role === "super_admin" && patch.role && patch.role !== "super_admin" && actor.role !== "super_admin") {
    throw new HttpError(403, "Only a super administrator can change another super administrator");
  }
  if (["admin", "super_admin"].includes(target.role) && patch.role && !["admin", "super_admin"].includes(patch.role)) {
    const admins = get<{ c: number }>("SELECT COUNT(*) AS c FROM users WHERE role IN ('admin','super_admin') AND status = 'active'")?.c ?? 0;
    if (admins <= 1) throw new HttpError(403, "Cannot demote the last administrator");
  }
  if (patch.role) run("UPDATE users SET role = ?, updated_at = ? WHERE id = ?", patch.role, nowIso(), id);
  if (patch.status) {
    run("UPDATE users SET status = ?, updated_at = ? WHERE id = ?", patch.status, nowIso(), id);
    if (patch.status === "suspended") run("DELETE FROM sessions WHERE user_id = ?", id);
  }
  run(
    "INSERT INTO audit_logs (id, actor_user_id, actor_email, action, entity, entity_id, meta, created_at) VALUES (?,?,?,?,?,?,?,?)",
    crypto.randomUUID(), actor.id, actor.email, "user.update", "user", id, JSON.stringify(patch), nowIso(),
  );
}

export function listCommentsAdmin(status = "pending") {
  ensureBootstrapped();
  const where = status === "all" ? "" : "WHERE c.status = ?";
  return all<{ id: string; body: string; status: string; created_at: string; author: string; email: string; article_title: string; article_id: string; slug: string }>(
    `SELECT c.id, c.body, c.status, c.created_at, u.name AS author, u.email, a.id AS article_id,
            COALESCE(t.title, o.title) AS article_title, COALESCE(t.slug, o.slug) AS slug
     FROM comments c
     JOIN users u ON u.id = c.user_id
     JOIN articles a ON a.id = c.article_id
     LEFT JOIN article_translations t ON t.article_id = a.id AND t.locale = 'en'
     LEFT JOIN article_translations o ON o.article_id = a.id AND o.locale = a.original_locale
     ${where} ORDER BY c.created_at DESC LIMIT 200`,
    ...(status === "all" ? [] : [status]),
  );
}

export function moderateComment(id: string, status: string, actor: SessionUser): void {
  run("UPDATE comments SET status = ?, moderated_by = ?, moderated_at = ? WHERE id = ?", status, actor.id, nowIso(), id);
  run(
    "INSERT INTO audit_logs (id, actor_user_id, actor_email, action, entity, entity_id, meta, created_at) VALUES (?,?,?,?,?,?,?,?)",
    crypto.randomUUID(), actor.id, actor.email, `comment.${status}`, "comment", id, null, nowIso(),
  );
}

export function listCategoriesAdmin() {
  return all<any>("SELECT * FROM categories ORDER BY order_index ASC");
}

export function upsertCategory(input: {
  slug: string; names: { uz: string; en: string; ru: string }; icon: string; color?: string;
  orderIndex: number; isActive: boolean; id?: string;
}): string {
  const now = nowIso();
  const existing = input.id
    ? get<{ id: string }>("SELECT id FROM categories WHERE id = ?", input.id)
    : get<{ id: string }>("SELECT id FROM categories WHERE slug = ?", input.slug);
  if (existing) {
    run(
      "UPDATE categories SET slug = ?, name_i18n = ?, icon = ?, color = ?, order_index = ?, is_active = ?, updated_at = ? WHERE id = ?",
      input.slug, JSON.stringify(input.names), input.icon, input.color || null, input.orderIndex,
      input.isActive ? 1 : 0, now, existing.id,
    );
    return existing.id;
  }
  const id = crypto.randomUUID();
  run(
    `INSERT INTO categories (id, slug, name_i18n, description_i18n, icon, color, order_index, is_active, created_at, updated_at)
     VALUES (?,?,?,?,?,?,?,?,?,?)`,
    id, input.slug, JSON.stringify(input.names), "{}", input.icon, input.color || null,
    input.orderIndex, input.isActive ? 1 : 0, now, now,
  );
  return id;
}

export function listAudit(limit = 100) {
  return all<any>("SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT ?", limit);
}

export function listSubscribers() {
  return all<any>("SELECT email, locale, confirmed, created_at, unsubscribed_at FROM newsletter_subscribers ORDER BY created_at DESC LIMIT 500");
}

export function listReports() {
  return all<{ id: string; reason: string; details: string | null; status: string; created_at: string; article_id: string; title: string }>(
    `SELECT r.id, r.reason, r.details, r.status, r.created_at, r.article_id, COALESCE(t.title, o.title) AS title
     FROM reports r JOIN articles a ON a.id = r.article_id
     LEFT JOIN article_translations t ON t.article_id = a.id AND t.locale = 'en'
     LEFT JOIN article_translations o ON o.article_id = a.id AND o.locale = a.original_locale
     ORDER BY r.created_at DESC LIMIT 200`,
  );
}

export function resolveReport(id: string, status: string): void {
  run("UPDATE reports SET status = ? WHERE id = ?", status, id);
}

export function listJobs(status?: string) {
  ensureBootstrapped();
  return all<any>(
    `SELECT j.*, s.name AS source_name FROM jobs j LEFT JOIN sources s ON s.id = j.source_id
     ${status && status !== "all" ? "WHERE j.status = ?" : ""} ORDER BY j.created_at DESC LIMIT 100`,
    ...(status && status !== "all" ? [status] : []),
  );
}

export function retryJob(id: string): void {
  run("UPDATE jobs SET status = 'queued', attempts = 0, next_run_at = ?, last_error = NULL, locked_at = NULL, updated_at = ? WHERE id = ?", nowIso(), nowIso(), id);
}

export function listIngestionLogs(limit = 60) {
  return all<any>(
    `SELECT l.*, s.name AS source_name FROM ingestion_logs l LEFT JOIN sources s ON s.id = l.source_id
     ORDER BY l.created_at DESC LIMIT ?`,
    limit,
  );
}

export function listAlerts() {
  return all<any>("SELECT * FROM alerts WHERE resolved_at IS NULL ORDER BY created_at DESC LIMIT 20");
}

export function resolveAlert(id: string): void {
  run("UPDATE alerts SET resolved_at = ? WHERE id = ?", nowIso(), id);
}
