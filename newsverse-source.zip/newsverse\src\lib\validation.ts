import { z } from "zod";
import { locales } from "@/i18n";

const localeEnum = z.enum(locales);

/** Only http(s) URLs may be stored or fetched; blocks javascript:, data:, file:. */
export const httpUrl = z
  .string()
  .trim()
  .max(1000)
  .url()
  .refine((value) => /^https?:\/\//i.test(value), { message: "Only http(s) URLs are allowed" });

export const emailSchema = z.string().trim().toLowerCase().email().max(254);

export const registerSchema = z.object({
  name: z.string().trim().min(2).max(80),
  username: z
    .string()
    .trim()
    .toLowerCase()
    .min(3, "Username must be at least 3 characters")
    .max(24, "Username is too long")
    .regex(/^[a-z0-9_]+$/, "Use letters, numbers and underscores only"),
  email: emailSchema,
  password: z.string().min(8).max(200),
  locale: localeEnum.default("uz"),
});

export const loginSchema = z.object({
  // Accepts either an e-mail address or a username; kept as `email` for the existing UI contract.
  email: z.string().trim().toLowerCase().min(3).max(254),
  password: z.string().min(1).max(200),
});

export const forgotSchema = z.object({ email: emailSchema });

export const resetSchema = z.object({
  token: z.string().min(10).max(300),
  password: z.string().min(8).max(200),
});

export const accountSchema = z.object({
  name: z.string().trim().min(2).max(80).optional(),
  username: z
    .string()
    .trim()
    .toLowerCase()
    .min(3)
    .max(24)
    .regex(/^[a-z0-9_]+$/)
    .optional(),
  locale: localeEnum.optional(),
  bio: z.string().max(500).optional(),
  avatar_url: httpUrl.max(500).or(z.literal("")).optional(),
  interests: z.array(z.string().max(60)).max(30).optional(),
  notify_email: z.boolean().optional(),
  notify_breaking: z.boolean().optional(),
  notify_comments: z.boolean().optional(),
});

export const passwordChangeSchema = z.object({
  currentPassword: z.string().min(1).max(200),
  newPassword: z.string().min(8).max(200),
});

export const emailChangeSchema = z.object({
  newEmail: emailSchema,
  password: z.string().min(1).max(200),
});

export const commentSchema = z.object({
  articleId: z.string().uuid(),
  body: z.string().trim().min(2).max(2000),
});

export const reportSchema = z.object({
  articleId: z.string().uuid(),
  reason: z.string().trim().min(3).max(80),
  details: z.string().max(2000).optional().default(""),
});

export const newsletterSchema = z.object({
  email: emailSchema,
  locale: localeEnum.default("uz"),
});

export const bookmarkSchema = z.object({
  articleId: z.string().uuid(),
  folder: z.string().max(40).optional(),
});

export const viewSchema = z.object({
  articleId: z.string().uuid(),
  locale: localeEnum.optional(),
});

const translationSchema = z.object({
  locale: localeEnum,
  title: z.string().trim().min(3).max(200),
  subtitle: z.string().max(300).optional().default(""),
  summary: z.string().trim().min(10).max(600),
  content: z.string().max(20000).optional().default(""),
});

export const articleSchema = z.object({
  categorySlug: z.string().max(60),
  status: z.enum(["draft", "pending", "scheduled", "published", "archived"]).default("draft"),
  scheduledFor: z.string().datetime().optional().nullable(),
  imageUrl: httpUrl.or(z.literal("")).optional().default(""),
  imageCredit: z.string().max(200).optional().default(""),
  sourceName: z.string().max(120).optional().default(""),
  sourceUrl: httpUrl.or(z.literal("")).optional().default(""),
  isBreaking: z.boolean().optional().default(false),
  isOpinion: z.boolean().optional().default(false),
  isSponsored: z.boolean().optional().default(false),
  tags: z.string().max(300).optional().default(""),
  translations: z.array(translationSchema).min(1).max(3),
});

export const articleActionSchema = z.object({
  action: z.enum(["publish", "unpublish", "archive", "restore", "approve", "reject", "delete"]),
});

export const sourceSchema = z.object({
  name: z.string().trim().min(2).max(120),
  feedUrl: httpUrl,
  siteUrl: httpUrl.or(z.literal("")).optional().default(""),
  categorySlug: z.string().max(60).default("world"),
  locale: localeEnum.default("en"),
  intervalMinutes: z.coerce.number().int().min(5).max(1440).default(60),
  trust: z.coerce.number().int().min(1).max(5).default(3),
  moderation: z.enum(["auto", "review", "hybrid"]).default("hybrid"),
  enabled: z.boolean().default(true),
});

export const sourcePatchSchema = sourceSchema.partial();

export const categorySchema = z.object({
  slug: z.string().trim().min(2).max(60).regex(/^[a-z0-9-]+$/),
  names: z.object({ uz: z.string().min(1).max(80), en: z.string().min(1).max(80), ru: z.string().min(1).max(80) }),
  icon: z.string().max(30).default("dot"),
  color: z.string().max(20).optional().default(""),
  orderIndex: z.coerce.number().int().min(0).max(999).default(0),
  isActive: z.boolean().default(true),
});

export const userPatchSchema = z.object({
  role: z.enum(["reader", "author", "moderator", "editor", "admin", "super_admin"]).optional(),
  status: z.enum(["active", "suspended"]).optional(),
  commentPrivilege: z.boolean().optional(),
});

export const commentModerationSchema = z.object({ status: z.enum(["approved", "rejected", "pending"]) });

export const settingsSchema = z.record(z.string(), z.string().max(20000));

export const sourceTestSchema = z.object({ feedUrl: httpUrl });

export type ArticleInput = z.infer<typeof articleSchema>;
export type SourceInput = z.infer<typeof sourceSchema>;
