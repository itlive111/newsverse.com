import Link from "next/link";
import type { ReactNode } from "react";

export function SectionHeader({
  title,
  href,
  linkLabel,
  hint,
}: {
  title: string;
  href?: string;
  linkLabel?: string;
  hint?: string;
}) {
  return (
    <div className="mb-4 flex items-end justify-between gap-3">
      <div>
        <h2 className="section-title flex items-center gap-2">
          <span aria-hidden className="inline-block h-5 w-1 rounded-full bg-brand" />
          {title}
        </h2>
        {hint && <p className="mt-1 text-xs subtle">{hint}</p>}
      </div>
      {href && linkLabel && (
        <Link href={href} className="shrink-0 text-xs font-semibold text-brand hover:underline">
          {linkLabel} →
        </Link>
      )}
    </div>
  );
}

export function Panel({ title, children, className = "" }: { title?: string; children: ReactNode; className?: string }) {
  return (
    <section className={`card p-4 sm:p-5 ${className}`}>
      {title && <h2 className="mb-3 text-sm font-extrabold uppercase tracking-wider">{title}</h2>}
      {children}
    </section>
  );
}

export function EmptyState({
  title,
  body,
  actionHref,
  actionLabel,
  icon,
}: {
  title: string;
  body: string;
  actionHref?: string;
  actionLabel?: string;
  icon?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed px-6 py-14 text-center" style={{ borderColor: "var(--line)" }}>
      <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-brand/10 text-brand">{icon}</div>
      <h3 className="font-display text-lg font-bold">{title}</h3>
      <p className="mt-1 max-w-md text-sm subtle">{body}</p>
      {actionHref && actionLabel && (
        <Link href={actionHref} className="btn-primary mt-4">{actionLabel}</Link>
      )}
    </div>
  );
}

export function Pagination({
  basePath,
  page,
  totalPages,
  prevLabel,
  nextLabel,
}: {
  basePath: string;
  page: number;
  totalPages: number;
  prevLabel: string;
  nextLabel: string;
}) {
  if (totalPages <= 1) return null;
  const join = (p: number) => `${basePath}${basePath.includes("?") ? "&" : "?"}page=${p}`;
  const pages = new Set<number>([1, totalPages, page, page - 1, page + 1]);
  const sorted = [...pages].filter((p) => p >= 1 && p <= totalPages).sort((a, b) => a - b);
  return (
    <nav aria-label="pagination" className="mt-8 flex flex-wrap items-center justify-center gap-1.5">
      {page > 1 && <Link href={join(page - 1)} className="btn-ghost !py-1.5 !text-xs">{prevLabel}</Link>}
      {sorted.map((p, i) => (
        <span key={p} className="flex items-center gap-1.5">
          {i > 0 && p - sorted[i - 1]! > 1 && <span className="px-1 text-xs subtle">…</span>}
          <Link
            href={join(p)}
            aria-current={p === page ? "page" : undefined}
            className={`flex h-8 min-w-8 items-center justify-center rounded-lg border px-2 text-xs font-semibold ${
              p === page ? "border-brand bg-brand text-white" : "hover:border-brand"
            }`}
            style={{ borderColor: p === page ? "#FF1538" : "var(--line)" }}
          >
            {p}
          </Link>
        </span>
      ))}
      {page < totalPages && <Link href={join(page + 1)} className="btn-ghost !py-1.5 !text-xs">{nextLabel}</Link>}
    </nav>
  );
}
