import crypto from "node:crypto";
import { all, get, run, tx, nowIso } from "@/server/db";
import { ensureBootstrapped } from "@/server/db/bootstrap";
import { getSetting, getBoolSetting, getNumberSetting } from "@/server/repo/settings";
import { canonicalizeUrl, recordingTimeMinutes, sha256, slugify, truncate, uniqueSlug } from "@/server/lib/text";
import { eventKey, isNearDuplicate, titleHash } from "@/server/ingest/dedupe";
import { fetchFeed, type FeedItem } from "@/server/ingest/rss";
import { aiStatus, classify, qualityScore, summarize, translate } from "@/server/ingest/ai";
import { locales, type Locale } from "@/i18n";

export type SourceRow = {
  id: string;
  name: string;
  type: string;
  feed_url: string;
  site_url: string | null;
  category_slug: string;
  locale: string;
  enabled: number;
  interval_minutes: number;
  trust: number;
  moderation: string;
  last_run_at: string | null;
  last_ok_at: string | null;
  last_error: string | null;
  consecutive_failures: number;
  total_items: number;
};

export type IngestResult = {
  sourceId: string;
  sourceName: string;
  fetched: number;
  accepted: number;
  duplicates: number;
  pending: number;
  published: number;
  translated: number;
  error: string | null;
};

const HIGH_RISK_CATEGORIES = new Set(["politics", "health", "economy", "security", "breaking"]);

export function logIngestion(params: {
  sourceId?: string | null;
  jobId?: string | null;
  level: "info" | "warn" | "error";
  message: string;
  meta?: Record<string, unknown>;
}): void {
  run(
    "INSERT INTO ingestion_logs (id, source_id, job_id, level, message, meta, created_at) VALUES (?,?,?,?,?,?,?)",
    crypto.randomUUID(), params.sourceId ?? null, params.jobId ?? null, params.level,
    params.message.slice(0, 500), params.meta ? JSON.stringify(params.meta) : null, nowIso(),
  );
}

function ensureTag(name: string): string {
  const slug = slugify(name, 40);
  const existing = get<{ id: string }>("SELECT id FROM tags WHERE slug = ?", slug);
  if (existing) return existing.id;
  const id = crypto.randomUUID();
  run("INSERT INTO tags (id, slug, name) VALUES (?,?,?)", id, slug, truncate(name, 40));
  return id;
}

function uniqueTranslationSlug(locale: Locale, base: string): string {
  return uniqueSlug(base, (candidate) =>
    !!get("SELECT 1 AS x FROM article_translations WHERE locale = ? AND slug = ?", locale, candidate),
  );
}

function isBreaking(title: string, categories: string[], sourceCategory: string): boolean {
  if (sourceCategory === "breaking") return true;
  const keywords = getSetting("breaking_keywords", "breaking,urgent")
    .split(",")
    .map((k) => k.trim().toLowerCase())
    .filter(Boolean);
  const haystack = `${title} ${categories.join(" ")}`.toLowerCase();
  return keywords.some((k) => haystack.includes(k));
}

/** Recent titles used for duplicate/near-duplicate detection within one run. */
type RecentTitle = { id: string; title: string; title_hash: string | null; event_key: string | null; source_id: string | null };

function loadRecentTitles(): RecentTitle[] {
  const since = new Date(Date.now() - 7 * 86400000).toISOString();
  return all<RecentTitle>(
    `SELECT a.id, a.title_hash, a.event_key, a.source_id, COALESCE(t.title, o.title) AS title
     FROM articles a
     LEFT JOIN article_translations t ON t.article_id = a.id AND t.locale = a.original_locale
     LEFT JOIN article_translations o ON o.article_id = a.id AND o.locale = a.original_locale
     WHERE a.created_at >= ? AND a.deleted_at IS NULL ORDER BY a.created_at DESC LIMIT 400`,
    since,
  );
}

export async function ingestSource(sourceId: string, jobId?: string | null): Promise<IngestResult> {
  ensureBootstrapped();
  const source = get<SourceRow>("SELECT * FROM sources WHERE id = ?", sourceId);
  if (!source) throw new Error("Source not found");
  const result: IngestResult = {
    sourceId: source.id,
    sourceName: source.name,
    fetched: 0,
    accepted: 0,
    duplicates: 0,
    pending: 0,
    published: 0,
    translated: 0,
    error: null,
  };
  if (!source.enabled) {
    logIngestion({ sourceId, jobId, level: "info", message: "Source disabled; skipped" });
    return result;
  }

  let feed;
  try {
    feed = await fetchFeed(source.feed_url);
  } catch (err) {
    const message = (err as Error).message;
    run(
      "UPDATE sources SET last_run_at = ?, consecutive_failures = consecutive_failures + 1, last_error = ?, updated_at = ? WHERE id = ?",
      nowIso(), message.slice(0, 400), nowIso(), sourceId,
    );
    logIngestion({ sourceId, jobId, level: "error", message: `Feed fetch failed: ${message}` });
    throw err;
  }

  const maxItems = getNumberSetting("ingest_max_items_per_run", 50);
  const items = feed.items.slice(0, maxItems);
  result.fetched = items.length;

  const mode = getSetting("moderation_mode", "hybrid");
  const autoPublishTrust = getNumberSetting("auto_publish_trust", 4);
  const aiEnabled = aiStatus().enabled && getBoolSetting("ai_enabled", true);
  const aiTranslationBudget = { left: Number(process.env.AI_TRANSLATIONS_PER_RUN ?? 6) };
  const categorySlugs = all<{ slug: string }>("SELECT slug FROM categories WHERE is_active = 1").map((c) => c.slug);
  const defaultCategory = get<{ id: string; slug: string }>(
    "SELECT id, slug FROM categories WHERE slug = ?",
    source.category_slug,
  );
  const recent = loadRecentTitles();
  const sourceLocale = (locales.includes(source.locale as Locale) ? source.locale : "en") as Locale;

  for (const item of items) {
    try {
      const accepted = await processItem({
        item, source, sourceLocale, defaultCategory, mode, autoPublishTrust, aiEnabled,
        aiTranslationBudget, categorySlugs, recent, result,
      });
      if (accepted) {
        result.accepted += 1;
        recent.push({
          id: accepted.id, title: item.title, title_hash: accepted.titleHash,
          event_key: accepted.eventKey, source_id: source.id,
        });
      }
    } catch (err) {
      logIngestion({
        sourceId, jobId, level: "warn",
        message: `Item skipped: ${(err as Error).message}`,
        meta: { link: item.link },
      });
    }
  }

  run(
    `UPDATE sources SET last_run_at = ?, last_ok_at = ?, last_error = NULL, consecutive_failures = 0,
       total_items = total_items + ?, updated_at = ? WHERE id = ?`,
    nowIso(), nowIso(), result.accepted, nowIso(), sourceId,
  );
  logIngestion({
    sourceId, jobId, level: "info",
    message: `Collected ${result.fetched} items, accepted ${result.accepted} (${result.published} published, ${result.pending} pending), ${result.duplicates} duplicates`,
    meta: result,
  });
  return result;
}

async function processItem(args: {
  item: FeedItem;
  source: SourceRow;
  sourceLocale: Locale;
  defaultCategory: { id: string; slug: string } | undefined;
  mode: string;
  autoPublishTrust: number;
  aiEnabled: boolean;
  aiTranslationBudget: { left: number };
  categorySlugs: string[];
  recent: RecentTitle[];
  result: IngestResult;
}): Promise<{ id: string; titleHash: string; eventKey: string } | null> {
  const { item, source, sourceLocale, defaultCategory, mode, autoPublishTrust, aiEnabled, recent, result } = args;
  if (!item.title || item.title.length < 8) throw new Error("Title too short or missing");
  if (!item.link || !/^https?:\/\//i.test(item.link)) throw new Error("Invalid article URL");

  const urlHash = sha256(canonicalizeUrl(item.link));
  const exact = get<{ id: string }>("SELECT id FROM articles WHERE url_hash = ?", urlHash);
  if (exact) {
    result.duplicates += 1;
    return null;
  }

  const tHash = titleHash(item.title);
  const exactTitle = get<{ id: string }>("SELECT id FROM articles WHERE title_hash = ? LIMIT 1", tHash);
  if (exactTitle) {
    result.duplicates += 1;
    return null;
  }

  let nearDuplicate = recent.find((r) => isNearDuplicate(r.title, item.title));
  if (nearDuplicate && nearDuplicate.source_id === source.id) {
    result.duplicates += 1;
    return null;
  }

  const body = item.content || item.summary;
  const classification = aiEnabled
    ? await classify(item.title, body, defaultCategory?.slug ?? "other", args.categorySlugs)
    : null;
  const categorySlug = classification?.category ?? defaultCategory?.slug ?? "other";
  const category = get<{ id: string }>("SELECT id FROM categories WHERE slug = ?", categorySlug);

  const summaryResult = await summarize(item.title, body || item.summary || item.title);
  const credit = item.imageUrl ? `${source.name}` : null;
  const breaking = isBreaking(item.title, item.categories, source.category_slug);
  const risk = classification?.risk ?? "low";
  const quality = classification?.quality ?? qualityScore({
    title: item.title, bodyLength: body.length, hasImage: !!item.imageUrl, sourceTrust: source.trust,
  });

  // Moderation rules: auto-publish only for trusted, low-risk sources.
  const rule = source.moderation || mode;
  let status: "published" | "pending" = "published";
  if (rule === "review" || mode === "review") status = "pending";
  else if (rule === "hybrid" || mode === "hybrid") {
    status = source.trust >= autoPublishTrust && !HIGH_RISK_CATEGORIES.has(categorySlug) && risk === "low"
      ? "published"
      : "pending";
  }
  if (mode === "auto" && rule === "auto") status = "published";

  const now = nowIso();
  const id = crypto.randomUUID();
  const publishedAt = item.publishedAt;
  const content = truncate(body || item.summary, 1200);
  const eventKeyValue = nearDuplicate?.event_key ?? nearDuplicate?.id ?? eventKey(item.title);

  // Only excerpts + our own summary are stored; the reader always links out.
  const originalSlug = uniqueTranslationSlug(sourceLocale, slugify(item.title));
  const inserted = tx(() => {
    run(
      `INSERT INTO articles (id, category_id, source_id, status, published_at, original_locale, image_url, image_credit,
         source_name, source_url, canonical_url, url_hash, title_hash, event_key, is_breaking, is_ai_assisted,
         quality_score, reading_minutes, video_url, created_at, updated_at)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      id, category?.id ?? defaultCategory?.id ?? null, source.id, status, publishedAt, sourceLocale,
      item.imageUrl, credit, source.name, item.link, item.link, urlHash, tHash, eventKeyValue,
      breaking ? 1 : 0, summaryResult.mode === "ai" || classification?.mode === "ai" ? 1 : 0,
      quality, recordingTimeMinutes(content || item.summary), item.videoUrl, now, now,
    );
    run(
      `INSERT INTO article_translations (id, article_id, locale, slug, title, summary, content, is_machine, is_original, created_at, updated_at)
       VALUES (?,?,?,?,?,?,?,?,1,?,?)`,
      crypto.randomUUID(), id, sourceLocale, originalSlug, item.title, summaryResult.summary,
      content || null,
      summaryResult.mode === "ai" ? 1 : 0, now, now,
    );
    return true;
  });
  if (!inserted) throw new Error("Insert failed");

  // Tags from classification (bounded).
  const tags = classification?.tags ?? [];
  for (const tag of tags.slice(0, 5)) {
    if (!tag || tag.length < 3) continue;
    try {
      run("INSERT OR IGNORE INTO article_tags (article_id, tag_id) VALUES (?,?)", id, ensureTag(tag));
    } catch { /* tag failure should not fail ingestion */ }
  }

  // Machine translations for the other two locales (never presented as human).
  let translated = 0;
  if (aiEnabled && args.aiTranslationBudget.left > 0) {
    for (const target of locales.filter((l) => l !== sourceLocale)) {
      if (args.aiTranslationBudget.left <= 0) break;
      args.aiTranslationBudget.left -= 1;
      const tr = await translate(
        { title: item.title, summary: summaryResult.summary, content },
        sourceLocale,
        target,
      );
      if (!tr) continue;
      const slug = uniqueTranslationSlug(target, slugify(tr.title));
      run(
        `INSERT OR IGNORE INTO article_translations (id, article_id, locale, slug, title, summary, content, is_machine, is_original, created_at, updated_at)
         VALUES (?,?,?,?,?,?,?,1,0,?,?)`,
        crypto.randomUUID(), id, target, slug, tr.title, tr.summary, tr.content ?? null, now, now,
      );
      translated += 1;
    }
  }
  result.translated += translated;
  if (status === "published") result.published += 1;
  else result.pending += 1;

  return { id, titleHash: tHash, eventKey: eventKeyValue };
}
