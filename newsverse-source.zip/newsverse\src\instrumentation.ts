/**
 * Next.js server instrumentation. Runs once per server process on boot.
 * This is where the automated ingestion scheduler is started, so collection
 * keeps happening with no browser open and no user visit.
 *
 * The node-only imports live behind a NEXT_RUNTIME check so the edge build
 * (which compiles together with middleware) never bundles `node:sqlite`,
 * `node:crypto` or the filesystem.
 */
export async function register(): Promise<void> {
  if (process.env.NEXT_RUNTIME === "nodejs") {
    try {
      const { bootstrapServer } = await import("@/server/boot");
      await bootstrapServer();
    } catch (err) {
      console.error("[newsverse] server bootstrap failed:", err);
    }
  }
}
