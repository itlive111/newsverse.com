import { adminGate } from "@/server/adminPage";
import Link from "next/link";
import { notFound } from "next/navigation";
import { formatDate, formatNumber, isLocale, t } from "@/i18n";
import { duplicateCandidates, listAdminArticles } from "@/server/repo/admin";
import { AdminSection, EmptyRow, StatusBadge, Td, Th } from "@/components/admin/ui";
import { ActionButton } from "@/components/admin/action-button";

export const dynamic = "force-dynamic";

const STATUSES = ["all", "published", "pending", "scheduled", "draft", "archived"];

export default async function AdminArticles({
  params,
  searchParams,
}: {
  params: Promise<{ locale: string }>;
  searchParams: Promise<{ status?: string; q?: string; page?: string }>;
}) {
  const { locale: raw } = await params;
  if (!isLocale(raw)) notFound();
  const locale = raw;
  await adminGate();
  const sp = await searchParams;
  const status = STATUSES.includes(sp.status ?? "") ? (sp.status as string) : "all";
  const q = (sp.q ?? "").slice(0, 80);
  const page = Math.max(1, Number(sp.page ?? 1) || 1);
  const perPage = 25;
  const { rows, total } = listAdminArticles({ status, q, limit: perPage, offset: (page - 1) * perPage });
  const pages = Math.max(1, Math.ceil(total / perPage));
  const duplicates = duplicateCandidates(30);
  const duplicateGroups = Object.values(
    duplicates.reduce<Record<string, { title: string; items: typeof duplicates }>>((acc, row) => {
      if (!row.event_key) return acc;
      acc[row.event_key] ??= { title: row.title, items: [] };
      acc[row.event_key].items.push(row);
      return acc;
    }, {}),
  );

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <h1 className="font-display text-2xl font-black tracking-tight">{t(locale, "admin.articles")}</h1>
        <Link href={`/${locale}/admin/articles/new`} className="btn-primary !py-1.5 !text-xs">{t(locale, "admin.newArticle")}</Link>
      </div>

      <AdminSection>
        <form method="get" className="flex flex-wrap items-end gap-2">
          <div className="min-w-[180px] flex-1">
            <label className="label" htmlFor="q">{t(locale, "search.title")}</label>
            <input id="q" name="q" defaultValue={q} className="input !py-1.5 !text-xs" placeholder={t(locale, "search.placeholder")} />
          </div>
          <div>
            <label className="label" htmlFor="status">{t(locale, "admin.status")}</label>
            <select id="status" name="status" defaultValue={status} className="input !py-1.5 !text-xs">
              {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          <button className="btn-ghost !py-1.5 !text-xs" type="submit">{t(locale, "common.filter")}</button>
          <span className="ml-auto text-[11px] subtle">{formatNumber(total, locale)} {t(locale, "common.results")}</span>
        </form>
      </AdminSection>

      <AdminSection>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr>
                <Th>{t(locale, "admin.title")}</Th>
                <Th>{t(locale, "admin.status")}</Th>
                <Th>{t(locale, "search.category")}</Th>
                <Th>{t(locale, "admin.sourceHealth")}</Th>
                <Th>Views</Th>
                <Th>{t(locale, "common.updated")}</Th>
                <Th>{t(locale, "admin.actions")}</Th>
              </tr>
            </thead>
            <tbody>
              {rows.map((a) => (
                <tr key={a.id} className="border-t" style={{ borderColor: "var(--line)" }}>
                  <Td>
                    <Link href={`/${locale}/admin/articles/${a.id}`} className="line-clamp-2 font-semibold hover:text-brand">{a.title ?? "—"}</Link>
                    <p className="mt-0.5 text-[10px] subtle">{a.id.slice(0, 8)}{a.is_demo ? " · demo" : ""}{a.is_ai_assisted ? " · AI-assisted" : ""}</p>
                  </Td>
                  <Td><StatusBadge status={a.status} /></Td>
                  <Td className="uppercase subtle">{a.category_slug}</Td>
                  <Td className="subtle">{a.source_name ?? "NewsVerse"}</Td>
                  <Td>{formatNumber(a.view_count, locale)}</Td>
                  <Td className="subtle">{formatDate(a.updated_at, locale)}</Td>
                  <Td>
                    <div className="flex flex-wrap gap-1">
                      <Link href={`/${locale}/admin/articles/${a.id}`} className="btn-ghost !px-2 !py-1 !text-[11px]">{t(locale, "common.edit")}</Link>
                      {a.status !== "published" ? (
                        <ActionButton endpoint={`/api/admin/articles/${a.id}`} body={{ action: "publish" }} label={t(locale, "admin.publish")} />
                      ) : (
                        <ActionButton endpoint={`/api/admin/articles/${a.id}`} body={{ action: "unpublish" }} label={t(locale, "admin.archive")} />
                      )}
                      {a.status !== "archived" && (
                        <ActionButton endpoint={`/api/admin/articles/${a.id}`} body={{ action: "archive" }} label={t(locale, "admin.archive")} />
                      )}
                    </div>
                  </Td>
                </tr>
              ))}
              {!rows.length && <EmptyRow colSpan={7} text={t(locale, "common.noResults")} />}
            </tbody>
          </table>
        </div>

        {pages > 1 && (
          <div className="mt-3 flex items-center justify-between text-[11px]">
            <span className="subtle">{t(locale, "common.of")} {pages}</span>
            <div className="flex gap-2">
              {page > 1 && (
                <Link href={`?status=${status}&q=${encodeURIComponent(q)}&page=${page - 1}`} className="btn-ghost !py-1 !text-xs">{t(locale, "common.prev")}</Link>
              )}
              {page < pages && (
                <Link href={`?status=${status}&q=${encodeURIComponent(q)}&page=${page + 1}`} className="btn-ghost !py-1 !text-xs">{t(locale, "common.next")}</Link>
              )}
            </div>
          </div>
        )}
      </AdminSection>

      <AdminSection title={t(locale, "admin.duplicates")}>
        {duplicateGroups.length ? (
          <div className="space-y-3 text-xs">
            <p className="subtle">
              Articles grouped by shared event fingerprint. Open a record and use “{t(locale, "admin.merge")}” to fold duplicates into one story.
            </p>
            {duplicateGroups.map((group, i) => (
              <div key={i} className="rounded-lg border p-2" style={{ borderColor: "var(--line)" }}>
                <p className="font-semibold">{group.title}</p>
                <ul className="mt-1 flex flex-wrap gap-2">
                  {group.items.map((item) => (
                    <li key={item.id}>
                      <Link href={`/${locale}/admin/articles/${item.id}`} className="text-[10px] underline">
                        {item.source_name ?? item.id.slice(0, 8)}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-xs subtle">{t(locale, "common.noResults")}</p>
        )}
      </AdminSection>
    </div>
  );
}
