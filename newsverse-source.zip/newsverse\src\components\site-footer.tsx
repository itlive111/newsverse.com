import Link from "next/link";
import { t, type Locale } from "@/i18n";
import { listCategories } from "@/server/repo/content";
import { getSetting } from "@/server/repo/settings";
import { NewsletterForm } from "@/components/newsletter-form";
import { BrandLogo } from "@/components/brand-logo";

export function SiteFooter({ locale }: { locale: Locale }) {
  const categories = listCategories(locale).slice(0, 8);
  const contact = getSetting("contact_email", "hello@newsverse.example");
  const year = new Date().getFullYear();
  return (
    <footer className="mt-16 border-t" style={{ borderColor: "var(--line)" }}>
      <div className="border-b" style={{ borderColor: "var(--line)" }}>
        <div className="container-nv grid gap-6 py-10 md:grid-cols-[1.2fr_1fr] md:items-center">
          <div>
            <p className="kicker">{t(locale, "footer.newsletter")}</p>
            <h2 className="mt-1 font-display text-2xl font-extrabold">{t(locale, "newsletter.title")}</h2>
            <p className="mt-1 max-w-md text-sm subtle">{t(locale, "newsletter.desc")}</p>
          </div>
          <NewsletterForm locale={locale} />
        </div>
      </div>
      <div className="container-nv grid gap-8 py-12 sm:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr_1fr]">
        <div>
          <BrandLogo href={`/${locale}`} size="md" />
          <p className="mt-3 max-w-sm text-sm leading-relaxed subtle">{t(locale, "footer.editorial")}</p>
          <p className="mt-3 text-xs subtle">{t(locale, "brand.tagline")}</p>
        </div>
        <div>
          <p className="label">{t(locale, "footer.sections")}</p>
          <ul className="space-y-2 text-sm">
            {categories.map((c) => (
              <li key={c.slug}>
                <Link href={`/${locale}/category/${c.slug}`} className="subtle transition hover:text-brand">{c.name}</Link>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <p className="label">{t(locale, "footer.company")}</p>
          <ul className="space-y-2 text-sm">
            <li><Link href={`/${locale}/about`} className="subtle hover:text-brand">{t(locale, "footer.about")}</Link></li>
            <li><Link href={`/${locale}/sources`} className="subtle hover:text-brand">{t(locale, "footer.sources")}</Link></li>
            <li><Link href={`/${locale}/privacy`} className="subtle hover:text-brand">{t(locale, "footer.privacy")}</Link></li>
            <li><Link href={`/${locale}/terms`} className="subtle hover:text-brand">{t(locale, "footer.terms")}</Link></li>
            <li>
              <a href={`mailto:${contact}`} className="subtle hover:text-brand">{t(locale, "footer.contact")}</a>
            </li>
          </ul>
        </div>
        <div>
          <p className="label">{t(locale, "footer.follow")}</p>
          <ul className="space-y-2 text-sm">
            <li><a href="/feed.xml" className="subtle hover:text-brand">RSS</a></li>
            <li><Link href={`/${locale}/search`} className="subtle hover:text-brand">{t(locale, "nav.search")}</Link></li>
            <li><Link href={`/${locale}/trending`} className="subtle hover:text-brand">{t(locale, "nav.trending")}</Link></li>
            <li><a href="/sitemap.xml" className="subtle hover:text-brand">{t(locale, "footer.sitemap")}</a></li>
            <li><a href="/manifest.webmanifest" className="subtle hover:text-brand">PWA</a></li>
          </ul>
        </div>
      </div>
      <div className="border-t" style={{ borderColor: "var(--line)" }}>
        <div className="container-nv flex flex-col gap-2 py-5 text-[11px] subtle sm:flex-row sm:items-center sm:justify-between">
          <p>© {year} NewsVerse. {t(locale, "footer.rights")}</p>
          <p>
            {t(locale, "footer.editorial")}
          </p>
        </div>
      </div>
    </footer>
  );
}
