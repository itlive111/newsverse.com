import { adminGate } from "@/server/adminPage";
import { notFound } from "next/navigation";
import { isLocale, t } from "@/i18n";
import { getAllSettings } from "@/server/repo/settings";
import { SettingsForm, type SettingField } from "@/components/admin/settings-form";
import { AdminSection } from "@/components/admin/ui";

export const dynamic = "force-dynamic";

export default async function AdminSettings({ params }: { params: Promise<{ locale: string }> }) {
  const { locale: raw } = await params;
  if (!isLocale(raw)) notFound();
  const locale = raw;
  await adminGate("admin");
  const settings = getAllSettings();

  const general: SettingField[] = [
    { key: "site_name", label: "Site name", placeholder: "NewsVerse" },
    { key: "site_tagline", label: "Tagline", placeholder: "Dunyodagi eng so‘nggi yangiliklar bir joyda!" },
    { key: "contact_email", label: "Contact email", placeholder: "hello@example.com" },
    { key: "default_locale", label: "Default locale", type: "select", options: [
      { value: "uz", label: "Uzbek" }, { value: "en", label: "English" }, { value: "ru", label: "Russian" },
    ] },
    { key: "comments_enabled", label: "Reader comments", type: "checkbox", hint: "Allow signed-in readers to comment" },
    { key: "newsletter_enabled", label: "Newsletter signup", type: "checkbox", hint: "Show the subscription form" },
  ];

  const seo: SettingField[] = [
    { key: "seo_default_title", label: "Default meta title", placeholder: "NewsVerse — news from Uzbekistan and the world" },
    { key: "seo_default_description", label: "Default meta description", type: "textarea" },
    { key: "seo_keywords", label: "Keywords", type: "textarea", hint: "Comma separated, used sparingly" },
  ];

  const widgets: SettingField[] = [
    { key: "markets_widget", label: "Markets widget", type: "checkbox", hint: "Requires a configured data provider" },
    { key: "weather_widget", label: "Weather widget", type: "checkbox", hint: "Requires a configured data provider" },
  ];

  const monetization: SettingField[] = [
    { key: "ads_enabled", label: "Display ads", type: "checkbox", hint: "Only enable with a real ad network configured" },
    { key: "payments_enabled", label: "Premium subscriptions", type: "checkbox", hint: "Requires a payment provider and API keys" },
  ];

  return (
    <div className="space-y-4">
      <h1 className="font-display text-2xl font-black tracking-tight">{t(locale, "admin.settings")}</h1>

      <AdminSection title="General"><SettingsForm locale={locale} fields={general} initial={settings} /></AdminSection>
      <AdminSection title="SEO"><SettingsForm locale={locale} fields={seo} initial={settings} /></AdminSection>
      <AdminSection title="Widgets"><SettingsForm locale={locale} fields={widgets} initial={settings} /></AdminSection>
      <AdminSection title="Monetization">
        <SettingsForm locale={locale} fields={monetization} initial={settings} />
        <p className="mt-3 text-[11px] subtle">
          Monetization stays off until a payment provider is configured server-side. NewsVerse never renders a fake
          checkout or fabricated revenue figures.
        </p>
      </AdminSection>

      <p className="text-[11px] subtle">
        API keys, database paths and AI provider credentials are environment variables, not settings. They never reach the browser.
      </p>
    </div>
  );
}
