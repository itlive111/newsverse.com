import crypto from "node:crypto";
import { get, run, nowIso } from "@/server/db";
import { hashPassword, audit, rateLimit, clientIpFromHeaders } from "@/server/auth";
import { json, fail, parseBody, handleError } from "@/server/http";
import { resetSchema } from "@/lib/validation";

export async function POST(request: Request) {
  try {
    const ip = clientIpFromHeaders(request.headers) ?? "unknown";
    if (!rateLimit(`reset:${ip}`, 10, 60 * 60 * 1000)) return fail("rate_limited", 429);
    const input = await parseBody(request, resetSchema);
    const hash = crypto.createHash("sha256").update(input.token).digest("hex");
    const token = get<{ id: string; user_id: string; expires_at: string; used_at: string | null }>(
      "SELECT id, user_id, expires_at, used_at FROM auth_tokens WHERE token_hash = ? AND kind = 'reset'",
      hash,
    );
    if (!token || token.used_at || new Date(token.expires_at).getTime() < Date.now()) {
      return fail("invalid_token", 400);
    }
    run("UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?", hashPassword(input.password), nowIso(), token.user_id);
    run("UPDATE auth_tokens SET used_at = ? WHERE id = ?", nowIso(), token.id);
    run("DELETE FROM sessions WHERE user_id = ?", token.user_id);
    const user = get<{ email: string }>("SELECT email FROM users WHERE id = ?", token.user_id);
    if (user) audit({ actor: { id: token.user_id, email: user.email }, action: "auth.password_reset", entity: "user", entityId: token.user_id });
    return json({ ok: true });
  } catch (err) {
    return handleError(err);
  }
}
