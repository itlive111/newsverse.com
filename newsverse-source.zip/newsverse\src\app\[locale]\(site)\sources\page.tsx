import type { Metadata } from "next";
import { resolveLocale, t, formatDate, type Locale } from "@/i18n";
import { sourceHealth } from "@/server/repo/admin";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const locale = resolveLocale((await params).locale);
  return { title: t(locale, "footer.sources"), alternates: { canonical: `/${locale}/sources` } };
}

export default async function SourcesPage({ params }: { params: Promise<{ locale: string }> }) {
  const locale = resolveLocale((await params).locale) as Locale;
  const sources = sourceHealth();

  return (
    <div className="container-nv py-10">
      <p className="kicker">{t(locale, "footer.sources")}</p>
      <h1 className="mt-2 font-display text-4xl font-extrabold tracking-tight">{t(locale, "footer.sources")}</h1>
      <p className="mt-2 max-w-2xl text-sm leading-relaxed subtle">{t(locale, "footer.editorial")}</p>

      <div className="mt-8 overflow-x-auto rounded-2xl border" style={{ borderColor: "var(--line)" }}>
        <table className="w-full min-w-[720px] text-left text-sm">
          <thead className="text-[11px] uppercase tracking-wider subtle">
            <tr className="border-b" style={{ borderColor: "var(--line)" }}>
              <th className="px-4 py-3">{t(locale, "search.source")}</th>
              <th className="px-4 py-3">RSS</th>
              <th className="px-4 py-3">{t(locale, "search.category")}</th>
              <th className="px-4 py-3">{t(locale, "common.language")}</th>
              <th className="px-4 py-3">{t(locale, "admin.status")}</th>
              <th className="px-4 py-3">{t(locale, "common.updated")}</th>
            </tr>
          </thead>
          <tbody>
            {sources.map((source) => (
              <tr key={source.id} className="border-b last:border-0" style={{ borderColor: "var(--line)" }}>
                <td className="px-4 py-3 font-semibold">
                  <a href={source.feed_url} target="_blank" rel="noopener noreferrer" className="hover:text-brand">{source.name}</a>
                </td>
                <td className="px-4 py-3 text-xs subtle">trust {source.trust}/5 · {source.moderation}</td>
                <td className="px-4 py-3 text-xs uppercase subtle">{source.category_slug}</td>
                <td className="px-4 py-3 text-xs uppercase subtle">{source.locale}</td>
                <td className="px-4 py-3 text-xs">
                  {source.consecutive_failures > 0 ? (
                    <span className="text-brand">error ×{source.consecutive_failures}</span>
                  ) : source.enabled ? (
                    <span className="text-emerald-400">active</span>
                  ) : (
                    <span className="subtle">disabled</span>
                  )}
                </td>
                <td className="px-4 py-3 text-xs subtle">{source.last_ok_at ? formatDate(source.last_ok_at, locale) : "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="mt-4 text-xs subtle">
        {t(locale, "article.sourceNotice")}
      </p>
    </div>
  );
}
