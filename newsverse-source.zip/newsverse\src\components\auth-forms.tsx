"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { t, type Locale } from "@/i18n";

function errorMessage(code: string, locale: Locale): string {
  switch (code) {
    case "invalid_credentials":
      return t(locale, "auth.invalid");
    case "account_suspended":
      return t(locale, "auth.suspended");
    case "email_taken":
      return t(locale, "auth.emailTaken");
    case "username_taken":
      return t(locale, "auth.usernameTaken");
    case "rate_limited":
      return t(locale, "auth.rateLimited");
    default:
      return t(locale, "common.error");
  }
}

const fieldClass = "input";

function PasswordField({
  id,
  label,
  value,
  onChange,
  locale,
  autoComplete,
  minLength,
}: {
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
  locale: Locale;
  autoComplete?: string;
  minLength?: number;
}) {
  const [visible, setVisible] = useState(false);
  return (
    <div>
      <label htmlFor={id} className="label">{label}</label>
      <div className="relative">
        <input
          id={id}
          type={visible ? "text" : "password"}
          required
          minLength={minLength}
          autoComplete={autoComplete}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className={`${fieldClass} pr-11`}
        />
        <button
          type="button"
          onClick={() => setVisible((v) => !v)}
          aria-label={t(locale, visible ? "auth.hidePassword" : "auth.showPassword")}
          className="absolute inset-y-0 right-0 px-3 text-[11px] font-semibold subtle hover:text-brand"
        >
          {visible ? t(locale, "auth.hidePassword") : t(locale, "auth.showPassword")}
        </button>
      </div>
    </div>
  );
}

export function LoginForm({ locale, next }: { locale: Locale; next?: string }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const router = useRouter();

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const data = (await res.json()) as { ok?: boolean; error?: string; redirect?: string };
      if (!res.ok) {
        setError(errorMessage(data.error ?? "", locale));
        return;
      }
      router.push(next || data.redirect || `/${locale}/account`);
      router.refresh();
    } catch {
      setError(t(locale, "common.error"));
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} className="space-y-4">
      <div>
        <label htmlFor="login-email" className="label">{t(locale, "auth.identifier")}</label>
        <input
          id="login-email"
          type="text"
          required
          autoComplete="username"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className={fieldClass}
        />
      </div>
      <PasswordField
        id="login-password"
        label={t(locale, "auth.password")}
        value={password}
        onChange={setPassword}
        locale={locale}
        autoComplete="current-password"
      />
      {error && <p role="alert" className="rounded-lg bg-brand/10 px-3 py-2 text-xs text-brand">{error}</p>}
      <button type="submit" disabled={busy} className="btn-primary w-full">{busy ? t(locale, "common.loading") : t(locale, "nav.login")}</button>
      <div className="flex items-center justify-between gap-2 text-xs subtle">
        <Link href={`/${locale}/forgot-password`} className="hover:text-brand">{t(locale, "auth.forgot")}</Link>
        <span>{t(locale, "auth.noAccount")} <Link href={`/${locale}/register`} className="font-semibold text-brand hover:underline">{t(locale, "nav.register")}</Link></span>
      </div>
      <div className="border-t pt-3" style={{ borderColor: "var(--line)" }}>
        <button type="button" disabled className="btn-ghost w-full opacity-50" title={t(locale, "auth.googleUnavailable")}>
          {t(locale, "auth.google")}
        </button>
        <p className="mt-2 text-[10px] subtle">{t(locale, "auth.googleUnavailable")}</p>
      </div>
    </form>
  );
}

export function RegisterForm({ locale }: { locale: Locale }) {
  const [form, setForm] = useState({ name: "", username: "", email: "", password: "", confirm: "" });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const router = useRouter();

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    if (!/^[a-z0-9_]{3,24}$/.test(form.username)) return setError(t(locale, "auth.usernameHint"));
    if (form.password.length < 8) return setError(t(locale, "auth.weakPassword"));
    if (form.password !== form.confirm) return setError(t(locale, "auth.mismatch"));
    setBusy(true);
    setError("");
    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          name: form.name,
          username: form.username,
          email: form.email,
          password: form.password,
          locale,
        }),
      });
      const data = (await res.json()) as { ok?: boolean; error?: string; redirect?: string };
      if (!res.ok) {
        setError(errorMessage(data.error ?? "", locale));
        return;
      }
      router.push(data.redirect || `/${locale}/account`);
      router.refresh();
    } catch {
      setError(t(locale, "common.error"));
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} className="space-y-4">
      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <label htmlFor="reg-name" className="label">{t(locale, "auth.name")}</label>
          <input id="reg-name" required minLength={2} autoComplete="name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className={fieldClass} />
        </div>
        <div>
          <label htmlFor="reg-username" className="label">{t(locale, "auth.username")}</label>
          <input
            id="reg-username"
            required
            minLength={3}
            maxLength={24}
            pattern="[a-zA-Z0-9_]+"
            autoComplete="username"
            value={form.username}
            onChange={(e) => setForm({ ...form, username: e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, "") })}
            className={fieldClass}
          />
          <p className="mt-1 text-[10px] subtle">{t(locale, "auth.usernameHint")}</p>
        </div>
      </div>
      <div>
        <label htmlFor="reg-email" className="label">{t(locale, "auth.email")}</label>
        <input id="reg-email" type="email" required autoComplete="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className={fieldClass} />
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        <PasswordField
          id="reg-password"
          label={t(locale, "auth.password")}
          value={form.password}
          onChange={(value) => setForm({ ...form, password: value })}
          locale={locale}
          autoComplete="new-password"
          minLength={8}
        />
        <PasswordField
          id="reg-confirm"
          label={t(locale, "auth.confirmPassword")}
          value={form.confirm}
          onChange={(value) => setForm({ ...form, confirm: value })}
          locale={locale}
          autoComplete="new-password"
        />
      </div>
      <p className="text-[11px] subtle">{t(locale, "auth.weakPassword")}</p>
      {error && <p role="alert" className="rounded-lg bg-brand/10 px-3 py-2 text-xs text-brand">{error}</p>}
      <button type="submit" disabled={busy} className="btn-primary w-full">{busy ? t(locale, "common.loading") : t(locale, "nav.register")}</button>
      <p className="text-center text-xs subtle">
        {t(locale, "auth.hasAccount")}{" "}
        <Link href={`/${locale}/login`} className="font-semibold text-brand hover:underline">{t(locale, "nav.login")}</Link>
      </p>
    </form>
  );
}

export function ForgotForm({ locale }: { locale: Locale }) {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    await fetch("/api/auth/forgot", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ email }),
    }).catch(() => {});
    setBusy(false);
    setSent(true);
  }

  return (
    <form onSubmit={submit} className="space-y-4">
      <div>
        <label htmlFor="forgot-email" className="label">{t(locale, "auth.email")}</label>
        <input id="forgot-email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className={fieldClass} />
      </div>
      {sent && <p className="rounded-lg border p-3 text-xs subtle" style={{ borderColor: "var(--line)" }}>{t(locale, "auth.resetSent")}</p>}
      <button type="submit" disabled={busy} className="btn-primary w-full">{busy ? t(locale, "common.loading") : t(locale, "auth.resetTitle")}</button>
      <p className="text-center text-xs subtle">
        <Link href={`/${locale}/login`} className="font-semibold text-brand hover:underline">{t(locale, "nav.login")}</Link>
      </p>
    </form>
  );
}

export function ResetForm({ locale, token }: { locale: Locale; token: string }) {
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [done, setDone] = useState(false);
  const router = useRouter();

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    if (password.length < 8) return setError(t(locale, "auth.weakPassword"));
    const res = await fetch("/api/auth/reset", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ token, password }),
    });
    if (!res.ok) {
      setError(t(locale, "common.error"));
      return;
    }
    setDone(true);
    setTimeout(() => router.push(`/${locale}/login`), 1500);
  }

  return (
    <form onSubmit={submit} className="space-y-4">
      <PasswordField
        id="reset-password"
        label={t(locale, "auth.newPassword")}
        value={password}
        onChange={setPassword}
        locale={locale}
        autoComplete="new-password"
        minLength={8}
      />
      {error && <p className="text-xs text-brand">{error}</p>}
      {done && <p className="text-xs text-emerald-400">{t(locale, "account.saved")}</p>}
      <button type="submit" className="btn-primary w-full">{t(locale, "auth.resetTitle")}</button>
    </form>
  );
}
