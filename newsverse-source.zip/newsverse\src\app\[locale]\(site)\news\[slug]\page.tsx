import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { resolveLocale, t, formatDate, formatNumber, relativeTime, localeTags, type Locale } from "@/i18n";
import { getArticleBySlug, getRelated, isBookmarked, listComments } from "@/server/repo/content";
import { getCurrentUser } from "@/server/auth";
import { getBoolSetting, getSetting } from "@/server/repo/settings";
import { paragraphs, articlePath, siteUrl } from "@/lib/ui";
import { JsonLd } from "@/components/json-ld";
import { ArticleCard } from "@/components/article-card";
import { ShareButtons } from "@/components/share-buttons";
import { BookmarkButton } from "@/components/bookmark-button";
import { ViewTracker } from "@/components/view-tracker";
import { CommentForm } from "@/components/comment-form";
import { ReportForm } from "@/components/report-form";
import { ReaderControls } from "@/components/reader-controls";
import { SectionHeader } from "@/components/layout-parts";
import { CategoryIcon, IconEye, IconClock, IconChevronRight, IconPlay, IconShield } from "@/components/icons";

type Props = { params: Promise<{ locale: string; slug: string }> };

function decodeSlug(slug: string): string {
  try {
    return decodeURIComponent(slug);
  } catch {
    return slug;
  }
}

function safeHttpUrl(url: string | null): string | null {
  if (!url) return null;
  return /^https?:\/\//i.test(url) ? url : null;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { locale: raw, slug } = await params;
  const locale = resolveLocale(raw);
  const article = getArticleBySlug(locale, decodeSlug(slug));
  if (!article) return { title: t(locale, "state.notFoundTitle"), robots: { index: false } };
  const languages: Record<string, string> = {};
  for (const tr of article.translations) languages[tr.locale] = `/${tr.locale}/news/${tr.slug}`;
  const image = safeHttpUrl(article.image_url);
  return {
    title: article.title,
    description: article.summary,
    alternates: { canonical: `/${locale}/news/${article.slug}`, languages },
    openGraph: {
      type: "article",
      title: article.title,
      description: article.summary,
      url: `/${locale}/news/${article.slug}`,
      publishedTime: article.published_at,
      modifiedTime: article.updated_at,
      locale: localeTags[locale],
      images: image ? [{ url: image }] : [{ url: "/brand/og.png", width: 1200, height: 630 }],
      siteName: "NewsVerse",
    },
    twitter: { card: "summary_large_image", title: article.title, description: article.summary },
  };
}

export default async function ArticlePage({ params }: Props) {
  const { locale: raw, slug } = await params;
  const locale = resolveLocale(raw) as Locale;
  const article = getArticleBySlug(locale, decodeSlug(slug));
  if (!article) notFound();

  const user = await getCurrentUser();
  const saved = user ? isBookmarked(user.id, article.id) : false;
  const commentsEnabled = getBoolSetting("comments_enabled", true);
  const comments = commentsEnabled ? listComments(article.id) : [];
  const related = getRelated(article.id, article.category_slug, locale, 4);
  const body = paragraphs(article.content || article.summary);
  const url = siteUrl(articlePath(locale, article.slug));
  const image = safeHttpUrl(article.image_url);
  const video = safeHttpUrl(article.video_url);
  const siteName = getSetting("site_name", "NewsVerse");
  const showSourceNotice = !!article.source_name;

  return (
    <div className="container-nv py-6">
      <ViewTracker articleId={article.id} locale={locale} />
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "NewsArticle",
          headline: article.title.slice(0, 110),
          description: article.summary,
          datePublished: article.published_at,
          dateModified: article.updated_at,
          inLanguage: article.contentLocale,
          isAccessibleForFree: true,
          image: image ? [image] : undefined,
          mainEntityOfPage: url,
          publisher: { "@type": "Organization", name: siteName, logo: { "@type": "ImageObject", url: siteUrl("/brand/icon-512.png") } },
          ...(article.source_name
            ? { isBasedOn: article.source_url, creditText: article.source_name, citation: article.source_url ?? undefined }
            : {}),
        }}
      />
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "BreadcrumbList",
          itemListElement: [
            { "@type": "ListItem", position: 1, name: t(locale, "nav.home"), item: siteUrl(`/${locale}`) },
            ...(article.category_slug
              ? [{ "@type": "ListItem", position: 2, name: article.category_name, item: siteUrl(`/${locale}/category/${article.category_slug}`) }]
              : []),
            { "@type": "ListItem", position: 3, name: article.title, item: url },
          ],
        }}
      />

      <nav aria-label="Breadcrumb" className="flex flex-wrap items-center gap-1 text-[11px] subtle">
        <Link href={`/${locale}`} className="hover:text-brand">{t(locale, "nav.home")}</Link>
        <IconChevronRight size={12} />
        {article.category_slug && (
          <>
            <Link href={`/${locale}/category/${article.category_slug}`} className="hover:text-brand">{article.category_name}</Link>
            <IconChevronRight size={12} />
          </>
        )}
        <span className="line-clamp-1 max-w-[50ch]">{article.title}</span>
      </nav>

      <article className="mt-4 grid gap-8 lg:grid-cols-[minmax(0,1fr)_300px]">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            {article.is_breaking && (
              <span className="badge-breaking">
                <span className="h-1.5 w-1.5 animate-pulseDot rounded-full bg-white" />
                {t(locale, "home.breaking")}
              </span>
            )}
            {article.is_demo && <span className="chip">{t(locale, "common.demo")}</span>}
            {article.is_opinion && <span className="chip">{t(locale, "article.opinion")}</span>}
            {article.is_sponsored && <span className="chip !text-brand">{t(locale, "article.sponsored")}</span>}
            {article.category_slug && (
              <Link href={`/${locale}/category/${article.category_slug}`} className="kicker inline-flex items-center gap-1">
                <CategoryIcon name={article.category_icon ?? "dot"} size={13} />
                {article.category_name}
              </Link>
            )}
          </div>

          <h1 className="mt-2 font-display text-[28px] font-extrabold leading-[1.15] tracking-tight sm:text-4xl">
            {article.title}
          </h1>
          {article.subtitle && <p className="mt-2 text-lg leading-relaxed subtle">{article.subtitle}</p>}

          <div className="mt-4 flex flex-wrap items-center gap-x-3 gap-y-2 border-y py-3 text-[12px] subtle" style={{ borderColor: "var(--line)" }}>
            {article.author_name && <span>{article.author_name}</span>}
            {article.source_name && (
              <span className="font-semibold text-[color:var(--text)]">{article.source_name}</span>
            )}
            <time dateTime={article.published_at}>{formatDate(article.published_at, locale)}</time>
            {new Date(article.updated_at).getTime() - new Date(article.published_at).getTime() > 60000 && (
              <span>· {t(locale, "common.updated")}: {formatDate(article.updated_at, locale)}</span>
            )}
            <span className="inline-flex items-center gap-1"><IconClock size={13} />{article.reading_minutes} {t(locale, "common.minRead")}</span>
            <span className="inline-flex items-center gap-1"><IconEye size={13} />{formatNumber(article.view_count, locale)} {t(locale, "article.views")}</span>
          </div>

          {article.isFallback && (
            <p className="mt-4 rounded-xl border border-amber-500/30 bg-amber-500/10 px-4 py-3 text-xs text-amber-300">
              {t(locale, "common.onlyOriginal")} ({article.contentLocale.toUpperCase()})
            </p>
          )}

          {image && (
            <figure className="mt-5">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={image}
                alt={article.title}
                className="w-full rounded-2xl object-cover"
                referrerPolicy="no-referrer"
                loading="eager"
              />
              <figcaption className="mt-2 text-[11px] subtle">
                {article.source_name ? `${t(locale, "common.source")}: ${article.source_name}` : ""}
                {article.image_credit ? ` · ${article.image_credit}` : ""}
              </figcaption>
            </figure>
          )}

          {video && (
            <div className="mt-5 overflow-hidden rounded-2xl border" style={{ borderColor: "var(--line)" }}>
              {/* eslint-disable-next-line jsx-a11y/media-has-caption */}
              <video src={video} controls preload="none" poster={image ?? undefined} className="w-full" />
            </div>
          )}

          <div className="mt-6 flex flex-wrap items-center justify-between gap-3">
            <ShareButtons url={url} title={article.title} locale={locale} />
            <div className="flex items-center gap-2">
              <ReaderControls locale={locale} />
              <BookmarkButton articleId={article.id} initialSaved={saved} locale={locale} signedIn={!!user} />
            </div>
          </div>

          <div className="prose-nv reader mt-6">
            {body.map((paragraph, index) => (
              <p key={index}>{paragraph}</p>
            ))}
          </div>

          {article.is_ai_assisted && (
            <p className="mt-5 flex items-start gap-2 rounded-xl border px-4 py-3 text-xs subtle" style={{ borderColor: "var(--line)" }}>
              <span className="badge-ai shrink-0">{t(locale, "common.aiSummary")}</span>
              <span>{t(locale, "article.aiNotice")}</span>
            </p>
          )}

          {showSourceNotice && (
            <div className="mt-4 rounded-xl border p-4" style={{ borderColor: "var(--line)" }}>
              <p className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider subtle">
                <IconShield size={15} className="text-brand" /> {t(locale, "common.source")}
              </p>
              <p className="mt-1.5 text-sm leading-relaxed subtle">{t(locale, "article.sourceNotice")}</p>
              {article.source_url && (
                <a href={article.source_url} target="_blank" rel="noopener noreferrer nofollow" className="mt-2 inline-block text-sm font-semibold text-brand hover:underline">
                  {article.source_name} — {t(locale, "common.original")} →
                </a>
              )}
            </div>
          )}

          <div className="mt-5 flex flex-wrap gap-1.5">
            {article.tags.map((tag) => (
              <Link key={tag.slug} href={`/${locale}/search?tag=${tag.slug}`} className="chip hover:border-brand hover:text-brand">
                #{tag.name}
              </Link>
            ))}
          </div>

          <div className="mt-4 flex flex-wrap items-center gap-2 text-[11px] subtle">
            <span className="uppercase tracking-wider">{t(locale, "common.language")}:</span>
            {article.translations.map((tr) => (
              <Link
                key={tr.locale}
                href={`/${tr.locale}/news/${tr.slug}`}
                className={`chip hover:border-brand hover:text-brand ${tr.locale === locale ? "!border-brand !text-brand" : ""}`}
              >
                {tr.locale.toUpperCase()}
                {tr.isMachine && <span className="ml-1 opacity-70">AI</span>}
              </Link>
            ))}
            {article.translations.some((tr) => tr.isMachine) && (
              <span className="text-[10px] subtle">· {t(locale, "common.unverifiedTranslation")}</span>
            )}
          </div>

          <ReportForm articleId={article.id} locale={locale} />

          {article.corrections.length > 0 && (
            <details className="mt-5 rounded-xl border p-4 text-xs" style={{ borderColor: "var(--line)" }}>
              <summary className="cursor-pointer font-semibold uppercase tracking-wider subtle">{t(locale, "article.corrections")}</summary>
              <ul className="mt-2 space-y-1 subtle">
                {article.corrections.map((c, i) => (
                  <li key={i}>{formatDate(c.created_at, locale)} — {c.action}</li>
                ))}
              </ul>
            </details>
          )}

          {commentsEnabled && (
            <section id="comments" className="mt-10 border-t pt-6" style={{ borderColor: "var(--line)" }}>
              <SectionHeader title={`${t(locale, "article.comments")} (${comments.length})`} />
              {user ? (
                <CommentForm articleId={article.id} locale={locale} />
              ) : (
                <p className="rounded-xl border px-4 py-3 text-sm subtle" style={{ borderColor: "var(--line)" }}>
                  <Link href={`/${locale}/login?next=${encodeURIComponent(articlePath(locale, article.slug))}`} className="font-semibold text-brand hover:underline">
                    {t(locale, "nav.login")}
                  </Link>{" "}
                  — {t(locale, "article.loginToComment")}
                </p>
              )}
              <ul className="mt-5 space-y-4">
                {comments.length === 0 && <li className="text-sm subtle">{t(locale, "article.noComments")}</li>}
                {comments.map((comment) => (
                  <li key={comment.id} className="rounded-xl border p-4" style={{ borderColor: "var(--line)" }}>
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold">{comment.author}</span>
                      <time dateTime={comment.created_at} className="subtle">{relativeTime(comment.created_at, locale)}</time>
                    </div>
                    <p className="mt-1.5 text-sm leading-relaxed">{comment.body}</p>
                  </li>
                ))}
              </ul>
            </section>
          )}
        </div>

        <aside className="space-y-4">
          <div className="card p-4">
            <p className="label">{t(locale, "article.related")}</p>
            <div className="space-y-3">
              {related.map((item) => (
                <ArticleCard key={item.id} article={item} locale={locale} variant="compact" />
              ))}
              {related.length === 0 && <p className="text-xs subtle">{t(locale, "state.emptyBody")}</p>}
            </div>
          </div>
          <div className="card bg-brand/[0.06] p-4">
            <p className="text-sm font-bold">{t(locale, "newsletter.title")}</p>
            <p className="mt-1 text-xs subtle">{t(locale, "newsletter.desc")}</p>
            <Link href={`/${locale}/saved`} className="btn-primary mt-3 w-full !text-xs">{t(locale, "nav.bookmarks")}</Link>
          </div>
        </aside>
      </article>

      {related.length > 0 && (
        <section className="mt-12">
          <SectionHeader title={t(locale, "article.related")} />
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {related.map((item) => <ArticleCard key={item.id} article={item} locale={locale} />)}
          </div>
        </section>
      )}
      <div className="mt-10 flex items-center gap-2 text-xs subtle">
        <IconPlay size={14} /> {siteName} · {t(locale, "footer.editorial")}
      </div>
    </div>
  );
}
