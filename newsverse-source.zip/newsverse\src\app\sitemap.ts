import type { MetadataRoute } from "next";
import { all } from "@/server/db";
import { listCategories } from "@/server/repo/content";
import { locales } from "@/i18n";
import { siteUrl } from "@/lib/ui";

type Row = { id: string; updated_at: string; locale: string; slug: string };

export default function sitemap(): MetadataRoute.Sitemap {
  const base = siteUrl();
  const entries: MetadataRoute.Sitemap = [];

  const staticPaths = ["", "/latest", "/trending", "/search", "/about", "/privacy", "/terms", "/sources"];
  for (const locale of locales) {
    for (const path of staticPaths) {
      entries.push({
        url: `${base}/${locale}${path}`,
        lastModified: new Date(),
        changeFrequency: path === "" || path === "/latest" ? "hourly" : "monthly",
        priority: path === "" ? 1 : 0.6,
        alternates: { languages: Object.fromEntries(locales.map((l) => [l, `${base}/${l}${path}`])) },
      });
    }
  }

  for (const category of listCategories("en")) {
    entries.push({
      url: `${base}/en/category/${category.slug}`,
      lastModified: new Date(),
      changeFrequency: "hourly",
      priority: 0.7,
      alternates: { languages: Object.fromEntries(locales.map((l) => [l, `${base}/${l}/category/${category.slug}`])) },
    });
  }

  let rows: Row[] = [];
  try {
    rows = all<Row>(
      `SELECT a.id, a.updated_at, t.locale, t.slug FROM articles a
       JOIN article_translations t ON t.article_id = a.id
       WHERE a.status = 'published' AND a.deleted_at IS NULL AND a.published_at IS NOT NULL
       ORDER BY a.published_at DESC LIMIT 4000`,
    );
  } catch {
    rows = [];
  }

  const grouped = new Map<string, { updated: string; translations: Record<string, string> }>();
  for (const row of rows) {
    const current = grouped.get(row.id) ?? { updated: row.updated_at, translations: {} };
    current.translations[row.locale] = `${base}/${row.locale}/news/${row.slug}`;
    grouped.set(row.id, current);
  }
  for (const item of grouped.values()) {
    const languages = item.translations;
    for (const url of Object.values(languages)) {
      entries.push({
        url,
        lastModified: new Date(item.updated),
        changeFrequency: "daily",
        priority: 0.8,
        alternates: { languages },
      });
    }
  }

  return entries;
}
