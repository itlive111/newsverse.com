import { guardAdmin } from "@/server/adminGuard";
import { json, parseBody, handleError } from "@/server/http";
import { sourcePatchSchema } from "@/lib/validation";
import { updateSource } from "@/server/repo/admin";
import { audit } from "@/server/auth";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(request: Request, ctx: Ctx) {
  try {
    const user = await guardAdmin(request);
    const { id } = await ctx.params;
    const input = await parseBody(request, sourcePatchSchema);
    updateSource(id, input);
    audit({ actor: user, action: "source.update", entity: "source", entityId: id, meta: input as Record<string, unknown> });
    return json({ ok: true });
  } catch (err) {
    return handleError(err);
  }
}
