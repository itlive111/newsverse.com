# Troubleshooting

## `TypeError: Cannot read properties of undefined (reading 'fileExists')` on startup

Next.js 15 cannot transpile `next.config.ts` with TypeScript 7 (the native compiler package), whose
JavaScript API no longer exposes `ts.sys`. This project pins TypeScript 5.x. Check:

```bash
npx tsc -v           # expect 5.9.x
npm ls typescript
```

If TypeScript 7 was installed by a tool, run `npm install -D typescript@^5.9.3`.

## `Reading from "node:crypto" is not handled by plugins`

A client component imported server-only code. Client modules must not import `@/server/*`.
Shared helpers live in `src/lib/` (`html.ts`, `ui.ts`). If you see this, follow the import trace in
the error and move the pure helper out of the server module.

## App starts but every page returns 500 and `.next` errors appear

Usually the development server was running while `.next` was deleted or a build was run. Stop all
Next processes for the project, delete `.next`, and start again:

```bash
rm -rf .next
npm run dev
```

Never run `npm run build` against the same `.next` a dev server is using.

## Port 3000 is already in use

Next prints the port it chose. To force one: `npm run dev -- -p 3001`. To find the old process:

```bash
netstat -ano | grep LISTENING | grep :3000
# Windows: taskkill /PID <pid> /T /F
```

## `Cannot find module 'node:sqlite'`

Node is too old. Use Node 24 (or 22.5+ with `--experimental-sqlite`). The Docker image already uses
Node 24.

## Admin pages show 403 after signing in

The account is not `admin` or `editor`. Promote it:

```bash
ADMIN_EMAIL=you@example.com ADMIN_PASSWORD='new-long-password' npm run admin:create
```

Existing sessions are not upgraded automatically — sign out and back in.

## Login says "invalid credentials" but the password is right

Check the account status in Admin → Users. Suspended accounts are rejected, and suspension deletes
their sessions. If the database was restored from an older backup, the password is the old one.

## All feed collections fail with HTTP 403/404

Publishers block unknown user agents, or the feed moved. Test in **Admin → Sources** (Test feed).
The collector sends `NewsVerseBot/1.0`. Some publishers require an API key instead of RSS; add the
official API feed only if their terms allow it. Feeds that keep failing are disabled by the
administrator and an alert appears in Automation.

## Collections succeed but nothing appears on the site

Check the source's moderation mode: `review` sends items to `pending`, which do not appear publicly.
Open **Admin → Articles → status: pending** and publish or approve. Also confirm the article is not
scheduled in the future.

## Scheduler is not running

`/api/health` shows `scheduler.running`. If false:

- `INGEST_AUTO_START` must not be `0`.
- The app must run as a Node server (`npm start`), not a static export or edge runtime.
- If the process is serverless, use the external cron mode instead (`/api/cron/tick`).

## Reset password link never arrives

No mail provider is configured by design; the link is printed in the server log:

```bash
docker compose logs web | grep "password reset link"
```

## "Cross-origin request rejected"

A state-changing request arrived with a mismatched `Origin`. Set `NEXT_PUBLIC_SITE_URL` to the real
public origin, and add any additional hostnames (with scheme) to `ALLOWED_ORIGINS`. Behind a proxy,
forward the original `Host` header.

## Uploaded/imported image is not shown

Only `http(s)` image URLs are stored; anything else is rejected by validation. Some feeds omit
images — cards fall back to a branded placeholder rather than a misleading stock photo.

## Database is locked

Only one process should write. Running dev and production at the same time against the same file,
or two containers sharing a volume, causes `SQLITE_BUSY`. Keep one instance; backups use
`VACUUM INTO`, which is safe while running.
