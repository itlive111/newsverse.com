import crypto from "node:crypto";
import { all, get, run, tx, nowIso } from "@/server/db";
import { ensureBootstrapped } from "@/server/db/bootstrap";
import type { Locale } from "@/i18n";

export type Tri = { uz: string; en: string; ru: string };

export type CategoryRow = {
  id: string;
  slug: string;
  name_i18n: string;
  description_i18n: string;
  icon: string;
  color: string | null;
  image_url: string | null;
  order_index: number;
  is_active: number;
};

export type Category = {
  id: string;
  slug: string;
  name: string;
  description: string;
  icon: string;
  color: string | null;
  image_url: string | null;
  orderIndex: number;
  isActive: boolean;
};

export type ArticleCard = {
  id: string;
  slug: string;
  title: string;
  summary: string;
  contentLocale: Locale;
  isFallback: boolean;
  image_url: string | null;
  image_credit: string | null;
  video_url: string | null;
  source_name: string | null;
  source_url: string | null;
  published_at: string;
  updated_at: string;
  reading_minutes: number;
  view_count: number;
  recent_views: number;
  is_breaking: boolean;
  is_demo: boolean;
  is_ai_assisted: boolean;
  is_opinion: boolean;
  is_sponsored: boolean;
  original_locale: Locale;
  category_slug: string | null;
  category_name: string | null;
  category_icon: string | null;
  category_color: string | null;
};

export type ArticleDetail = ArticleCard & {
  content: string;
  subtitle: string | null;
  canonical_url: string | null;
  author_name: string | null;
  tags: { slug: string; name: string }[];
  translations: { locale: Locale; slug: string; isMachine: boolean }[];
  corrections: { action: string; created_at: string }[];
};

function parseTri(json: string | null, fallback = ""): Tri {
  if (!json) return { uz: fallback, en: fallback, ru: fallback };
  try {
    const parsed = JSON.parse(json) as Partial<Tri>;
    return { uz: parsed.uz ?? fallback, en: parsed.en ?? fallback, ru: parsed.ru ?? fallback };
  } catch {
    return { uz: fallback, en: fallback, ru: fallback };
  }
}

export function mapCategory(row: CategoryRow, locale: Locale): Category {
  return {
    id: row.id,
    slug: row.slug,
    name: parseTri(row.name_i18n, row.slug)[locale],
    description: parseTri(row.description_i18n)[locale],
    icon: row.icon,
    color: row.color,
    image_url: row.image_url,
    orderIndex: row.order_index,
    isActive: !!row.is_active,
  };
}

export function listCategories(locale: Locale, includeInactive = false): Category[] {
  ensureBootstrapped();
  const rows = all<CategoryRow>(
    `SELECT * FROM categories ${includeInactive ? "" : "WHERE is_active = 1"} ORDER BY order_index ASC, slug ASC`,
  );
  return rows.map((r) => mapCategory(r, locale));
}

export function getCategoryBySlug(slug: string, locale: Locale): Category | null {
  ensureBootstrapped();
  const row = get<CategoryRow>("SELECT * FROM categories WHERE slug = ?", slug);
  return row ? mapCategory(row, locale) : null;
}

/* -------------------------------------------------------------------------- */
/* Shared article projection with per-locale fallback                          */
/* -------------------------------------------------------------------------- */

const BASE_SELECT = `
  SELECT a.id, a.published_at, a.updated_at, a.image_url, a.image_credit, a.video_url, a.source_name, a.source_url,
         a.reading_minutes, a.view_count, a.is_breaking, a.is_demo, a.is_ai_assisted, a.is_opinion,
         a.is_sponsored, a.original_locale, a.canonical_url,
         t.slug AS t_slug, t.title AS t_title, t.summary AS t_summary, t.locale AS t_locale,
         o.slug AS o_slug, o.title AS o_title, o.summary AS o_summary, o.locale AS o_locale,
         c.slug AS category_slug, c.name_i18n AS category_name_i18n, c.icon AS category_icon, c.color AS category_color
  FROM articles a
  LEFT JOIN article_translations t ON t.article_id = a.id AND t.locale = ?
  LEFT JOIN article_translations o ON o.article_id = a.id AND o.locale = a.original_locale
  LEFT JOIN categories c ON c.id = a.category_id
`;

type RawRow = {
  id: string; published_at: string; updated_at: string; image_url: string | null; image_credit: string | null;
  video_url: string | null;
  source_name: string | null; source_url: string | null; reading_minutes: number; view_count: number;
  is_breaking: number; is_demo: number; is_ai_assisted: number; is_opinion: number; is_sponsored: number;
  original_locale: string; canonical_url: string | null;
  t_slug: string | null; t_title: string | null; t_summary: string | null; t_locale: string | null;
  o_slug: string | null; o_title: string | null; o_summary: string | null; o_locale: string | null;
  category_slug: string | null; category_name_i18n: string | null; category_icon: string | null; category_color: string | null;
  recent_views?: number;
};

function mapCard(row: RawRow, locale: Locale): ArticleCard {
  const useTranslation = !!row.t_slug;
  return {
    id: row.id,
    slug: (useTranslation ? row.t_slug : row.o_slug) ?? "",
    title: (useTranslation ? row.t_title : row.o_title) ?? "—",
    summary: (useTranslation ? row.t_summary : row.o_summary) ?? "",
    contentLocale: ((useTranslation ? row.t_locale : row.o_locale) ?? row.original_locale) as Locale,
    isFallback: !useTranslation,
    image_url: row.image_url,
    image_credit: row.image_credit,
    video_url: row.video_url,
    source_name: row.source_name,
    source_url: row.source_url,
    published_at: row.published_at,
    updated_at: row.updated_at,
    reading_minutes: row.reading_minutes,
    view_count: row.view_count,
    recent_views: row.recent_views ?? 0,
    is_breaking: !!row.is_breaking,
    is_demo: !!row.is_demo,
    is_ai_assisted: !!row.is_ai_assisted,
    is_opinion: !!row.is_opinion,
    is_sponsored: !!row.is_sponsored,
    original_locale: row.original_locale as Locale,
    category_slug: row.category_slug,
    category_name: row.category_slug ? parseTri(row.category_name_i18n)[locale] : null,
    category_icon: row.category_icon,
    category_color: row.category_color,
  };
}

const PUBLISHED_WHERE = `a.status = 'published' AND a.deleted_at IS NULL AND a.published_at IS NOT NULL AND a.published_at <= ? AND (t.id IS NOT NULL OR o.id IS NOT NULL)`;

export type ListOptions = {
  locale: Locale;
  limit?: number;
  offset?: number;
  categorySlug?: string;
  tagSlug?: string;
  sourceName?: string;
  query?: string;
  from?: string;
  to?: string;
  contentLocale?: string;
  excludeId?: string;
  breakingOnly?: boolean;
};

function buildFilters(opts: ListOptions, now: string): { where: string; params: unknown[] } {
  let where = PUBLISHED_WHERE;
  const params: unknown[] = [opts.locale, now];
  if (opts.categorySlug) {
    where += " AND c.slug = ?";
    params.push(opts.categorySlug);
  }
  if (opts.breakingOnly) where += " AND a.is_breaking = 1";
  if (opts.excludeId) {
    where += " AND a.id <> ?";
    params.push(opts.excludeId);
  }
  if (opts.sourceName) {
    where += " AND a.source_name = ?";
    params.push(opts.sourceName);
  }
  if (opts.contentLocale) {
    where += " AND COALESCE(t.locale, o.locale) = ?";
    params.push(opts.contentLocale);
  }
  if (opts.from) {
    where += " AND a.published_at >= ?";
    params.push(opts.from);
  }
  if (opts.to) {
    where += " AND a.published_at <= ?";
    params.push(opts.to);
  }
  if (opts.tagSlug) {
    where += " AND a.id IN (SELECT at.article_id FROM article_tags at JOIN tags tg ON tg.id = at.tag_id WHERE tg.slug = ?)";
    params.push(opts.tagSlug);
  }
  if (opts.query) {
    const like = `%${opts.query.toLowerCase()}%`;
    where += ` AND (LOWER(COALESCE(t.title,o.title)) LIKE ? OR LOWER(COALESCE(t.summary,o.summary)) LIKE ?)`;
    params.push(like, like);
  }
  return { where, params };
}

export function listArticles(opts: ListOptions): ArticleCard[] {
  ensureBootstrapped();
  const now = nowIso();
  const { where, params } = buildFilters(opts, now);
  const limit = Math.min(Math.max(opts.limit ?? 12, 1), 60);
  const offset = Math.max(opts.offset ?? 0, 0);
  const rows = all<RawRow>(
    `${BASE_SELECT} WHERE ${where} ORDER BY (a.is_breaking AND a.published_at > ?) DESC, a.published_at DESC LIMIT ? OFFSET ?`,
    ...params, new Date(Date.now() - 6 * 3600000).toISOString(), limit, offset,
  );
  return rows.map((r) => mapCard(r, opts.locale));
}

export function countArticles(opts: ListOptions): number {
  ensureBootstrapped();
  const now = nowIso();
  const { where, params } = buildFilters(opts, now);
  const row = get<{ c: number }>(
    `SELECT COUNT(*) AS c FROM articles a
     LEFT JOIN article_translations t ON t.article_id = a.id AND t.locale = ?
     LEFT JOIN article_translations o ON o.article_id = a.id AND o.locale = a.original_locale
     LEFT JOIN categories c ON c.id = a.category_id
     WHERE ${where}`,
    ...params,
  );
  return row?.c ?? 0;
}

export function getArticleBySlug(locale: Locale, slug: string): ArticleDetail | null {
  ensureBootstrapped();
  const row = get<RawRow & { content: string | null; subtitle: string | null; author_name: string | null }>(
    `SELECT a.id, a.published_at, a.updated_at, a.image_url, a.image_credit, a.video_url, a.source_name, a.source_url,
            a.reading_minutes, a.view_count, a.is_breaking, a.is_demo, a.is_ai_assisted, a.is_opinion,
            a.is_sponsored, a.original_locale, a.canonical_url,
            t.slug AS t_slug, t.title AS t_title, t.summary AS t_summary, t.locale AS t_locale,
            o.slug AS o_slug, o.title AS o_title, o.summary AS o_summary, o.locale AS o_locale,
            c.slug AS category_slug, c.name_i18n AS category_name_i18n, c.icon AS category_icon, c.color AS category_color,
            COALESCE(t.content, o.content) AS content, COALESCE(t.subtitle, o.subtitle) AS subtitle,
            (SELECT name FROM users u WHERE u.id = a.author_user_id) AS author_name,
            (SELECT COUNT(*) FROM article_views av WHERE av.article_id = a.id AND av.viewed_at >= ?) AS recent_views
     FROM articles a
     LEFT JOIN article_translations t ON t.article_id = a.id AND t.locale = ?
     LEFT JOIN article_translations o ON o.article_id = a.id AND o.locale = a.original_locale
     LEFT JOIN categories c ON c.id = a.category_id
     WHERE a.deleted_at IS NULL AND a.status = 'published' AND (t.slug = ? OR o.slug = ?)
     LIMIT 1`,
    new Date(Date.now() - 72 * 3600000).toISOString(), locale, slug, slug,
  );
  if (!row) return null;
  const card = mapCard(row, locale);
  const tags = all<{ slug: string; name: string }>(
    `SELECT tg.slug, tg.name FROM article_tags at JOIN tags tg ON tg.id = at.tag_id WHERE at.article_id = ? ORDER BY tg.name`,
    row.id,
  );
  const translations = all<{ locale: string; slug: string; is_machine: number }>(
    "SELECT locale, slug, is_machine FROM article_translations WHERE article_id = ? ORDER BY locale",
    row.id,
  );
  const corrections = all<{ action: string; created_at: string }>(
    "SELECT action, created_at FROM audit_logs WHERE entity = 'article' AND entity_id = ? AND action IN ('article.update','article.publish','correction') ORDER BY created_at DESC LIMIT 5",
    row.id,
  );
  return {
    ...card,
    content: row.content ?? "",
    subtitle: row.subtitle,
    canonical_url: row.canonical_url,
    author_name: row.author_name,
    tags,
    translations: translations.map((tr) => ({
      locale: tr.locale as Locale, slug: tr.slug, isMachine: !!tr.is_machine,
    })),
    corrections,
  };
}

export function getArticleById(id: string): RawRow | undefined {
  return get<RawRow>(
    `${BASE_SELECT} WHERE a.id = ?`,
    "en", id,
  );
}

export function getRelated(articleId: string, categorySlug: string | null, locale: Locale, limit = 4): ArticleCard[] {
  ensureBootstrapped();
  const now = nowIso();
  const rows = all<RawRow>(
    `${BASE_SELECT} WHERE ${PUBLISHED_WHERE} AND a.id <> ? ${categorySlug ? "AND c.slug = ?" : ""}
     ORDER BY a.published_at DESC LIMIT ?`,
    locale, now, articleId, ...(categorySlug ? [categorySlug] : []), limit,
  );
  return rows.map((r) => mapCard(r, locale));
}

export function getBreaking(locale: Locale, limit = 6): ArticleCard[] {
  return listArticles({ locale, breakingOnly: true, limit });
}

export type Range = "day" | "week" | "month";

export function getMostRead(locale: Locale, range: Range, limit = 5): ArticleCard[] {
  ensureBootstrapped();
  const since = new Date(Date.now() - (range === "day" ? 1 : range === "week" ? 7 : 30) * 86400000).toISOString();
  const rows = all<RawRow>(
    `${BASE_SELECT}
     LEFT JOIN (SELECT article_id, COUNT(*) AS recent_views FROM article_views WHERE viewed_at >= ? GROUP BY article_id) v
       ON v.article_id = a.id
     WHERE ${PUBLISHED_WHERE}
     ORDER BY COALESCE(v.recent_views, 0) DESC, a.view_count DESC, a.published_at DESC LIMIT ?`,
    locale, since, nowIso(), limit,
  );
  return rows.map((r) => mapCard(r, locale));
}

export function getTrending(locale: Locale, limit = 5): ArticleCard[] {
  ensureBootstrapped();
  const since = new Date(Date.now() - 72 * 3600000).toISOString();
  const rows = all<RawRow>(
    `${BASE_SELECT}
     LEFT JOIN (SELECT article_id, COUNT(*) AS recent_views FROM article_views WHERE viewed_at >= ? GROUP BY article_id) v
       ON v.article_id = a.id
     LEFT JOIN (SELECT article_id, COUNT(*) AS recent_comments FROM comments WHERE status = 'approved' AND created_at >= ? GROUP BY article_id) cm
       ON cm.article_id = a.id
     WHERE ${PUBLISHED_WHERE}
     ORDER BY (COALESCE(v.recent_views,0) * 3 + COALESCE(cm.recent_comments,0) * 8) DESC, a.published_at DESC LIMIT ?`,
    locale, since, since, nowIso(), limit,
  );
  return rows.map((r) => mapCard(r, locale));
}

export function listVideos(locale: Locale, limit = 4): ArticleCard[] {
  ensureBootstrapped();
  const rows = all<RawRow>(
    `${BASE_SELECT} WHERE ${PUBLISHED_WHERE} AND a.video_url IS NOT NULL ORDER BY a.published_at DESC LIMIT ?`,
    locale, nowIso(), limit,
  );
  return rows.map((r) => mapCard(r, locale));
}

export function getRecentlyUpdated(locale: Locale, limit = 4): ArticleCard[] {
  ensureBootstrapped();
  const rows = all<RawRow>(
    `${BASE_SELECT} WHERE ${PUBLISHED_WHERE} AND a.updated_at > a.published_at
     ORDER BY a.updated_at DESC LIMIT ?`,
    locale, nowIso(), limit,
  );
  return rows.map((r) => mapCard(r, locale));
}

export function getPersonalized(locale: Locale, interestSlugs: string[], limit = 6): ArticleCard[] {
  if (!interestSlugs.length) return [];
  const now = nowIso();
  const placeholders = interestSlugs.map(() => "?").join(",");
  const rows = all<RawRow>(
    `${BASE_SELECT} WHERE ${PUBLISHED_WHERE} AND c.slug IN (${placeholders}) ORDER BY a.published_at DESC LIMIT ?`,
    locale, now, ...interestSlugs, limit,
  );
  return rows.map((r) => mapCard(r, locale));
}

export function getEditorsPicks(locale: Locale, limit = 3): ArticleCard[] {
  ensureBootstrapped();
  const rows = all<RawRow>(
    `${BASE_SELECT} WHERE ${PUBLISHED_WHERE} AND a.is_ai_assisted = 0 AND a.is_demo = 0
     ORDER BY a.quality_score DESC, a.published_at DESC LIMIT ?`,
    locale, nowIso(), limit,
  );
  return rows.map((r) => mapCard(r, locale));
}

export function listTagsWithCounts(limit = 14): { slug: string; name: string; count: number }[] {
  ensureBootstrapped();
  return all<{ slug: string; name: string; count: number }>(
    `SELECT tg.slug, tg.name, COUNT(at.article_id) AS count
     FROM tags tg JOIN article_tags at ON at.tag_id = tg.id
     JOIN articles a ON a.id = at.article_id AND a.status = 'published'
     GROUP BY tg.id ORDER BY count DESC, tg.name ASC LIMIT ?`,
    limit,
  );
}

export function suggestArticles(locale: Locale, query: string, limit = 6) {
  const trimmed = query.trim();
  if (trimmed.length < 2) return [];
  ensureBootstrapped();
  const like = `%${trimmed.toLowerCase()}%`;
  return all<{ title: string; slug: string; category_slug: string | null }>(
    `SELECT COALESCE(t.title,o.title) AS title, COALESCE(t.slug,o.slug) AS slug, c.slug AS category_slug
     FROM articles a
     LEFT JOIN article_translations t ON t.article_id = a.id AND t.locale = ?
     LEFT JOIN article_translations o ON o.article_id = a.id AND o.locale = a.original_locale
     LEFT JOIN categories c ON c.id = a.category_id
     WHERE ${PUBLISHED_WHERE} AND LOWER(COALESCE(t.title,o.title)) LIKE ?
     ORDER BY a.published_at DESC LIMIT ?`,
    locale, nowIso(), like, limit,
  );
}

/** Records a genuine view; one per visitor per article per day. */
export function recordView(articleId: string, visitorHash: string, locale: Locale): boolean {
  ensureBootstrapped();
  const day = new Date().toISOString().slice(0, 10);
  const id = crypto.randomUUID();
  return tx(() => {
    const inserted = run(
      "INSERT OR IGNORE INTO article_views (id, article_id, visitor_hash, day_key, locale, viewed_at) VALUES (?,?,?,?,?,?)",
      id, articleId, visitorHash, day, locale, nowIso(),
    );
    if (inserted.changes > 0) {
      run("UPDATE articles SET view_count = view_count + 1 WHERE id = ?", articleId);
      return true;
    }
    return false;
  });
}

export function incrementShare(articleId: string): void {
  run("UPDATE articles SET share_count = share_count + 1 WHERE id = ?", articleId);
}

/* -------------------------------------------------------------------------- */
/* Bookmarks, comments, newsletter, reports                                   */
/* -------------------------------------------------------------------------- */

export function isBookmarked(userId: string, articleId: string): boolean {
  return !!get("SELECT 1 AS x FROM bookmarks WHERE user_id = ? AND article_id = ?", userId, articleId);
}

export function toggleBookmark(userId: string, articleId: string, folder = "default"): boolean {
  const existing = isBookmarked(userId, articleId);
  if (existing) {
    run("DELETE FROM bookmarks WHERE user_id = ? AND article_id = ?", userId, articleId);
    return false;
  }
  run("INSERT INTO bookmarks (user_id, article_id, folder, created_at) VALUES (?,?,?,?)", userId, articleId, folder, nowIso());
  return true;
}

export function listBookmarks(userId: string, locale: Locale): (ArticleCard & { folder: string })[] {
  ensureBootstrapped();
  const rows = all<RawRow & { folder: string }>(
    `${BASE_SELECT}
     JOIN bookmarks b ON b.article_id = a.id AND b.user_id = ?
     WHERE a.status = 'published' AND a.deleted_at IS NULL
     ORDER BY b.created_at DESC`,
    locale, userId,
  );
  return rows.map((r) => ({ ...mapCard(r, locale), folder: r.folder }));
}

export function listComments(articleId: string) {
  return all<{ id: string; body: string; created_at: string; author: string }>(
    `SELECT cm.id, cm.body, cm.created_at, u.name AS author
     FROM comments cm JOIN users u ON u.id = cm.user_id
     WHERE cm.article_id = ? AND cm.status = 'approved'
     ORDER BY cm.created_at DESC LIMIT 100`,
    articleId,
  );
}

export function addComment(articleId: string, userId: string, body: string, autoApprove = false): string {
  const id = crypto.randomUUID();
  run(
    "INSERT INTO comments (id, article_id, user_id, body, status, created_at) VALUES (?,?,?,?,?,?)",
    id, articleId, userId, body.trim().slice(0, 2000), autoApprove ? "approved" : "pending", nowIso(),
  );
  return id;
}

export function subscribeNewsletter(email: string, locale: Locale, userId?: string | null): boolean {
  ensureBootstrapped();
  const existing = get<{ id: string; unsubscribed_at: string | null }>(
    "SELECT id, unsubscribed_at FROM newsletter_subscribers WHERE email = ?",
    email,
  );
  if (existing) {
    if (existing.unsubscribed_at) {
      run("UPDATE newsletter_subscribers SET unsubscribed_at = NULL, locale = ? WHERE id = ?", locale, existing.id);
      return true;
    }
    return false;
  }
  run(
    "INSERT INTO newsletter_subscribers (id, email, locale, user_id, confirmed, created_at) VALUES (?,?,?,?,0,?)",
    crypto.randomUUID(), email, locale, userId ?? null, nowIso(),
  );
  return true;
}

export function addReport(articleId: string, reason: string, details: string, userId?: string | null): void {
  run(
    "INSERT INTO reports (id, article_id, user_id, reason, details, status, created_at) VALUES (?,?,?,?,?, 'open', ?)",
    crypto.randomUUID(), articleId, userId ?? null, reason.slice(0, 80), details.slice(0, 2000), nowIso(),
  );
}

export function recordHistory(userId: string, articleId: string): void {
  run(
    `INSERT INTO reading_history (user_id, article_id, read_at) VALUES (?,?,?)
     ON CONFLICT(user_id, article_id) DO UPDATE SET read_at = excluded.read_at`,
    userId, articleId, nowIso(),
  );
}

export function listHistory(userId: string, locale: Locale, limit = 20) {
  ensureBootstrapped();
  const rows = all<RawRow>(
    `${BASE_SELECT} JOIN reading_history h ON h.article_id = a.id AND h.user_id = ?
     WHERE ${PUBLISHED_WHERE} ORDER BY h.read_at DESC LIMIT ?`,
    locale, userId, nowIso(), limit,
  );
  return rows.map((r) => mapCard(r, locale));
}

export function listSources(): { id: string; name: string }[] {
  return all<{ id: string; name: string }>("SELECT id, name FROM sources WHERE enabled = 1 ORDER BY name");
}
