import Link from "next/link";

type Size = "sm" | "md" | "lg";

const IMAGE_HEIGHT: Record<Size, string> = {
  sm: "h-7 sm:h-8",
  md: "h-9 sm:h-11",
  lg: "h-14 sm:h-16",
};

const WORD_SIZE: Record<Size, string> = {
  sm: "text-lg sm:text-xl",
  md: "text-2xl sm:text-3xl",
  lg: "text-4xl",
};

/**
 * The supplied logo mark plus the NewsVerse wordmark.
 * "News" is always brand red; "Verse" uses the theme text colour, so it stays
 * black on the light theme and white on the dark theme (never invisible).
 */
export function BrandLogo({
  href,
  size = "md",
  className = "",
  compactWordmark = false,
}: {
  href?: string;
  size?: Size;
  className?: string;
  /** Hides the wordmark on very small screens so the header never overflows. */
  compactWordmark?: boolean;
}) {
  const wordClasses = compactWordmark ? "hidden sm:inline text-xl sm:text-2xl" : WORD_SIZE[size];
  const content = (
    <span className={`inline-flex items-center gap-2.5 ${className}`}>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src="/brand/newsverse-logo-sm.png"
        alt=""
        aria-hidden="true"
        className={`${IMAGE_HEIGHT[size]} w-auto shrink-0`}
        width={360}
        height={240}
      />
      <span
        className={`font-display ${wordClasses} font-black leading-none tracking-tight`}
        aria-hidden="true"
      >
        <span className="text-brand">News</span>
        <span className="text-[color:var(--text)]">Verse</span>
      </span>
    </span>
  );

  if (!href) return content;
  return (
    <Link href={href} aria-label="NewsVerse" className="inline-flex items-center">
      {content}
    </Link>
  );
}
