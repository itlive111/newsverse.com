import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { resolveLocale, t, formatNumber, type Locale } from "@/i18n";
import { countArticles, getCategoryBySlug, listArticles } from "@/server/repo/content";
import { ArticleCard } from "@/components/article-card";
import { EmptyState, Pagination } from "@/components/layout-parts";
import { CategoryIcon } from "@/components/icons";

type Props = {
  params: Promise<{ locale: string; slug: string }>;
  searchParams: Promise<{ page?: string; lang?: string }>;
};

const PAGE_SIZE = 12;

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { locale: raw, slug } = await params;
  const locale = resolveLocale(raw);
  const category = getCategoryBySlug(slug, locale);
  if (!category) return { title: t(locale, "state.notFoundTitle"), robots: { index: false } };
  const languages: Record<string, string> = {};
  for (const l of ["uz", "en", "ru"]) languages[l] = `/${l}/category/${slug}`;
  return {
    title: category.name,
    description: category.description,
    alternates: { canonical: `/${locale}/category/${slug}`, languages },
    openGraph: { title: `${category.name} · NewsVerse`, description: category.description, type: "website" },
  };
}

export default async function CategoryPage({ params, searchParams }: Props) {
  const { locale: raw, slug } = await params;
  const locale = resolveLocale(raw) as Locale;
  const { page: pageParam, lang } = await searchParams;
  const page = Math.max(1, Number(pageParam) || 1);
  const category = getCategoryBySlug(slug, locale);
  if (!category) notFound();

  const opts = {
    locale,
    categorySlug: slug,
    limit: PAGE_SIZE,
    offset: (page - 1) * PAGE_SIZE,
    contentLocale: lang && ["uz", "en", "ru"].includes(lang) ? lang : undefined,
  };
  const articles = listArticles(opts);
  const total = countArticles({ ...opts, limit: undefined, offset: undefined });
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const [lead, ...rest] = articles;

  return (
    <div className="container-nv py-6">
      <header className="mb-6 border-b pb-6" style={{ borderColor: "var(--line)" }}>
        <div className="flex items-center gap-3">
          <span
            className="flex h-12 w-12 items-center justify-center rounded-xl"
            style={{ background: `${category.color ?? "#FF1538"}1f`, color: category.color ?? "#FF1538" }}
          >
            <CategoryIcon name={category.icon} size={24} />
          </span>
          <div>
            <p className="kicker">{t(locale, "category.title")}</p>
            <h1 className="font-display text-3xl font-extrabold tracking-tight">{category.name}</h1>
          </div>
        </div>
        <p className="mt-2 max-w-2xl text-sm subtle">{category.description}</p>
        <div className="mt-3 flex flex-wrap items-center gap-2 text-[11px] subtle">
          <span className="chip">{formatNumber(total, locale)} {t(locale, "category.stories")}</span>
          {(["uz", "en", "ru"] as const).map((l) => (
            <Link
              key={l}
              href={`/${locale}/category/${slug}${l === "uz" ? "" : `?lang=${l}`}`}
              className={`chip hover:border-brand hover:text-brand ${lang === l || (!lang && l === "uz") ? "!border-brand !text-brand" : ""}`}
            >
              {l.toUpperCase()}
            </Link>
          ))}
        </div>
      </header>

      {articles.length === 0 ? (
        <EmptyState
          title={t(locale, "state.emptyTitle")}
          body={t(locale, "category.none")}
          actionHref={`/${locale}/latest`}
          actionLabel={t(locale, "home.latest")}
          icon={<CategoryIcon name={category.icon} size={22} />}
        />
      ) : (
        <>
          <div className="grid gap-5 lg:grid-cols-12">
            <div className="lg:col-span-8">
              {lead && <ArticleCard article={lead} locale={locale} variant="large" />}
            </div>
            <div className="space-y-3 lg:col-span-4">
              {rest.slice(0, 4).map((article) => (
                <ArticleCard key={article.id} article={article} locale={locale} variant="compact" />
              ))}
            </div>
          </div>
          <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {rest.slice(4).map((article) => (
              <ArticleCard key={article.id} article={article} locale={locale} />
            ))}
          </div>
          <Pagination
            basePath={`/${locale}/category/${slug}${lang ? `?lang=${lang}` : ""}`}
            page={page}
            totalPages={totalPages}
            prevLabel={t(locale, "common.prev")}
            nextLabel={t(locale, "common.next")}
          />
        </>
      )}
    </div>
  );
}
