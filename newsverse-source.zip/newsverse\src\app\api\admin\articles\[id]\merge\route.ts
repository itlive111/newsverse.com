import { z } from "zod";
import { guardAdmin } from "@/server/adminGuard";
import { json, parseBody, handleError } from "@/server/http";
import { mergeDuplicate } from "@/server/repo/admin";

type Ctx = { params: Promise<{ id: string }> };

export async function POST(request: Request, ctx: Ctx) {
  try {
    const user = await guardAdmin(request);
    const { id } = await ctx.params;
    const input = await parseBody(request, z.object({ duplicateId: z.string().uuid() }));
    mergeDuplicate(id, input.duplicateId, user);
    return json({ ok: true });
  } catch (err) {
    return handleError(err);
  }
}
