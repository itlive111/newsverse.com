import { guardAdmin } from "@/server/adminGuard";
import { json, parseBody, handleError } from "@/server/http";
import { articleSchema } from "@/lib/validation";
import { createArticle } from "@/server/repo/admin";

export async function POST(request: Request) {
  try {
    const user = await guardAdmin(request);
    const input = await parseBody(request, articleSchema);
    const id = createArticle(input, user);
    return json({ ok: true, id }, 201);
  } catch (err) {
    return handleError(err);
  }
}
