import { describe, expect, test } from "vitest";
import {
  articleSchema, categorySchema, emailChangeSchema, loginSchema, passwordChangeSchema, registerSchema, sourceSchema,
} from "@/lib/validation";

const validArticle = {
  categorySlug: "technology",
  status: "published",
  translations: [
    { locale: "en", title: "A valid headline about technology", summary: "A summary long enough to pass validation." },
  ],
};

describe("article schema", () => {
  test("accepts a valid article", () => {
    expect(articleSchema.safeParse(validArticle).success).toBe(true);
  });

  test("rejects a short title", () => {
    const bad = { ...validArticle, translations: [{ locale: "en", title: "Hi", summary: "A summary long enough." }] };
    expect(articleSchema.safeParse(bad).success).toBe(false);
  });

  test("rejects an unsupported locale", () => {
    const bad = { ...validArticle, translations: [{ locale: "de", title: "A valid headline here", summary: "Long enough summary text." }] };
    expect(articleSchema.safeParse(bad).success).toBe(false);
  });

  test("rejects javascript: URLs for images", () => {
    const bad = { ...validArticle, imageUrl: "javascript:alert(1)" };
    expect(articleSchema.safeParse(bad).success).toBe(false);
  });
});

describe("source schema", () => {
  test("requires an http(s) feed url", () => {
    expect(sourceSchema.safeParse({ name: "Feed", feedUrl: "https://example.com/rss" }).success).toBe(true);
    expect(sourceSchema.safeParse({ name: "Feed", feedUrl: "file:///etc/passwd" }).success).toBe(false);
  });
});

describe("category schema", () => {
  test("requires slug-safe characters", () => {
    const base = { names: { uz: "Sport", en: "Sports", ru: "Спорт" } };
    expect(categorySchema.safeParse({ ...base, slug: "sports" }).success).toBe(true);
    expect(categorySchema.safeParse({ ...base, slug: "Sports News" }).success).toBe(false);
  });
});

describe("auth schemas", () => {
  test("rejects weak passwords", () => {
    expect(
      registerSchema.safeParse({ name: "Ann", username: "ann", email: "a@b.co", password: "short", locale: "en" }).success,
    ).toBe(false);
  });

  test("accepts a complete registration", () => {
    const parsed = registerSchema.safeParse({
      name: "Ann Reader",
      username: "Ann_Reader",
      email: "ann@example.com",
      password: "long-enough-password",
      locale: "en",
    });
    expect(parsed.success).toBe(true);
    if (parsed.success) expect(parsed.data.username).toBe("ann_reader");
  });

  test("rejects usernames with spaces or symbols", () => {
    const base = { name: "Ann", email: "ann@example.com", password: "long-enough-password", locale: "en" };
    expect(registerSchema.safeParse({ ...base, username: "ann reader" }).success).toBe(false);
    expect(registerSchema.safeParse({ ...base, username: "a" }).success).toBe(false);
    expect(registerSchema.safeParse({ ...base, username: "ann-reader" }).success).toBe(false);
  });

  test("normalizes the login identifier", () => {
    const parsed = loginSchema.parse({ email: "  USER@Example.COM ", password: "whatever123" });
    expect(parsed.email).toBe("user@example.com");
    expect(loginSchema.safeParse({ email: "some_username", password: "whatever123" }).success).toBe(true);
  });

  test("password change requires a new password of 8+ characters", () => {
    expect(passwordChangeSchema.safeParse({ currentPassword: "old-pass", newPassword: "short" }).success).toBe(false);
    expect(passwordChangeSchema.safeParse({ currentPassword: "old-pass", newPassword: "new-long-pass" }).success).toBe(true);
  });

  test("email change validates the address", () => {
    expect(emailChangeSchema.safeParse({ newEmail: "not-an-email", password: "x" }).success).toBe(false);
    expect(emailChangeSchema.safeParse({ newEmail: "new@example.com", password: "x" }).success).toBe(true);
  });
});
