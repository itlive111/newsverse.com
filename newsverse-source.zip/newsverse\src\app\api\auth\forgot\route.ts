import crypto from "node:crypto";
import { get, run, nowIso } from "@/server/db";
import { ensureBootstrapped } from "@/server/db/bootstrap";
import { clientIpFromHeaders, rateLimit, randomTokenOrHash } from "@/server/lib/authHelpers";
import { json, parseBody, handleError } from "@/server/http";
import { forgotSchema } from "@/lib/validation";
import { siteUrl } from "@/lib/ui";

/**
 * Always answers 200 (no account enumeration). Without a configured mail
 * provider the reset link is written to the server log and documented.
 */
export async function POST(request: Request) {
  try {
    ensureBootstrapped();
    const ip = clientIpFromHeaders(request.headers) ?? "unknown";
    if (!rateLimit(`forgot:${ip}`, 5, 60 * 60 * 1000)) return json({ ok: true });
    const input = await parseBody(request, forgotSchema);
    const user = get<{ id: string; email: string }>("SELECT id, email FROM users WHERE email = ?", input.email);
    if (user) {
      const { token, hash } = randomTokenOrHash();
      run(
        "INSERT INTO auth_tokens (id, user_id, kind, token_hash, expires_at, created_at) VALUES (?,?,?,?,?,?)",
        crypto.randomUUID(), user.id, "reset", hash, new Date(Date.now() + 3600000).toISOString(), nowIso(),
      );
      const link = siteUrl(`/reset-password?token=${token}`);
      console.log(`[newsverse] password reset link for ${user.email}: ${link}`);
    }
    return json({ ok: true });
  } catch (err) {
    return handleError(err);
  }
}
