import { adminGate } from "@/server/adminPage";
import { notFound } from "next/navigation";
import { isLocale, t } from "@/i18n";
import { listCategories } from "@/server/repo/content";
import { ArticleEditor } from "@/components/admin/article-editor";

export const dynamic = "force-dynamic";

export default async function NewArticle({ params }: { params: Promise<{ locale: string }> }) {
  const { locale: raw } = await params;
  if (!isLocale(raw)) notFound();
  const locale = raw;
  await adminGate();
  const categories = listCategories(locale).map((c) => ({ slug: c.slug, name: c.name }));
  return (
    <div className="space-y-4">
      <h1 className="font-display text-2xl font-black tracking-tight">{t(locale, "admin.newArticle")}</h1>
      <p className="text-xs subtle">
        {t(locale, "article.sourceNotice")} · {t(locale, "common.optional")}
      </p>
      <ArticleEditor locale={locale} categories={categories} />
    </div>
  );
}
