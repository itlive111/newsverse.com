"use client";

import { useRouter } from "next/navigation";
import { t, type Locale } from "@/i18n";

export function LogoutButton({ locale, className = "" }: { locale: Locale; className?: string }) {
  const router = useRouter();
  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push(`/${locale}`);
    router.refresh();
  }
  return (
    <button type="button" onClick={logout} className={className || "btn-quiet"}>
      {t(locale, "nav.logout")}
    </button>
  );
}
