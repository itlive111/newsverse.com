import { describe, expect, test } from "vitest";
import { canonicalizeUrl, escapeXml, slugify, stripHtml, truncate } from "@/server/lib/text";
import { paragraphs } from "@/lib/ui";
import { hashPassword, verifyPassword } from "@/server/password";

describe("slugify", () => {
  test("handles Uzbek Latin with apostrophes", () => {
    expect(slugify("O‘zbekistonda yangi qonun qabul qilindi")).toBe("ozbekistonda-yangi-qonun-qabul-qilindi");
  });

  test("transliterates Cyrillic", () => {
    expect(slugify("Новости Узбекистана")).toBe("novosti-uzbekistana");
  });

  test("never returns an empty slug", () => {
    expect(slugify("!!!")).toBe("story");
  });
});

describe("stripHtml", () => {
  test("removes scripts and tags from untrusted feed content", () => {
    const dirty = '<p>Hello</p><script>alert("x")</script><b>world</b>';
    expect(stripHtml(dirty)).toBe("Hello world");
  });

  test("decodes entities and collapses whitespace", () => {
    expect(stripHtml("A&nbsp;&amp;&nbsp;B\n\nC")).toBe("A & B C");
  });
});

describe("canonicalizeUrl", () => {
  test("drops tracking parameters and fragments", () => {
    const url = canonicalizeUrl("https://www.Example.com/story/?utm_source=x&id=7#top");
    expect(url).toBe("https://example.com/story?id=7");
  });
});

describe("paragraphs", () => {
  test("splits on blank lines", () => {
    expect(paragraphs("One.\n\nTwo.")).toEqual(["One.", "Two."]);
  });

  test("splits a single long block into readable parts", () => {
    const long = Array.from({ length: 40 }, () => "This is a sentence about the world.").join(" ");
    const out = paragraphs(long);
    expect(out.length).toBeGreaterThan(1);
  });
});

describe("password hashing", () => {
  test("verifies the correct password only", () => {
    const stored = hashPassword("correct horse battery");
    expect(verifyPassword("correct horse battery", stored)).toBe(true);
    expect(verifyPassword("wrong password", stored)).toBe(false);
    expect(stored.startsWith("scrypt$")).toBe(true);
  });
});

describe("xml escaping", () => {
  test("escapes feed output", () => {
    expect(escapeXml("<a>&\"'")).toBe("&lt;a&gt;&amp;&quot;&apos;");
  });
});

describe("truncate", () => {
  test("keeps short text and ellipsizes long text", () => {
    expect(truncate("short", 20)).toBe("short");
    expect(truncate("a".repeat(30), 10).endsWith("…")).toBe(true);
  });
});
