import crypto from "node:crypto";

/** Re-exports of auth helpers usable from routes without circular imports. */
export { clientIpFromHeaders, rateLimit } from "@/server/auth";

export function randomTokenOrHash(): { token: string; hash: string } {
  const token = crypto.randomBytes(32).toString("base64url");
  return { token, hash: crypto.createHash("sha256").update(token).digest("hex") };
}
