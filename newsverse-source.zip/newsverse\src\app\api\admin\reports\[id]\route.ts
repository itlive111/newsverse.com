import { z } from "zod";
import { guardAdmin } from "@/server/adminGuard";
import { json, parseBody, handleError } from "@/server/http";
import { resolveReport } from "@/server/repo/admin";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(request: Request, ctx: Ctx) {
  try {
    await guardAdmin(request, "moderator");
    const { id } = await ctx.params;
    const input = await parseBody(request, z.object({ status: z.enum(["open", "resolved", "dismissed"]) }));
    resolveReport(id, input.status);
    return json({ ok: true });
  } catch (err) {
    return handleError(err);
  }
}
