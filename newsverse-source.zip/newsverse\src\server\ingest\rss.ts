import { XMLParser } from "fast-xml-parser";
import { canonicalizeUrl, stripHtml, truncate } from "@/server/lib/text";

export type FeedItem = {
  title: string;
  link: string;
  summary: string;
  content: string;
  publishedAt: string;
  imageUrl: string | null;
  videoUrl: string | null;
  author: string | null;
  categories: string[];
  guid: string;
};

export type ParsedFeed = { title: string; siteUrl: string | null; items: FeedItem[] };

const USER_AGENT =
  "NewsVerseBot/1.0 (+https://github.com/newsverse; feed reader; contact via site footer)";

const lastFetchByHost = new Map<string, number>();
const MIN_HOST_INTERVAL_MS = 2000;

async function politeFetch(url: string, timeoutMs = 15000): Promise<Response> {
  const host = new URL(url).host;
  const last = lastFetchByHost.get(host) ?? 0;
  const wait = MIN_HOST_INTERVAL_MS - (Date.now() - last);
  if (wait > 0) await new Promise((r) => setTimeout(r, wait));
  lastFetchByHost.set(host, Date.now());
  return fetch(url, {
    headers: {
      "user-agent": USER_AGENT,
      accept: "application/rss+xml, application/atom+xml, application/xml, text/xml;q=0.9, */*;q=0.5",
    },
    redirect: "follow",
    signal: AbortSignal.timeout(timeoutMs),
  });
}

function text(value: unknown): string {
  if (value == null) return "";
  if (typeof value === "string") return value;
  if (typeof value === "number") return String(value);
  if (Array.isArray(value)) return text(value[0]);
  if (typeof value === "object") {
    const obj = value as Record<string, unknown>;
    return text(obj["#text"] ?? obj.__cdata ?? "");
  }
  return "";
}

function attr(node: unknown, name: string): string {
  if (!node || typeof node !== "object") return "";
  const obj = node as Record<string, unknown>;
  const value = obj[`@_${name}`];
  return typeof value === "string" ? value : "";
}

function asArray<T>(value: T | T[] | undefined | null): T[] {
  if (value == null) return [];
  return Array.isArray(value) ? value : [value];
}

function findVideo(item: Record<string, unknown>): string | null {
  for (const node of asArray(item["media:content"] as never)) {
    const url = attr(node, "url");
    const type = attr(node, "type");
    if (url && type.startsWith("video")) return url;
  }
  for (const node of asArray(item.enclosure as never)) {
    const url = attr(node, "url");
    const type = attr(node, "type");
    if (url && type.startsWith("video")) return url;
  }
  return null;
}

function findImage(item: Record<string, unknown>): string | null {
  const mediaContent = asArray(item["media:content"] as never);
  for (const m of mediaContent) {
    const url = attr(m, "url");
    if (url) return url;
  }
  const thumbs = asArray(item["media:thumbnail"] as never);
  for (const t of thumbs) {
    const url = attr(t, "url");
    if (url) return url;
  }
  const enclosure = asArray(item.enclosure as never);
  for (const e of enclosure) {
    const url = attr(e, "url");
    const type = attr(e, "type");
    if (url && (!type || type.startsWith("image"))) return url;
  }
  const html = `${text(item["content:encoded"])} ${text(item.description)} ${text(item.content)}`;
  const match = html.match(/<img[^>]+src=["']([^"']+)["']/i);
  return match?.[1] ?? null;
}

function safeDate(value: string, fallback = new Date().toISOString()): string {
  if (!value) return fallback;
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return fallback;
  // Reject dates far in the future (broken feed clocks) and pre-1990 values.
  if (d.getTime() > Date.now() + 86400000) return fallback;
  if (d.getTime() < Date.UTC(1990, 0, 1)) return fallback;
  return d.toISOString();
}

export function parseFeedXml(xml: string): ParsedFeed {
  const parser = new XMLParser({
    ignoreAttributes: false,
    attributeNamePrefix: "@_",
    trimValues: true,
    processEntities: true,
    allowBooleanAttributes: true,
  });
  const doc = parser.parse(xml) as Record<string, any>;

  if (doc.rss?.channel) {
    const channel = doc.rss.channel;
    const items = asArray(channel.item) as Record<string, unknown>[];
    return {
      title: text(channel.title) || "Untitled feed",
      siteUrl: text(channel.link) || null,
      items: items.map((item) => normalizeItem(item, "rss")),
    };
  }
  if (doc.feed) {
    const feed = doc.feed;
    const entries = asArray(feed.entry) as Record<string, unknown>[];
    return {
      title: text(feed.title) || "Untitled feed",
      siteUrl: asArray(feed.link).map((l) => attr(l, "href"))[0] ?? null,
      items: entries.map((entry) => normalizeItem(entry, "atom")),
    };
  }
  if (doc["rdf:RDF"]?.item) {
    const items = asArray(doc["rdf:RDF"].item) as Record<string, unknown>[];
    return {
      title: text(doc["rdf:RDF"].channel?.title) || "Untitled feed",
      siteUrl: text(doc["rdf:RDF"].channel?.link) || null,
      items: items.map((item) => normalizeItem(item, "rss")),
    };
  }
  throw new Error("Feed format not recognised (expected RSS, Atom or RDF)");
}

function normalizeItem(item: Record<string, unknown>, kind: "rss" | "atom"): FeedItem {
  const rawLink =
    kind === "atom"
      ? asArray(item.link).map((l) => attr(l, "href")).find((h) => !!h) ?? text(item.id)
      : text(item.link) || text(item.guid);
  const summarySource = text(item.description) || text(item.summary) || text(item["content:encoded"]);
  const contentSource = text(item["content:encoded"]) || text(item.content) || summarySource;
  const published = text(item.pubDate) || text(item.published) || text(item.updated) || text(item["dc:date"]);
  const cats = asArray(item.category).map((c) => text(c)).filter(Boolean);
  return {
    title: stripHtml(text(item.title)).slice(0, 300),
    link: canonicalizeUrl(rawLink),
    summary: truncate(stripHtml(summarySource), 400),
    content: stripHtml(contentSource).slice(0, 8000),
    publishedAt: safeDate(published),
    imageUrl: findImage(item),
    videoUrl: findVideo(item),
    author: stripHtml(text(item["dc:creator"]) || text(item.author) || text(item["author"]?.toString?.() ?? "")).slice(0, 120) || null,
    categories: cats.slice(0, 6),
    guid: text(item.guid) || rawLink,
  };
}

/**
 * SSRF guard: feeds are configured by staff, but a mistyped or malicious URL
 * must never make the server fetch loopback, link-local or private addresses.
 */
export function assertPublicFeedUrl(raw: string): URL {
  let url: URL;
  try {
    url = new URL(raw);
  } catch {
    throw new Error("Feed URL is not a valid URL");
  }
  if (!/^https?:$/.test(url.protocol)) throw new Error("Feed URL must use http or https");
  const host = url.hostname.toLowerCase().replace(/^\[|\]$/g, "");
  if (
    host === "localhost" ||
    host.endsWith(".localhost") ||
    host.endsWith(".local") ||
    host.endsWith(".internal") ||
    host === "0.0.0.0" ||
    host === "::1" ||
    host === "::" ||
    /^127\./.test(host) ||
    /^10\./.test(host) ||
    /^192\.168\./.test(host) ||
    /^169\.254\./.test(host) ||
    /^172\.(1[6-9]|2\d|3[01])\./.test(host) ||
    /^f[cd][0-9a-f]{2}:/i.test(host)
  ) {
    throw new Error("Feed URL must point to a public host");
  }
  return url;
}

export async function fetchFeed(url: string): Promise<ParsedFeed> {
  assertPublicFeedUrl(url);
  let res: Response;
  try {
    res = await politeFetch(url);
  } catch (err) {
    throw new Error(`Network error: ${(err as Error).message}`);
  }
  if (!res.ok) throw new Error(`HTTP ${res.status} from feed`);
  const contentType = res.headers.get("content-type") ?? "";
  if (contentType.includes("text/html")) {
    throw new Error("Feed URL returned HTML (not an RSS/Atom document)");
  }
  const body = await res.text();
  if (body.length > 5_000_000) throw new Error("Feed document too large");
  return parseFeedXml(body);
}
