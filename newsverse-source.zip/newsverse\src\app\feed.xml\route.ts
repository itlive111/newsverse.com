import { all } from "@/server/db";
import { ensureBootstrapped } from "@/server/db/bootstrap";
import { escapeXml } from "@/server/lib/text";
import { siteUrl } from "@/lib/ui";
import { locales, type Locale } from "@/i18n";

/** RSS 2.0 feed of NewsVerse's own published summaries. */
export async function GET(request: Request) {
  ensureBootstrapped();
  const url = new URL(request.url);
  const requested = url.searchParams.get("locale") ?? "uz";
  const locale = (locales as readonly string[]).includes(requested) ? (requested as Locale) : "uz";

  const rows = all<{ title: string; summary: string; slug: string; published_at: string; source_name: string | null; source_url: string | null }>(
    `SELECT COALESCE(t.title,o.title) AS title, COALESCE(t.summary,o.summary) AS summary,
            COALESCE(t.slug,o.slug) AS slug, a.published_at, a.source_name, a.source_url
     FROM articles a
     LEFT JOIN article_translations t ON t.article_id = a.id AND t.locale = ?
     LEFT JOIN article_translations o ON o.article_id = a.id AND o.locale = a.original_locale
     WHERE a.status = 'published' AND a.deleted_at IS NULL AND a.published_at IS NOT NULL
     ORDER BY a.published_at DESC LIMIT 50`,
    locale,
  );

  const items = rows
    .map(
      (row) => `    <item>
      <title>${escapeXml(row.title)}</title>
      <link>${escapeXml(siteUrl(`/${locale}/news/${row.slug}`))}</link>
      <guid isPermaLink="true">${escapeXml(siteUrl(`/${locale}/news/${row.slug}`))}</guid>
      <description>${escapeXml(row.summary)}</description>
      <pubDate>${new Date(row.published_at).toUTCString()}</pubDate>
      <language>${locale}-${locale.toUpperCase()}</language>
      ${row.source_name ? `<source url="${escapeXml(row.source_url ?? "")}">${escapeXml(row.source_name)}</source>` : ""}
    </item>`,
    )
    .join("\n");

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">
  <channel>
    <title>NewsVerse — ${locale.toUpperCase()}</title>
    <link>${escapeXml(siteUrl(`/${locale}`))}</link>
    <description>${escapeXml("NewsVerse — the world's latest news in one place.")}</description>
    <language>${locale}</language>
    <lastBuildDate>${new Date().toUTCString()}</lastBuildDate>
    <atom:link href="${escapeXml(siteUrl(`/feed.xml?locale=${locale}`))}" rel="self" type="application/rss+xml" />
${items}
  </channel>
</rss>`;

  return new Response(xml, {
    headers: {
      "content-type": "application/rss+xml; charset=utf-8",
      "cache-control": "public, max-age=600, s-maxage=600",
    },
  });
}
