import { guardAdmin } from "@/server/adminGuard";
import { json, parseBody, fail, handleError } from "@/server/http";
import { articleActionSchema, articleSchema } from "@/lib/validation";
import { setArticleStatus, updateArticle } from "@/server/repo/admin";
import { get } from "@/server/db";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(request: Request, ctx: Ctx) {
  try {
    const user = await guardAdmin(request);
    const { id } = await ctx.params;
    if (!get("SELECT id FROM articles WHERE id = ? AND deleted_at IS NULL", id)) return fail("Not found", 404);
    const input = await parseBody(request, articleSchema);
    updateArticle(id, input, user);
    return json({ ok: true });
  } catch (err) {
    return handleError(err);
  }
}

export async function POST(request: Request, ctx: Ctx) {
  try {
    const user = await guardAdmin(request);
    const { id } = await ctx.params;
    const input = await parseBody(request, articleActionSchema);
    setArticleStatus(id, input.action, user);
    return json({ ok: true, action: input.action });
  } catch (err) {
    return handleError(err);
  }
}

export async function DELETE(request: Request, ctx: Ctx) {
  try {
    const user = await guardAdmin(request);
    const { id } = await ctx.params;
    setArticleStatus(id, "delete", user);
    return json({ ok: true });
  } catch (err) {
    return handleError(err);
  }
}
