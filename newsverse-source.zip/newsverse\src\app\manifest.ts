import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "NewsVerse",
    short_name: "NewsVerse",
    description: "Dunyodagi eng so‘nggi yangiliklar bir joyda!",
    start_url: "/uz",
    scope: "/",
    display: "standalone",
    background_color: "#09090D",
    theme_color: "#FF1538",
    icons: [
      { src: "/brand/icon-192.png", sizes: "192x192", type: "image/png", purpose: "any" },
      { src: "/brand/icon-512.png", sizes: "512x512", type: "image/png", purpose: "any" },
      { src: "/brand/icon-512.png", sizes: "512x512", type: "image/png", purpose: "maskable" },
    ],
  };
}
