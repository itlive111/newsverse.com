import type { Metadata } from "next";
import { resolveLocale, t, type Locale } from "@/i18n";
import { ResetForm } from "@/components/auth-forms";

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const locale = resolveLocale((await params).locale);
  return { title: t(locale, "auth.resetTitle"), robots: { index: false } };
}

export default async function ResetPage({
  params,
  searchParams,
}: {
  params: Promise<{ locale: string }>;
  searchParams: Promise<{ token?: string }>;
}) {
  const locale = resolveLocale((await params).locale) as Locale;
  const token = (await searchParams).token ?? "";
  return (
    <div className="container-nv max-w-md py-12">
      <h1 className="font-display text-3xl font-extrabold">{t(locale, "auth.resetTitle")}</h1>
      <div className="card mt-6 p-6">
        {token ? <ResetForm locale={locale} token={token} /> : <p className="text-sm subtle">{t(locale, "common.error")}</p>}
      </div>
    </div>
  );
}
