import fs from "node:fs";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";
import { applyMigrations } from "./migrate";

/**
 * Single shared SQLite connection per server process.
 *
 * `node:sqlite` ships with Node 22.5+/24, so there is no native build step and
 * no external database server required to run the platform. Every query goes
 * through prepared statements with bound parameters (no string interpolation).
 *
 * Production note: for multi-instance deployments put PostgreSQL in front of
 * the repository layer; the SQL is intentionally simple and portable.
 */
const globalForDb = globalThis as unknown as { __nvDb?: DatabaseSync; __nvMigrations?: string[] };

export function dbPath(): string {
  const configured = process.env.DATABASE_PATH || "./data/newsverse.db";
  return path.isAbsolute(configured) ? configured : path.join(process.cwd(), configured);
}

export function getDb(): DatabaseSync {
  if (globalForDb.__nvDb) return globalForDb.__nvDb;
  const file = dbPath();
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const db = new DatabaseSync(file);
  db.exec("PRAGMA journal_mode = WAL");
  db.exec("PRAGMA foreign_keys = ON");
  db.exec("PRAGMA busy_timeout = 5000");
  db.exec("PRAGMA synchronous = NORMAL");
  const res = applyMigrations(db);
  globalForDb.__nvMigrations = res.applied;
  globalForDb.__nvDb = db;
  return db;
}

export function migrationsAppliedThisBoot(): string[] {
  return globalForDb.__nvMigrations ?? [];
}

export function all<T = Record<string, unknown>>(sql: string, ...params: unknown[]): T[] {
  return getDb().prepare(sql).all(...(params as never[])) as T[];
}

export function get<T = Record<string, unknown>>(sql: string, ...params: unknown[]): T | undefined {
  return getDb().prepare(sql).get(...(params as never[])) as T | undefined;
}

export function run(sql: string, ...params: unknown[]): { changes: number; lastInsertRowid: number } {
  const r = getDb().prepare(sql).run(...(params as never[]));
  return { changes: Number(r.changes), lastInsertRowid: Number(r.lastInsertRowid) };
}

export function tx<T>(fn: () => T): T {
  const db = getDb();
  db.exec("BEGIN IMMEDIATE");
  try {
    const out = fn();
    db.exec("COMMIT");
    return out;
  } catch (err) {
    db.exec("ROLLBACK");
    throw err;
  }
}

export function nowIso(): string {
  return new Date().toISOString();
}
