import crypto from "node:crypto";
import { NextResponse } from "next/server";
import { get, run, nowIso } from "@/server/db";
import { audit } from "@/server/auth";

type TokenRow = {
  id: string;
  user_id: string;
  kind: string;
  expires_at: string;
  used_at: string | null;
  meta: string | null;
};

/** Consumes an e-mail verification / e-mail change token, then redirects. */
export async function GET(request: Request) {
  const url = new URL(request.url);
  const token = url.searchParams.get("token") ?? "";
  const locale = url.searchParams.get("locale") ?? "uz";

  if (!token) return NextResponse.redirect(new URL(`/${locale}/account?verify=invalid`, url.origin));

  const hash = crypto.createHash("sha256").update(token).digest("hex");
  const row = get<TokenRow>(
    "SELECT id, user_id, kind, expires_at, used_at, meta FROM auth_tokens WHERE token_hash = ? AND kind IN ('verify','email_change')",
    hash,
  );

  if (!row || row.used_at || new Date(row.expires_at).getTime() < Date.now()) {
    return NextResponse.redirect(new URL(`/${locale}/account?verify=invalid`, url.origin));
  }

  const user = get<{ email: string; locale: string }>("SELECT email, locale FROM users WHERE id = ?", row.user_id);
  if (!user) return NextResponse.redirect(new URL(`/${locale}/account?verify=invalid`, url.origin));

  if (row.kind === "email_change" && row.meta) {
    let nextEmail = "";
    try {
      nextEmail = String((JSON.parse(row.meta) as { email?: string }).email ?? "");
    } catch {
      nextEmail = "";
    }
    if (!nextEmail) return NextResponse.redirect(new URL(`/${user.locale}/account?verify=invalid`, url.origin));
    if (get("SELECT id FROM users WHERE email = ? AND id <> ?", nextEmail, row.user_id)) {
      return NextResponse.redirect(new URL(`/${user.locale}/account?verify=taken`, url.origin));
    }
    run(
      "UPDATE users SET email = ?, pending_email = NULL, email_verified = 1, email_verified_at = ?, updated_at = ? WHERE id = ?",
      nextEmail,
      nowIso(),
      nowIso(),
      row.user_id,
    );
  } else {
    run(
      "UPDATE users SET email_verified = 1, email_verified_at = COALESCE(email_verified_at, ?), pending_email = NULL, updated_at = ? WHERE id = ?",
      nowIso(),
      nowIso(),
      row.user_id,
    );
  }

  run("UPDATE auth_tokens SET used_at = ? WHERE id = ?", nowIso(), row.id);
  audit({
    actor: { id: row.user_id, email: user.email },
    action: row.kind === "email_change" ? "auth.email_changed" : "auth.email_verified",
    entity: "user",
    entityId: row.user_id,
  });

  return NextResponse.redirect(new URL(`/${user.locale}/account?verify=ok`, url.origin));
}
