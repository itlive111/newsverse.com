import { guardAdmin } from "@/server/adminGuard";
import { json, parseBody, fail, handleError } from "@/server/http";
import { userPatchSchema } from "@/lib/validation";
import { updateUser } from "@/server/repo/admin";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(request: Request, ctx: Ctx) {
  try {
    const user = await guardAdmin(request, "admin");
    const { id } = await ctx.params;
    const input = await parseBody(request, userPatchSchema);
    if (!["admin", "super_admin"].includes(user.role) && (input.role || input.status)) {
      return fail("Only administrators can change roles or status", 403);
    }
    updateUser(id, { role: input.role, status: input.status }, user);
    return json({ ok: true });
  } catch (err) {
    return handleError(err);
  }
}
