import { guardAdmin } from "@/server/adminGuard";
import { json, parseBody, handleError } from "@/server/http";
import { settingsSchema } from "@/lib/validation";
import { setSetting } from "@/server/repo/settings";
import { audit } from "@/server/auth";

const ALLOWED_PREFIXES = ["site_", "seo_", "ingest_", "ai_", "moderation_", "auto_", "comments_", "newsletter_", "ads_", "payments_", "notify_", "failure_", "breaking_", "contact_", "analytics_", "default_", "weather_", "markets_", "sports_"];

export async function POST(request: Request) {
  try {
    const user = await guardAdmin(request, "admin");
    const input = await parseBody(request, settingsSchema);
    const changed: string[] = [];
    for (const [key, value] of Object.entries(input)) {
      if (!ALLOWED_PREFIXES.some((p) => key.startsWith(p))) continue;
      if (typeof value !== "string" || value.length > 5000) continue;
      setSetting(key, value);
      changed.push(key);
    }
    audit({ actor: user, action: "settings.update", entity: "settings", meta: { keys: changed } });
    return json({ ok: true, updated: changed.length });
  } catch (err) {
    return handleError(err);
  }
}
