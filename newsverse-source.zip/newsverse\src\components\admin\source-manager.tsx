"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { locales, t, type Locale } from "@/i18n";

type TestResult = { title: string; siteUrl: string; items: number; sample: { title: string; publishedAt: string | null }[] };

export function SourceManager({ locale, categories }: { locale: Locale; categories: { slug: string; name: string }[] }) {
  const [form, setForm] = useState({
    name: "",
    feedUrl: "",
    siteUrl: "",
    categorySlug: categories[0]?.slug ?? "world",
    locale: "en" as Locale,
    intervalMinutes: "60",
    trust: "3",
    moderation: "hybrid",
    enabled: true,
  });
  const [test, setTest] = useState<TestResult | null>(null);
  const [busy, setBusy] = useState<"" | "test" | "add">("");
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const router = useRouter();

  async function testFeed() {
    setBusy("test");
    setError("");
    setTest(null);
    const res = await fetch("/api/admin/sources/test", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ feedUrl: form.feedUrl }),
    }).catch(() => null);
    const data = await res?.json().catch(() => ({}));
    if (!res?.ok) {
      setError(data?.error ?? "Feed could not be read");
    } else {
      setTest(data as TestResult);
    }
    setBusy("");
  }

  async function addSource() {
    setBusy("add");
    setError("");
    setNotice("");
    const res = await fetch("/api/admin/sources", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        ...form,
        intervalMinutes: Number(form.intervalMinutes),
        trust: Number(form.trust),
      }),
    }).catch(() => null);
    const data = await res?.json().catch(() => ({}));
    if (!res?.ok) {
      setError(data?.issues?.map((i: { path: string; message: string }) => `${i.path}: ${i.message}`).join("; ") || data?.error || "error");
    } else {
      setNotice(t(locale, "admin.saved"));
      setForm((f) => ({ ...f, name: "", feedUrl: "", siteUrl: "" }));
      setTest(null);
      router.refresh();
    }
    setBusy("");
  }

  return (
    <div className="space-y-3">
      <div className="grid gap-2 sm:grid-cols-2">
        <div>
          <label className="label" htmlFor="src-name">Name *</label>
          <input id="src-name" className="input !py-1.5 !text-xs" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
        </div>
        <div>
          <label className="label" htmlFor="src-feed">RSS / Atom URL *</label>
          <input id="src-feed" className="input !py-1.5 !text-xs" value={form.feedUrl} onChange={(e) => setForm({ ...form, feedUrl: e.target.value })} placeholder="https://example.com/rss.xml" />
        </div>
        <div>
          <label className="label" htmlFor="src-site">Site URL</label>
          <input id="src-site" className="input !py-1.5 !text-xs" value={form.siteUrl} onChange={(e) => setForm({ ...form, siteUrl: e.target.value })} />
        </div>
        <div>
          <label className="label" htmlFor="src-cat">{t(locale, "search.category")}</label>
          <select id="src-cat" className="input !py-1.5 !text-xs" value={form.categorySlug} onChange={(e) => setForm({ ...form, categorySlug: e.target.value })}>
            {categories.map((c) => <option key={c.slug} value={c.slug}>{c.name}</option>)}
          </select>
        </div>
        <div className="grid grid-cols-3 gap-2">
          <div>
            <label className="label" htmlFor="src-locale">{t(locale, "common.language")}</label>
            <select id="src-locale" className="input !py-1.5 !text-xs" value={form.locale} onChange={(e) => setForm({ ...form, locale: e.target.value as Locale })}>
              {locales.map((l) => <option key={l} value={l}>{l}</option>)}
            </select>
          </div>
          <div>
            <label className="label" htmlFor="src-int" title="60 = hourly, 1440 = daily">Min (60/1440)</label>
            <input id="src-int" type="number" min={5} max={1440} className="input !py-1.5 !text-xs" value={form.intervalMinutes} onChange={(e) => setForm({ ...form, intervalMinutes: e.target.value })} />
          </div>
          <div>
            <label className="label" htmlFor="src-trust">Trust</label>
            <input id="src-trust" type="number" min={1} max={5} className="input !py-1.5 !text-xs" value={form.trust} onChange={(e) => setForm({ ...form, trust: e.target.value })} />
          </div>
        </div>
        <div>
          <label className="label" htmlFor="src-mod">{t(locale, "admin.moderationMode")}</label>
          <select id="src-mod" className="input !py-1.5 !text-xs" value={form.moderation} onChange={(e) => setForm({ ...form, moderation: e.target.value })}>
            <option value="auto">{t(locale, "admin.modeAuto")}</option>
            <option value="review">{t(locale, "admin.modeReview")}</option>
            <option value="hybrid">{t(locale, "admin.modeHybrid")}</option>
          </select>
        </div>
      </div>

      <label className="flex items-center gap-2 text-xs">
        <input type="checkbox" checked={form.enabled} onChange={(e) => setForm({ ...form, enabled: e.target.checked })} />
        {t(locale, "admin.ingestionEnabled")}
      </label>

      <div className="flex flex-wrap gap-2">
        <button type="button" onClick={testFeed} disabled={busy !== "" || !form.feedUrl} className="btn-ghost !py-1.5 !text-xs">
          {busy === "test" ? t(locale, "common.loading") : t(locale, "admin.testFeed")}
        </button>
        <button type="button" onClick={addSource} disabled={busy !== "" || !form.name || !form.feedUrl} className="btn-primary !py-1.5 !text-xs">
          {busy === "add" ? t(locale, "common.loading") : t(locale, "common.save")}
        </button>
      </div>

      {error && <p className="break-words text-[11px] text-brand">{error}</p>}
      {notice && <p className="text-[11px] text-emerald-400">{notice}</p>}
      {test && (
        <div className="rounded-lg border p-3 text-xs" style={{ borderColor: "var(--line)" }}>
          <p className="font-semibold">{test.title}</p>
          <p className="text-[10px] subtle">{test.items} items · {test.siteUrl}</p>
          <ul className="mt-1 space-y-0.5 text-[10px] subtle">
            {test.sample.map((s, i) => <li key={i}>• {s.title}</li>)}
          </ul>
        </div>
      )}
    </div>
  );
}
