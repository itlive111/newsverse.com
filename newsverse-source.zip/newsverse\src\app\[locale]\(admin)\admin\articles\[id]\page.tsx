import { adminGate } from "@/server/adminPage";
import Link from "next/link";
import { notFound } from "next/navigation";
import { formatDate, isLocale, locales, t, type Locale } from "@/i18n";
import { getAdminArticle } from "@/server/repo/admin";
import { listCategories } from "@/server/repo/content";
import { ArticleEditor, type EditorTranslation } from "@/components/admin/article-editor";
import { MergeForm } from "@/components/admin/merge-form";
import { ActionButton } from "@/components/admin/action-button";
import { AdminSection, StatusBadge } from "@/components/admin/ui";

export const dynamic = "force-dynamic";

export default async function EditArticle({
  params,
}: {
  params: Promise<{ locale: string; id: string }>;
}) {
  const { locale: raw, id } = await params;
  if (!isLocale(raw)) notFound();
  const locale = raw;
  await adminGate();
  const data = getAdminArticle(id);
  if (!data) notFound();
  const { article, translations, tags, source, logs } = data;

  const byLocale = new Map(translations.map((tr: Record<string, string>) => [tr.locale, tr]));
  const editorTranslations: EditorTranslation[] = locales.map((l) => {
    const tr = byLocale.get(l);
    return {
      locale: l,
      title: tr?.title ?? "",
      subtitle: tr?.subtitle ?? "",
      summary: tr?.summary ?? "",
      content: tr?.content ?? "",
    };
  });
  const allCategories = listCategories(locale, true);
  const categories = allCategories.map((c) => ({ slug: c.slug, name: c.name }));
  const currentCategory = allCategories.find((c) => c.id === article.category_id)?.slug ?? "world";

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h1 className="font-display text-2xl font-black tracking-tight">{t(locale, "common.edit")}</h1>
          <p className="text-[11px] subtle">
            {article.id} · {t(locale, "common.updated")}: {formatDate(article.updated_at, locale)}
            {article.is_ai_assisted ? " · AI-assisted" : ""}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <StatusBadge status={article.status} />
          <ActionButton endpoint={`/api/admin/articles/${id}`} body={{ action: "publish" }} label={t(locale, "admin.publish")} variant="primary" />
          <ActionButton endpoint={`/api/admin/articles/${id}`} body={{ action: "archive" }} label={t(locale, "admin.archive")} />
        </div>
      </div>

      <ArticleEditor
        locale={locale}
        categories={categories}
        initial={{
          id: article.id,
          status: article.status,
          scheduledFor: article.scheduled_for ? article.scheduled_for.slice(0, 16) : "",
          categorySlug: currentCategory,
          imageUrl: article.image_url ?? "",
          imageCredit: article.image_credit ?? "",
          sourceName: article.source_name ?? "",
          sourceUrl: article.source_url ?? "",
          isBreaking: !!article.is_breaking,
          isOpinion: !!article.is_opinion,
          isSponsored: !!article.is_sponsored,
          tags: tags.join(", "),
          translations: editorTranslations,
        }}
      />

      <div className="grid gap-4 lg:grid-cols-3">
        <AdminSection title={t(locale, "admin.merge")}>
          <MergeForm locale={locale} articleId={id} />
          <p className="mt-2 text-[11px] subtle">
            The duplicate is archived and linked to this story, keeping its source URL in the audit trail.
          </p>
        </AdminSection>

        <AdminSection title={t(locale, "admin.sources")}>
          {source ? (
            <div className="text-xs">
              <p className="font-semibold">{source.name}</p>
              <Link href={source.feed_url} target="_blank" rel="noopener noreferrer" className="break-all text-[10px] underline subtle">
                {source.feed_url}
              </Link>
              <p className="mt-1 text-[10px] subtle">
                {t(locale, "admin.sourceHealth")}: {source.consecutive_failures > 0 ? `failing ×${source.consecutive_failures}` : "healthy"}
              </p>
            </div>
          ) : (
            <p className="text-xs subtle">{t(locale, "common.original")}</p>
          )}
          {article.source_url && (
            <a href={article.source_url} target="_blank" rel="noopener noreferrer" className="mt-2 block break-all text-[10px] underline">
              {article.source_url}
            </a>
          )}
        </AdminSection>

        <AdminSection title={t(locale, "admin.logs")}>
          {logs.length ? (
            <ul className="space-y-1.5 text-[10px]">
              {logs.map((log: Record<string, string>, i: number) => (
                <li key={i} className="border-t pt-1 first:border-0 first:pt-0" style={{ borderColor: "var(--line)" }}>
                  <span className={log.level === "error" ? "text-brand" : "subtle"}>[{log.level}]</span> {log.message}
                  <span className="block subtle">{formatDate(log.created_at, locale)}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-xs subtle">{t(locale, "common.noResults")}</p>
          )}
        </AdminSection>
      </div>
    </div>
  );
}
