import Link from "next/link";
import type { ArticleCard as ArticleCardType } from "@/server/repo/content";
import { formatNumber, relativeTime, t, type Locale } from "@/i18n";
import { articlePath, categoryPath } from "@/lib/ui";
import { CategoryIcon, IconClock, IconPlay } from "@/components/icons";

type Variant = "hero" | "large" | "standard" | "compact" | "rail" | "list";

function Media({
  article,
  className,
  sizes,
}: {
  article: ArticleCardType;
  className: string;
  sizes?: string;
}) {
  return (
    <div className={`relative overflow-hidden bg-ink-800 ${className}`}>
      {article.image_url ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={article.image_url}
          alt=""
          loading="lazy"
          referrerPolicy="no-referrer"
          sizes={sizes}
          className="h-full w-full object-cover transition duration-500 group-hover:scale-[1.03]"
        />
      ) : (
        <div
          className="flex h-full w-full items-center justify-center"
          style={{
            background: `radial-gradient(120% 120% at 20% 10%, ${article.category_color ?? "#FF1538"}55, #0c0c12 65%)`,
          }}
        >
          <span className="font-display text-3xl font-black text-white/20">NV</span>
        </div>
      )}
    </div>
  );
}

function Badges({ article, locale }: { article: ArticleCardType; locale: Locale }) {
  return (
    <div className="flex flex-wrap items-center gap-1.5">
      {article.is_breaking && (
        <span className="badge-breaking">
          <span className="h-1.5 w-1.5 rounded-full bg-white animate-pulseDot" />
          {t(locale, "home.breaking")}
        </span>
      )}
      {article.is_demo && <span className="chip !text-[10px]">{t(locale, "common.demo")}</span>}
      {article.is_opinion && <span className="chip !text-[10px]">{t(locale, "article.opinion")}</span>}
      {article.is_sponsored && <span className="chip !text-[10px] !text-brand">{t(locale, "article.sponsored")}</span>}
    </div>
  );
}

function Meta({ article, locale }: { article: ArticleCardType; locale: Locale }) {
  return (
    <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-[11px] subtle">
      {article.source_name && <span className="font-semibold text-[color:var(--text)]/80">{article.source_name}</span>}
      {article.source_name && <span aria-hidden>·</span>}
      <time dateTime={article.published_at}>{relativeTime(article.published_at, locale)}</time>
      <span aria-hidden>·</span>
      <span className="inline-flex items-center gap-1">
        <IconClock size={12} /> {article.reading_minutes} {t(locale, "common.minRead")}
      </span>
    </div>
  );
}

export function ArticleCard({
  article,
  locale,
  variant = "standard",
  showSummary = true,
}: {
  article: ArticleCardType;
  locale: Locale;
  variant?: Variant;
  showSummary?: boolean;
}) {
  const href = articlePath(locale, article.slug);
  const categoryHref = article.category_slug ? categoryPath(locale, article.category_slug) : null;

  if (variant === "hero") {
    return (
      <article className="group relative overflow-hidden rounded-2xl border" style={{ borderColor: "var(--line)" }}>
        <Link href={href} className="block">
          <Media article={article} className="aspect-[16/10] w-full sm:aspect-[16/9]" />
          <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#09090d] via-[#09090d]/55 to-transparent" />
          <div className="absolute inset-x-0 bottom-0 p-5 sm:p-7">
            <Badges article={article} locale={locale} />
            {article.category_name && (
              <p className="kicker mt-3">{article.category_name}</p>
            )}
            <h2 className="mt-1.5 max-w-3xl font-display text-2xl font-extrabold leading-tight text-white sm:text-4xl">
              {article.title}
            </h2>
            {showSummary && (
              <p className="mt-2.5 hidden max-w-2xl text-sm leading-relaxed text-white/75 sm:block">
                {article.summary}
              </p>
            )}
            <div className="mt-3 flex flex-wrap items-center gap-2 text-[11px] text-white/60">
              {article.source_name && <span className="font-semibold text-white/85">{article.source_name}</span>}
              <span aria-hidden>·</span>
              <time dateTime={article.published_at}>{relativeTime(article.published_at, locale)}</time>
              <span aria-hidden>·</span>
              <span className="inline-flex items-center gap-1"><IconClock size={12} />{article.reading_minutes} {t(locale, "common.minRead")}</span>
            </div>
          </div>
        </Link>
      </article>
    );
  }

  if (variant === "rail") {
    return (
      <article className="group w-[260px] shrink-0 sm:w-[300px]">
        <Link href={href} className="card card-hover block h-full">
          <Media article={article} className="aspect-[16/10] w-full" />
          <div className="p-4">
            <Badges article={article} locale={locale} />
            <p className="kicker mt-2">{article.category_name}</p>
            <h3 className="mt-1 line-clamp-2 text-base font-bold leading-snug group-hover:text-brand">{article.title}</h3>
            <div className="mt-2"><Meta article={article} locale={locale} /></div>
          </div>
        </Link>
      </article>
    );
  }

  if (variant === "compact" || variant === "list") {
    return (
      <article className="group flex gap-3">
        <Link href={href} className="shrink-0">
          <Media article={article} className="h-16 w-24 rounded-lg sm:h-20 sm:w-28" />
        </Link>
        <div className="min-w-0">
          {article.category_name && (
            categoryHref ? (
              <Link href={categoryHref} className="kicker text-[10px]">{article.category_name}</Link>
            ) : null
          )}
          <Link href={href}>
            <h3 className="line-clamp-2 text-sm font-bold leading-snug transition group-hover:text-brand">{article.title}</h3>
          </Link>
          <p className="mt-1 text-[11px] subtle">
            {article.source_name ? `${article.source_name} · ` : ""}
            {relativeTime(article.published_at, locale)}
          </p>
        </div>
      </article>
    );
  }

  if (variant === "large") {
    return (
      <article className="group">
        <Link href={href} className="card card-hover block h-full">
          <Media article={article} className="aspect-[16/9] w-full" />
          <div className="p-5">
            <Badges article={article} locale={locale} />
            <p className="kicker mt-2">{article.category_name}</p>
            <h2 className="mt-1 font-display text-xl font-extrabold leading-tight group-hover:text-brand sm:text-2xl">
              {article.title}
            </h2>
            {showSummary && <p className="mt-2 line-clamp-2 text-sm leading-relaxed subtle">{article.summary}</p>}
            <div className="mt-3"><Meta article={article} locale={locale} /></div>
          </div>
        </Link>
      </article>
    );
  }

  return (
    <article className="group">
      <Link href={href} className="card card-hover flex h-full flex-col">
        <Media article={article} className="aspect-[16/10] w-full" />
        <div className="flex flex-1 flex-col p-4">
          <Badges article={article} locale={locale} />
          {article.category_name && <p className="kicker mt-2">{article.category_name}</p>}
          <h3 className="mt-1 text-[17px] font-bold leading-snug group-hover:text-brand">{article.title}</h3>
          {showSummary && <p className="mt-2 line-clamp-2 text-[13px] leading-relaxed subtle">{article.summary}</p>}
          <div className="mt-auto pt-3"><Meta article={article} locale={locale} /></div>
        </div>
      </Link>
    </article>
  );
}

export function VideoCard({ article, locale }: { article: ArticleCardType; locale: Locale }) {
  return (
    <a
      href={article.source_url ?? "#"}
      target="_blank"
      rel="noopener noreferrer nofollow"
      className="card card-hover group block"
    >
      <div className="relative">
        <Media article={article} className="aspect-video w-full" />
        <span className="absolute inset-0 flex items-center justify-center">
          <span className="flex h-12 w-12 items-center justify-center rounded-full bg-brand text-white shadow-glow transition group-hover:scale-110">
            <IconPlay size={26} />
          </span>
        </span>
      </div>
      <div className="p-4">
        <p className="kicker">{t(locale, "home.video")}</p>
        <h3 className="mt-1 line-clamp-2 text-sm font-bold leading-snug group-hover:text-brand">{article.title}</h3>
        <p className="mt-1.5 text-[11px] subtle">
          {article.source_name} · {formatNumber(article.view_count, locale)} {t(locale, "article.views")}
        </p>
      </div>
    </a>
  );
}

export function CategoryPill({ article, locale }: { article: ArticleCardType; locale: Locale }) {
  if (!article.category_slug) return null;
  return (
    <Link
      href={categoryPath(locale, article.category_slug)}
      className="inline-flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-brand"
    >
      <CategoryIcon name={article.category_icon ?? "dot"} size={14} />
      {article.category_name}
    </Link>
  );
}
