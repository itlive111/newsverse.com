"use client";

import { useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import Link from "next/link";
import type { Locale } from "@/i18n";
import { t, localeFlags, locales } from "@/i18n";
import { IconMenu, IconClose, IconUser, IconBookmark, IconShield } from "@/components/icons";
import { BrandLogo } from "@/components/brand-logo";
import { SearchBox } from "@/components/search-box";
import { ThemeToggle } from "@/components/theme-toggle";

type NavCategory = { slug: string; name: string };

export function MobileMenu({
  locale,
  categories,
  signedIn,
  isStaff,
  displayName,
}: {
  locale: Locale;
  categories: NavCategory[];
  signedIn: boolean;
  isStaff: boolean;
  displayName: string | null;
}) {
  const [open, setOpen] = useState(false);
  const pathname = usePathname() || "";
  const router = useRouter();

  function switchLocale(target: Locale) {
    const parts = pathname.split("/");
    parts[1] = target;
    document.cookie = `nv_locale=${target};path=/;max-age=31536000;samesite=lax`;
    setOpen(false);
    router.push(parts.join("/") || `/${target}`);
  }

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    setOpen(false);
    router.push(`/${locale}`);
    router.refresh();
  }

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        aria-label={t(locale, "nav.menu")}
        className="flex h-9 w-9 items-center justify-center rounded-full border lg:hidden"
        style={{ borderColor: "var(--line)" }}
      >
        <IconMenu size={19} />
      </button>
      {open && (
        <div className="fixed inset-0 z-[60] flex flex-col overflow-y-auto bg-[color:var(--bg)] lg:hidden">
          <div className="flex items-center justify-between border-b px-4 py-3" style={{ borderColor: "var(--line)" }}>
            <span onClick={() => setOpen(false)}>
              <BrandLogo href={`/${locale}`} size="sm" />
            </span>
            <button
              type="button"
              onClick={() => setOpen(false)}
              aria-label={t(locale, "common.close")}
              className="flex h-9 w-9 items-center justify-center rounded-full border"
              style={{ borderColor: "var(--line)" }}
            >
              <IconClose size={19} />
            </button>
          </div>
          <div className="space-y-5 p-4">
            <SearchBox locale={locale} placeholder={t(locale, "search.placeholder")} label={t(locale, "nav.search")} />
            <div className="grid grid-cols-2 gap-2">
              <Link href={`/${locale}`} onClick={() => setOpen(false)} className="surface rounded-xl px-3 py-2.5 text-sm font-semibold">
                {t(locale, "nav.home")}
              </Link>
              <Link href={`/${locale}/trending`} onClick={() => setOpen(false)} className="surface rounded-xl px-3 py-2.5 text-sm font-semibold">
                {t(locale, "nav.trending")}
              </Link>
            </div>
            <div>
              <p className="label">{t(locale, "nav.categories")}</p>
              <div className="grid grid-cols-2 gap-x-3 gap-y-1.5">
                {categories.map((c) => (
                  <Link
                    key={c.slug}
                    href={`/${locale}/category/${c.slug}`}
                    onClick={() => setOpen(false)}
                    className="truncate py-1.5 text-sm hover:text-brand"
                  >
                    {c.name}
                  </Link>
                ))}
              </div>
            </div>
            <div>
              <p className="label">{t(locale, "nav.language")}</p>
              <div className="flex gap-2">
                {locales.map((l) => (
                  <button
                    key={l}
                    type="button"
                    onClick={() => switchLocale(l)}
                    className={`flex-1 rounded-xl border px-2 py-2 text-xs font-bold ${l === locale ? "border-brand text-brand" : ""}`}
                    style={{ borderColor: l === locale ? "#FF1538" : "var(--line)" }}
                  >
                    {localeFlags[l]} {l.toUpperCase()}
                  </button>
                ))}
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm subtle">{t(locale, "nav.theme")}</span>
              <ThemeToggle label={t(locale, "nav.theme")} />
            </div>
            <div className="space-y-2 border-t pt-4" style={{ borderColor: "var(--line)" }}>
              {signedIn ? (
                <>
                  <Link href={`/${locale}/account`} onClick={() => setOpen(false)} className="flex items-center gap-2 py-2 text-sm font-semibold">
                    <IconUser size={17} /> {displayName ?? t(locale, "nav.account")}
                  </Link>
                  <Link href={`/${locale}/saved`} onClick={() => setOpen(false)} className="flex items-center gap-2 py-2 text-sm font-semibold">
                    <IconBookmark size={17} /> {t(locale, "nav.bookmarks")}
                  </Link>
                  {isStaff && (
                    <Link href={`/${locale}/admin`} onClick={() => setOpen(false)} className="flex items-center gap-2 py-2 text-sm font-semibold text-brand">
                      <IconShield size={17} /> {t(locale, "nav.admin")}
                    </Link>
                  )}
                  <button type="button" onClick={logout} className="btn-ghost mt-2 w-full">
                    {t(locale, "nav.logout")}
                  </button>
                </>
              ) : (
                <>
                  <Link href={`/${locale}/login`} onClick={() => setOpen(false)} className="btn-primary w-full">
                    {t(locale, "nav.login")}
                  </Link>
                  <Link href={`/${locale}/register`} onClick={() => setOpen(false)} className="btn-ghost w-full">
                    {t(locale, "nav.register")}
                  </Link>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
