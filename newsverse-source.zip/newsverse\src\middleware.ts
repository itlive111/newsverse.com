import { NextResponse, type NextRequest } from "next/server";

const LOCALES = ["uz", "en", "ru"];
const PUBLIC_FILES = [
  "/robots.txt",
  "/sitemap.xml",
  "/feed.xml",
  "/manifest.webmanifest",
  "/brand/newsverse-logo.png",
  "/brand/newsverse-logo-sm.png",
  "/brand/icon-192.png",
  "/brand/icon-512.png",
  "/brand/og.png",
  "/favicon.ico",
  "/sw.js",
];

/** Redirects unprefixed paths to a locale, honouring the saved preference. */
export function middleware(request: NextRequest) {
  const { pathname, search } = request.nextUrl;
  if (
    pathname.startsWith("/api") ||
    pathname.startsWith("/_next") ||
    pathname.startsWith("/demo") ||
    PUBLIC_FILES.includes(pathname) ||
    /\.(png|jpe?g|svg|webp|ico|txt|xml|webmanifest|json|js|css|woff2?)$/i.test(pathname)
  ) {
    return NextResponse.next();
  }
  if (/^\/(uz|en|ru)(\/|$)/.test(pathname)) {
    // Cheap early bounce for anonymous admin visits. The session itself is
    // still validated against the database in every admin layout, page and API.
    const admin = /^\/(uz|en|ru)\/admin(\/|$)/.exec(pathname);
    if (admin && !request.cookies.get("nv_session")) {
      const login = request.nextUrl.clone();
      login.pathname = `/${admin[1]}/login`;
      login.search = `?next=${encodeURIComponent(pathname)}`;
      return NextResponse.redirect(login, 307);
    }
    return NextResponse.next();
  }

  const cookie = request.cookies.get("nv_locale")?.value;
  const header = request.headers.get("accept-language") ?? "";
  const preferred = header.split(",").map((part) => part.split(";")[0]!.trim().slice(0, 2).toLowerCase());
  const locale =
    (cookie && LOCALES.includes(cookie) && cookie) ||
    preferred.find((p) => LOCALES.includes(p)) ||
    "uz";

  const url = request.nextUrl.clone();
  url.pathname = `/${locale}${pathname === "/" ? "" : pathname}`;
  url.search = search;
  return NextResponse.redirect(url, 307);
}

export const config = {
  matcher: ["/((?!api|_next/static|_next/image|favicon.ico).*)"],
};
