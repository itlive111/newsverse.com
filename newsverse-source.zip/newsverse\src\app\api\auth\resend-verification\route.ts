import { get } from "@/server/db";
import { audit, clientIpFromHeaders, rateLimit, requireUser } from "@/server/auth";
import { guardOrigin } from "@/server/adminGuard";
import { json, fail, handleError } from "@/server/http";
import { issueToken, logVerificationLink, verificationLink } from "@/server/lib/verification";

export async function POST(request: Request) {
  try {
    guardOrigin(request);
    const user = await requireUser();
    if (user.email_verified) return json({ ok: true, alreadyVerified: true });

    const ip = clientIpFromHeaders(request.headers) ?? "unknown";
    if (!rateLimit(`verify:${user.id}:${ip}`, 4, 60 * 60 * 1000)) return fail("rate_limited", 429);

    const row = get<{ email: string }>("SELECT email FROM users WHERE id = ?", user.id);
    if (!row) return fail("unauthorized", 401);
    const token = issueToken(user.id, "verify");
    logVerificationLink(row.email, verificationLink(token));
    audit({ actor: user, action: "auth.verification_resent", entity: "user", entityId: user.id });
    return json({ ok: true });
  } catch (err) {
    return handleError(err);
  }
}
