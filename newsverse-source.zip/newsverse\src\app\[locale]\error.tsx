"use client";

import Link from "next/link";
import { useEffect } from "react";
import { defaultLocale, t } from "@/i18n";

export default function ErrorPage({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  const locale = defaultLocale;
  useEffect(() => {
    console.error("[newsverse] page error:", error.message);
  }, [error]);

  return (
    <div className="container-nv flex flex-col items-center justify-center py-24 text-center">
      <h1 className="font-display text-3xl font-extrabold">{t(locale, "state.errorTitle")}</h1>
      <p className="mt-2 max-w-md text-sm subtle">{t(locale, "state.errorBody")}</p>
      {error.digest && <p className="mt-2 text-[10px] subtle">ref: {error.digest}</p>}
      <div className="mt-6 flex gap-2">
        <button type="button" onClick={reset} className="btn-primary">{t(locale, "common.retry")}</button>
        <Link href={`/${locale}`} className="btn-ghost">{t(locale, "state.backHome")}</Link>
      </div>
    </div>
  );
}
