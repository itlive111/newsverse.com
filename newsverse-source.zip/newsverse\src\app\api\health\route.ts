import { get } from "@/server/db";
import { ensureBootstrapped } from "@/server/db/bootstrap";
import { aiStatus } from "@/server/ingest/ai";
import { schedulerInfo } from "@/server/ingest/jobs";
import { json } from "@/server/http";

export async function GET() {
  try {
    ensureBootstrapped();
    const articles = get<{ c: number }>("SELECT COUNT(*) AS c FROM articles WHERE status = 'published'")?.c ?? 0;
    const migrations = get<{ c: number }>("SELECT COUNT(*) AS c FROM _migrations")?.c ?? 0;
    return json({
      ok: true,
      time: new Date().toISOString(),
      database: "up",
      migrations,
      publishedArticles: articles,
      ai: aiStatus(),
      scheduler: schedulerInfo(),
    });
  } catch (err) {
    return json({ ok: false, error: (err as Error).message }, 500);
  }
}
