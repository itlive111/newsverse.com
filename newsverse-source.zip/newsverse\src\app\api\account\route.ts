import { run, nowIso, get } from "@/server/db";
import { requireUser } from "@/server/auth";
import { guardOrigin } from "@/server/adminGuard";
import { json, fail, parseBody, handleError } from "@/server/http";
import { accountSchema } from "@/lib/validation";

export async function PATCH(request: Request) {
  try {
    guardOrigin(request);
    const user = await requireUser();
    const input = await parseBody(request, accountSchema);

    if (input.username && input.username !== user.username) {
      const taken = get("SELECT id FROM users WHERE username = ? COLLATE NOCASE AND id <> ?", input.username, user.id);
      if (taken) return fail("username_taken", 409);
    }

    const interests = input.interests ? JSON.stringify(input.interests) : undefined;
    const prefs =
      input.notify_email === undefined && input.notify_breaking === undefined && input.notify_comments === undefined
        ? undefined
        : JSON.stringify({
            email: input.notify_email ?? true,
            breaking: input.notify_breaking ?? false,
            comments: input.notify_comments ?? true,
          });

    run(
      `UPDATE users SET name = COALESCE(?, name), username = COALESCE(?, username), locale = COALESCE(?, locale),
         bio = COALESCE(?, bio), avatar_url = COALESCE(?, avatar_url), interests = COALESCE(?, interests),
         notification_prefs = COALESCE(?, notification_prefs), updated_at = ? WHERE id = ?`,
      input.name ?? null,
      input.username ?? null,
      input.locale ?? null,
      input.bio ?? null,
      input.avatar_url ?? null,
      interests ?? null,
      prefs ?? null,
      nowIso(),
      user.id,
    );

    const updated = get(
      "SELECT name, username, locale, bio, avatar_url, interests, notification_prefs, email, email_verified FROM users WHERE id = ?",
      user.id,
    );
    return json({ ok: true, user: updated });
  } catch (err) {
    return handleError(err);
  }
}
