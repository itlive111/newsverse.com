import { getDb } from "./index";
import { seedIfEmpty } from "./seed";

let bootstrapped = false;

/**
 * Ensures migrations have run and the base taxonomy/settings/sources exist.
 * Called by the server instrumentation and by data access on first use, so a
 * fresh clone works with `npm run dev` alone.
 */
export function ensureBootstrapped(): void {
  if (bootstrapped) return;
  getDb();
  seedIfEmpty();
  bootstrapped = true;
}
