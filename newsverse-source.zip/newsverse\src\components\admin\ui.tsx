import type { ReactNode } from "react";

export function StatCard({
  label,
  value,
  hint,
  accent,
}: {
  label: string;
  value: string | number;
  hint?: string;
  accent?: boolean;
}) {
  return (
    <div className="card p-4">
      <p className="text-[10px] font-bold uppercase tracking-wider subtle">{label}</p>
      <p className={`mt-1 font-display text-2xl font-black ${accent ? "text-brand" : ""}`}>{value}</p>
      {hint && <p className="mt-0.5 text-[10px] subtle">{hint}</p>}
    </div>
  );
}

const STATUS_STYLES: Record<string, string> = {
  published: "bg-emerald-500/10 text-emerald-400",
  pending: "bg-amber-500/10 text-amber-300",
  scheduled: "bg-sky-500/10 text-sky-300",
  draft: "bg-white/5 text-[color:var(--muted)]",
  archived: "bg-white/5 text-[color:var(--muted)]",
  failed: "bg-brand/10 text-brand",
  succeeded: "bg-emerald-500/10 text-emerald-400",
  queued: "bg-sky-500/10 text-sky-300",
  running: "bg-amber-500/10 text-amber-300",
  approved: "bg-emerald-500/10 text-emerald-400",
  rejected: "bg-brand/10 text-brand",
  active: "bg-emerald-500/10 text-emerald-400",
  suspended: "bg-brand/10 text-brand",
  open: "bg-amber-500/10 text-amber-300",
  resolved: "bg-emerald-500/10 text-emerald-400",
};

export function StatusBadge({ status }: { status: string }) {
  return (
    <span className={`inline-flex rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide ${STATUS_STYLES[status] ?? "bg-white/5"}`}>
      {status}
    </span>
  );
}

export function AdminSection({
  title,
  action,
  children,
  className = "",
}: {
  title?: string;
  action?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <section className={`card p-5 ${className}`}>
      {(title || action) && (
        <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
          {title && <h2 className="text-sm font-extrabold uppercase tracking-wider">{title}</h2>}
          {action}
        </div>
      )}
      {children}
    </section>
  );
}

export function Bars({
  data,
  label,
}: {
  data: { day: string; views: number; articles: number }[];
  label: string;
}) {
  const max = Math.max(1, ...data.map((d) => d.views));
  return (
    <div>
      <div className="flex h-40 items-end gap-1.5" role="img" aria-label={label}>
        {data.map((d) => (
          <div key={d.day} className="group relative flex-1">
            <div
              className="w-full rounded-t bg-brand/70 transition group-hover:bg-brand"
              style={{ height: `${Math.max(2, (d.views / max) * 150)}px` }}
              title={`${d.day}: ${d.views} views · ${d.articles} articles`}
            />
          </div>
        ))}
      </div>
      <div className="mt-2 flex justify-between text-[10px] subtle">
        <span>{data[0]?.day}</span>
        <span>{data[data.length - 1]?.day}</span>
      </div>
    </div>
  );
}

export function EmptyRow({ colSpan, text }: { colSpan: number; text: string }) {
  return (
    <tr>
      <td colSpan={colSpan} className="px-3 py-8 text-center text-xs subtle">{text}</td>
    </tr>
  );
}

export function Th({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <th className={`px-3 py-2 text-left text-[10px] font-bold uppercase tracking-wider subtle ${className}`}>{children}</th>;
}

export function Td({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <td className={`px-3 py-2.5 align-top ${className}`}>{children}</td>;
}
