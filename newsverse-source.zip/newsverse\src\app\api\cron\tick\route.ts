import { schedulerTick, schedulerInfo } from "@/server/ingest/jobs";
import { json, fail, handleError } from "@/server/http";

/**
 * External scheduler entry point (e.g. GitHub Actions, cron-job.org, Cloud
 * Scheduler) for hosts that cannot keep a Node process alive. Requires
 * CRON_SECRET; the endpoint is never open by default.
 */
async function handle(request: Request) {
  try {
    const secret = process.env.CRON_SECRET;
    if (!secret) return fail("CRON_SECRET is not configured", 503);
    const url = new URL(request.url);
    const provided =
      request.headers.get("authorization")?.replace(/^Bearer\s+/i, "") ??
      url.searchParams.get("secret") ?? "";
    if (provided !== secret) return fail("Unauthorized", 401);
    const result = await schedulerTick();
    return json({ ok: true, ...result, scheduler: schedulerInfo() });
  } catch (err) {
    return handleError(err);
  }
}

export async function GET(request: Request) {
  return handle(request);
}

export async function POST(request: Request) {
  return handle(request);
}
