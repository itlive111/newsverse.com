"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { CategoryIcon } from "@/components/icons";
import type { Locale } from "@/i18n";

type Item = { slug: string; name: string; icon: string; color: string | null };

export function CategoryRail({ locale, categories, allLabel }: { locale: Locale; categories: Item[]; allLabel: string }) {
  const pathname = usePathname() || "";
  return (
    <nav aria-label={allLabel} className="border-b" style={{ borderColor: "var(--line)" }}>
      <div className="container-nv">
        <ul className="no-scrollbar flex items-center gap-0.5 overflow-x-auto">
          <li>
            <Link
              href={`/${locale}/latest`}
              className={`flex shrink-0 items-center gap-1.5 border-b-2 px-3 py-2.5 text-[12px] font-bold uppercase tracking-wide transition ${
                pathname.includes("/latest") ? "border-brand text-brand" : "border-transparent hover:text-brand"
              }`}
            >
              {allLabel}
            </Link>
          </li>
          {categories.map((c) => {
            const active = pathname.includes(`/category/${c.slug}`);
            return (
              <li key={c.slug}>
                <Link
                  href={`/${locale}/category/${c.slug}`}
                  className={`flex shrink-0 items-center gap-1.5 whitespace-nowrap border-b-2 px-3 py-2.5 text-[12px] font-semibold transition ${
                    active ? "border-brand text-brand" : "border-transparent hover:text-brand"
                  }`}
                >
                  <CategoryIcon name={c.icon} size={14} style={c.color ? { color: c.color } : undefined} />
                  {c.name}
                </Link>
              </li>
            );
          })}
        </ul>
      </div>
    </nav>
  );
}
