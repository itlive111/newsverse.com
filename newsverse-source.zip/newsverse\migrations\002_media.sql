-- Media additions: video URLs supplied by publisher feeds.
ALTER TABLE articles ADD COLUMN video_url TEXT;
CREATE INDEX IF NOT EXISTS idx_articles_video ON articles (video_url);
