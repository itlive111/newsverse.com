import type { Metadata } from "next";
import Link from "next/link";
import { resolveLocale, t, formatNumber, type Locale } from "@/i18n";
import { getMostRead, getTrending, listTagsWithCounts } from "@/server/repo/content";
import { ArticleCard } from "@/components/article-card";
import { EmptyState, Panel, SectionHeader } from "@/components/layout-parts";

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const locale = resolveLocale((await params).locale);
  return {
    title: t(locale, "nav.trending"),
    description: t(locale, "meta.homeDesc"),
    alternates: { canonical: `/${locale}/trending` },
  };
}

export default async function TrendingPage({ params }: { params: Promise<{ locale: string }> }) {
  const locale = resolveLocale((await params).locale) as Locale;
  const trending = getTrending(locale, 8);
  const day = getMostRead(locale, "day", 5);
  const week = getMostRead(locale, "week", 5);
  const month = getMostRead(locale, "month", 5);
  const tags = listTagsWithCounts(16);

  return (
    <div className="container-nv py-8">
      <SectionHeader title={t(locale, "home.trending")} hint={t(locale, "home.personalizedHint")} />
      {trending.length === 0 ? (
        <EmptyState title={t(locale, "state.emptyTitle")} body={t(locale, "state.emptyBody")} actionHref={`/${locale}/latest`} actionLabel={t(locale, "home.latest")} />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {trending.map((article, index) => (
            <div key={article.id} className="relative">
              <span className="pointer-events-none absolute -left-1 -top-3 z-10 font-display text-4xl font-black text-brand/30">
                {index + 1}
              </span>
              <ArticleCard article={article} locale={locale} />
            </div>
          ))}
        </div>
      )}

      <div className="mt-8 grid gap-4 md:grid-cols-3">
        <Panel title={`${t(locale, "home.mostRead")} · ${t(locale, "home.day")}`}>
          <ol className="space-y-2.5">
            {day.map((a, i) => (
              <li key={a.id} className="flex gap-2 text-sm">
                <span className="font-bold text-brand">{i + 1}</span>
                <Link href={`/${locale}/news/${a.slug}`} className="line-clamp-2 hover:text-brand">{a.title}</Link>
              </li>
            ))}
          </ol>
        </Panel>
        <Panel title={`${t(locale, "home.mostRead")} · ${t(locale, "home.week")}`}>
          <ol className="space-y-2.5">
            {week.map((a, i) => (
              <li key={a.id} className="flex gap-2 text-sm">
                <span className="font-bold text-brand">{i + 1}</span>
                <Link href={`/${locale}/news/${a.slug}`} className="line-clamp-2 hover:text-brand">{a.title}</Link>
              </li>
            ))}
          </ol>
        </Panel>
        <Panel title={`${t(locale, "home.mostRead")} · ${t(locale, "home.month")}`}>
          <ol className="space-y-2.5">
            {month.map((a, i) => (
              <li key={a.id} className="flex gap-2 text-sm">
                <span className="font-bold text-brand">{i + 1}</span>
                <Link href={`/${locale}/news/${a.slug}`} className="line-clamp-2 hover:text-brand">{a.title}</Link>
              </li>
            ))}
          </ol>
        </Panel>
      </div>

      <div className="mt-8">
        <SectionHeader title={t(locale, "home.tags")} />
        <div className="flex flex-wrap gap-2">
          {tags.map((tag) => (
            <Link key={tag.slug} href={`/${locale}/search?tag=${tag.slug}`} className="chip hover:border-brand hover:text-brand">
              #{tag.name} <span className="opacity-60">{formatNumber(tag.count, locale)}</span>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
