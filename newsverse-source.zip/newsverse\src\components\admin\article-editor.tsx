"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { locales, localeNames, t, type Locale } from "@/i18n";

export type EditorTranslation = {
  locale: Locale;
  title: string;
  subtitle: string;
  summary: string;
  content: string;
};

export type EditorInitial = {
  id?: string;
  status: string;
  scheduledFor: string;
  categorySlug: string;
  imageUrl: string;
  imageCredit: string;
  sourceName: string;
  sourceUrl: string;
  isBreaking: boolean;
  isOpinion: boolean;
  isSponsored: boolean;
  tags: string;
  translations: EditorTranslation[];
};

export function ArticleEditor({
  locale,
  categories,
  initial,
}: {
  locale: Locale;
  categories: { slug: string; name: string }[];
  initial?: EditorInitial;
}) {
  const [form, setForm] = useState<EditorInitial>(
    initial ?? {
      status: "draft",
      scheduledFor: "",
      categorySlug: categories[0]?.slug ?? "world",
      imageUrl: "",
      imageCredit: "",
      sourceName: "",
      sourceUrl: "",
      isBreaking: false,
      isOpinion: false,
      isSponsored: false,
      tags: "",
      translations: locales.map((l) => ({ locale: l, title: "", subtitle: "", summary: "", content: "" })),
    },
  );
  const [tab, setTab] = useState<Locale>(locale);
  const [state, setState] = useState<"idle" | "busy" | "ok" | "error">("idle");
  const [error, setError] = useState("");
  const router = useRouter();
  const active = form.translations.find((tr) => tr.locale === tab) ?? form.translations[0];

  function patch(partial: Partial<EditorInitial>) {
    setForm((current) => ({ ...current, ...partial }));
  }

  function patchTranslation(localeKey: Locale, partial: Partial<EditorTranslation>) {
    setForm((current) => ({
      ...current,
      translations: current.translations.map((tr) => (tr.locale === localeKey ? { ...tr, ...partial } : tr)),
    }));
  }

  async function save() {
    const filled = form.translations.filter((tr) => tr.title.trim().length >= 3 && tr.summary.trim().length >= 10);
    if (!filled.length) {
      setError(t(locale, "admin.noPermission"));
      return;
    }
    setState("busy");
    setError("");
    const payload = {
      categorySlug: form.categorySlug,
      status: form.status,
      scheduledFor: form.status === "scheduled" && form.scheduledFor ? new Date(form.scheduledFor).toISOString() : null,
      imageUrl: form.imageUrl,
      imageCredit: form.imageCredit,
      sourceName: form.sourceName,
      sourceUrl: form.sourceUrl,
      isBreaking: form.isBreaking,
      isOpinion: form.isOpinion,
      isSponsored: form.isSponsored,
      tags: form.tags,
      translations: filled,
    };
    const endpoint = form.id ? `/api/admin/articles/${form.id}` : "/api/admin/articles";
    const res = await fetch(endpoint, {
      method: form.id ? "PATCH" : "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(payload),
    }).catch(() => null);
    if (!res?.ok) {
      const data = (await res?.json().catch(() => ({}))) as { error?: string; issues?: { path: string; message: string }[] };
      setError(data?.issues?.map((i) => `${i.path}: ${i.message}`).join("; ") || data?.error || "error");
      setState("error");
      return;
    }
    const data = (await res.json()) as { id?: string };
    setState("ok");
    if (!form.id && data.id) {
      router.push(`/${locale}/admin/articles/${data.id}`);
    }
    router.refresh();
  }

  return (
    <div className="grid gap-5 lg:grid-cols-[1fr_300px]">
      <div className="card p-5">
        <div className="mb-4 flex flex-wrap gap-1">
          {locales.map((l) => {
            const tr = form.translations.find((x) => x.locale === l);
            const filled = (tr?.title ?? "").trim().length > 2;
            return (
              <button
                key={l}
                type="button"
                onClick={() => setTab(l)}
                className={`rounded-full border px-3 py-1.5 text-[11px] font-bold uppercase ${tab === l ? "border-brand text-brand" : ""}`}
                style={{ borderColor: tab === l ? "#FF1538" : "var(--line)" }}
              >
                {l.toUpperCase()} {filled ? "•" : ""}
              </button>
            );
          })}
        </div>
        <div className="space-y-3">
          <div>
            <label className="label" htmlFor="ed-title">{t(locale, "auth.name")} ({localeNames[active.locale]}) *</label>
            <input id="ed-title" value={active.title} onChange={(e) => patchTranslation(active.locale, { title: e.target.value })} className="input" maxLength={200} />
          </div>
          <div>
            <label className="label" htmlFor="ed-subtitle">Subtitle</label>
            <input id="ed-subtitle" value={active.subtitle} onChange={(e) => patchTranslation(active.locale, { subtitle: e.target.value })} className="input" maxLength={300} />
          </div>
          <div>
            <label className="label" htmlFor="ed-summary">{t(locale, "common.readMore")} — summary *</label>
            <textarea id="ed-summary" rows={3} value={active.summary} onChange={(e) => patchTranslation(active.locale, { summary: e.target.value })} className="input" maxLength={600} />
          </div>
          <div>
            <label className="label" htmlFor="ed-content">Content</label>
            <textarea id="ed-content" rows={12} value={active.content} onChange={(e) => patchTranslation(active.locale, { content: e.target.value })} className="input font-mono text-xs" placeholder="Paragraphs separated by a blank line" />
          </div>
          <p className="text-[11px] subtle">
            {t(locale, "article.sourceNotice")} — {t(locale, "article.aiNotice")}
          </p>
        </div>
      </div>

      <div className="space-y-4">
        <div className="card space-y-3 p-4">
          <div>
            <label className="label" htmlFor="ed-status">{t(locale, "admin.status")}</label>
            <select id="ed-status" value={form.status} onChange={(e) => patch({ status: e.target.value })} className="input">
              <option value="draft">draft</option>
              <option value="pending">pending</option>
              <option value="scheduled">scheduled</option>
              <option value="published">published</option>
              <option value="archived">archived</option>
            </select>
          </div>
          {form.status === "scheduled" && (
            <div>
              <label className="label" htmlFor="ed-sched">Scheduled for (UTC)</label>
              <input id="ed-sched" type="datetime-local" value={form.scheduledFor} onChange={(e) => patch({ scheduledFor: e.target.value })} className="input" />
            </div>
          )}
          <div>
            <label className="label" htmlFor="ed-category">{t(locale, "search.category")}</label>
            <select id="ed-category" value={form.categorySlug} onChange={(e) => patch({ categorySlug: e.target.value })} className="input">
              {categories.map((c) => <option key={c.slug} value={c.slug}>{c.name}</option>)}
            </select>
          </div>
          <div>
            <label className="label" htmlFor="ed-tags">{t(locale, "article.tags")}</label>
            <input id="ed-tags" value={form.tags} onChange={(e) => patch({ tags: e.target.value })} className="input" placeholder="ai, space, economy" />
          </div>
          <div className="space-y-2 pt-1">
            {([
              ["isBreaking", t(locale, "home.breaking")],
              ["isOpinion", t(locale, "article.opinion")],
              ["isSponsored", t(locale, "article.sponsored")],
            ] as const).map(([key, label]) => (
              <label key={key} className="flex items-center gap-2 text-xs">
                <input type="checkbox" checked={form[key]} onChange={(e) => patch({ [key]: e.target.checked } as Partial<EditorInitial>)} />
                {label}
              </label>
            ))}
          </div>
        </div>

        <div className="card space-y-3 p-4">
          <p className="label">Media & attribution</p>
          <input value={form.imageUrl} onChange={(e) => patch({ imageUrl: e.target.value })} className="input" placeholder="Image URL (https://…)" />
          <input value={form.imageCredit} onChange={(e) => patch({ imageCredit: e.target.value })} className="input" placeholder="Image credit" />
          <input value={form.sourceName} onChange={(e) => patch({ sourceName: e.target.value })} className="input" placeholder="Source name" />
          <input value={form.sourceUrl} onChange={(e) => patch({ sourceUrl: e.target.value })} className="input" placeholder="Source URL" />
        </div>

        <div className="card p-4">
          <button type="button" onClick={save} disabled={state === "busy"} className="btn-primary w-full">
            {state === "busy" ? t(locale, "common.loading") : form.id ? t(locale, "common.save") : t(locale, "admin.newArticle")}
          </button>
          {state === "ok" && <p className="mt-2 text-xs text-emerald-400">{t(locale, "admin.saved")}</p>}
          {error && <p className="mt-2 break-words text-[11px] text-brand">{error}</p>}
          {form.id && (
            <Link href={`/${locale}/admin/preview/${form.id}`} className="btn-ghost mt-2 w-full !text-xs">
              {t(locale, "admin.preview")}
            </Link>
          )}
        </div>
      </div>
    </div>
  );
}
