import type { Metadata } from "next";
import Link from "next/link";
import { resolveLocale, t, formatNumber, type Locale } from "@/i18n";
import { countArticles, listArticles, listCategories, listSources, listTagsWithCounts } from "@/server/repo/content";
import { ArticleCard } from "@/components/article-card";
import { SearchBox } from "@/components/search-box";
import { EmptyState, Pagination } from "@/components/layout-parts";

type Props = {
  params: Promise<{ locale: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

const PAGE_SIZE = 12;

function pick(value: string | string[] | undefined): string {
  return Array.isArray(value) ? (value[0] ?? "") : (value ?? "");
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const locale = resolveLocale((await params).locale);
  return {
    title: t(locale, "search.title"),
    description: t(locale, "meta.homeDesc"),
    alternates: { canonical: `/${locale}/search` },
    robots: { index: false, follow: true },
  };
}

export default async function SearchPage({ params, searchParams }: Props) {
  const locale = resolveLocale((await params).locale) as Locale;
  const sp = await searchParams;
  const q = pick(sp.q).trim().slice(0, 100);
  const category = pick(sp.category);
  const source = pick(sp.source);
  const tag = pick(sp.tag);
  const from = pick(sp.from);
  const to = pick(sp.to);
  const lang = pick(sp.lang);
  const sort = pick(sp.sort) || "newest";
  const page = Math.max(1, Number(pick(sp.page)) || 1);

  const opts = {
    locale,
    query: q || undefined,
    categorySlug: category || undefined,
    sourceName: source || undefined,
    tagSlug: tag || undefined,
    from: from ? new Date(from).toISOString() : undefined,
    to: to ? new Date(`${to}T23:59:59.999Z`).toISOString() : undefined,
    contentLocale: lang || undefined,
    limit: PAGE_SIZE,
    offset: (page - 1) * PAGE_SIZE,
  };
  const results = listArticles(opts);
  const total = countArticles(opts);
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const categories = listCategories(locale);
  const sources = listSources();
  const tags = listTagsWithCounts(10);
  const params2 = new URLSearchParams();
  for (const [key, value] of Object.entries({ q, category, source, tag, from, to, lang, sort })) {
    if (value) params2.set(key, value);
  }
  const baseQuery = params2.toString();
  const basePath = `/${locale}/search${baseQuery ? `?${baseQuery}` : ""}`;

  return (
    <div className="container-nv py-8">
      <h1 className="font-display text-3xl font-extrabold tracking-tight">{t(locale, "search.title")}</h1>
      <div className="mt-4">
        <SearchBox locale={locale} placeholder={t(locale, "search.placeholder")} label={t(locale, "search.title")} initial={q} size="lg" />
      </div>

      <form method="get" className="mt-5 grid gap-3 rounded-2xl border p-4 sm:grid-cols-2 lg:grid-cols-6" style={{ borderColor: "var(--line)" }}>
        <input type="hidden" name="q" value={q} />
        <div className="lg:col-span-2">
          <label htmlFor="filter-category" className="label">{t(locale, "search.category")}</label>
          <select id="filter-category" name="category" defaultValue={category} className="input">
            <option value="">{t(locale, "common.all")}</option>
            {categories.map((c) => <option key={c.slug} value={c.slug}>{c.name}</option>)}
          </select>
        </div>
        <div>
          <label htmlFor="filter-source" className="label">{t(locale, "search.source")}</label>
          <select id="filter-source" name="source" defaultValue={source} className="input">
            <option value="">{t(locale, "common.all")}</option>
            {sources.map((s) => <option key={s.id} value={s.name}>{s.name}</option>)}
          </select>
        </div>
        <div>
          <label htmlFor="filter-lang" className="label">{t(locale, "search.language")}</label>
          <select id="filter-lang" name="lang" defaultValue={lang} className="input">
            <option value="">{t(locale, "common.all")}</option>
            <option value="uz">UZ</option>
            <option value="en">EN</option>
            <option value="ru">RU</option>
          </select>
        </div>
        <div>
          <label htmlFor="filter-from" className="label">{t(locale, "search.from")}</label>
          <input id="filter-from" type="date" name="from" defaultValue={from} className="input" />
        </div>
        <div>
          <label htmlFor="filter-to" className="label">{t(locale, "search.to")}</label>
          <input id="filter-to" type="date" name="to" defaultValue={to} className="input" />
        </div>
        {tag && <input type="hidden" name="tag" value={tag} />}
        <div>
          <label htmlFor="filter-sort" className="label">{t(locale, "common.filter")}</label>
          <select id="filter-sort" name="sort" defaultValue={sort} className="input">
            <option value="newest">{t(locale, "search.sortNewest")}</option>
            <option value="relevant">{t(locale, "search.sortRelevant")}</option>
          </select>
        </div>
        <div className="flex items-end gap-2 lg:col-span-2">
          <button type="submit" className="btn-primary w-full">{t(locale, "common.filter")}</button>
          <Link href={`/${locale}/search`} className="btn-ghost whitespace-nowrap">{t(locale, "common.cancel")}</Link>
        </div>
      </form>

      <div className="mt-6 flex flex-wrap items-center justify-between gap-2">
        <p className="text-sm subtle">
          {q ? <span>“{q}” — </span> : null}
          {formatNumber(total, locale)} {t(locale, "common.results")}
          {tag && <span className="ml-1">· #{tag}</span>}
        </p>
        <div className="flex flex-wrap gap-1.5">
          {tags.slice(0, 6).map((tagItem) => (
            <Link key={tagItem.slug} href={`/${locale}/search?tag=${tagItem.slug}`} className="chip hover:border-brand hover:text-brand">
              #{tagItem.name}
            </Link>
          ))}
        </div>
      </div>

      {results.length === 0 ? (
        <div className="mt-6">
          <EmptyState title={t(locale, "common.noResults")} body={t(locale, "search.empty")} actionHref={`/${locale}/latest`} actionLabel={t(locale, "home.latest")} />
        </div>
      ) : (
        <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {results.map((article) => <ArticleCard key={article.id} article={article} locale={locale} />)}
        </div>
      )}

      <Pagination
        basePath={basePath}
        page={page}
        totalPages={totalPages}
        prevLabel={t(locale, "common.prev")}
        nextLabel={t(locale, "common.next")}
      />
    </div>
  );
}
