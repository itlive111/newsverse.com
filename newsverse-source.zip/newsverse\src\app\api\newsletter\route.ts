import { getCurrentUser, clientIpFromHeaders, rateLimit } from "@/server/auth";
import { guardOrigin } from "@/server/adminGuard";
import { json, parseBody, handleError } from "@/server/http";
import { newsletterSchema } from "@/lib/validation";
import { subscribeNewsletter } from "@/server/repo/content";
import { getBoolSetting } from "@/server/repo/settings";

export async function POST(request: Request) {
  try {
    guardOrigin(request);
    if (!getBoolSetting("newsletter_enabled", true)) return json({ ok: false, error: "disabled" }, 403);
    const ip = clientIpFromHeaders(request.headers) ?? "unknown";
    if (!rateLimit(`newsletter:${ip}`, 6, 60 * 60 * 1000)) return json({ ok: false }, 429);
    const input = await parseBody(request, newsletterSchema);
    const user = await getCurrentUser();
    const created = subscribeNewsletter(input.email, input.locale, user?.id ?? null);
    return json({ ok: true, created });
  } catch (err) {
    return handleError(err);
  }
}
