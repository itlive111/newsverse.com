"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { t, type Locale } from "@/i18n";

export function MergeForm({ locale, articleId }: { locale: Locale; articleId: string }) {
  const [duplicateId, setDuplicateId] = useState("");
  const [state, setState] = useState<"idle" | "busy" | "error">("idle");
  const [error, setError] = useState("");
  const router = useRouter();

  async function submit() {
    setState("busy");
    setError("");
    const res = await fetch(`/api/admin/articles/${articleId}/merge`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ duplicateId: duplicateId.trim() }),
    }).catch(() => null);
    if (!res?.ok) {
      const data = (await res?.json().catch(() => ({}))) as { error?: string };
      setError(data?.error ?? "error");
      setState("error");
      return;
    }
    setDuplicateId("");
    setState("idle");
    router.refresh();
  }

  return (
    <div className="space-y-2">
      <label className="label" htmlFor="merge-id">{t(locale, "admin.merge")} — duplicate article ID</label>
      <div className="flex gap-2">
        <input id="merge-id" value={duplicateId} onChange={(e) => setDuplicateId(e.target.value)} className="input !py-1.5 !text-xs" placeholder="uuid" />
        <button type="button" onClick={submit} disabled={state === "busy" || duplicateId.trim().length < 8} className="btn-ghost shrink-0 !py-1.5 !text-xs">
          {t(locale, "admin.merge")}
        </button>
      </div>
      {error && <p className="text-[11px] text-brand">{error}</p>}
    </div>
  );
}
