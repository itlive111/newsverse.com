/**
 * Idempotently applies the configured feed catalogue to an existing database:
 * adds missing sources, normalizes intervals to hourly and raises the per-run
 * item cap. Safe to re-run; it never deletes existing sources or articles.
 */
import crypto from "node:crypto";
import { all, get, run, nowIso } from "../src/server/db";
import { ensureBootstrapped } from "../src/server/db/bootstrap";
import { SOURCE_SEED } from "../src/server/db/seed";
import { setSetting } from "../src/server/repo/settings";

ensureBootstrapped();
const now = nowIso();
let added = 0;
let updated = 0;

for (const source of SOURCE_SEED) {
  const existing = get<{ id: string }>("SELECT id FROM sources WHERE feed_url = ?", source.feed);
  if (existing) {
    run(
      `UPDATE sources SET name = ?, site_url = ?, category_slug = ?, locale = ?, interval_minutes = ?,
         trust = ?, moderation = ?, enabled = 1, consecutive_failures = 0, last_error = NULL, updated_at = ?
       WHERE id = ?`,
      source.name, source.site, source.category, source.locale, source.interval,
      source.trust, source.moderation, now, existing.id,
    );
    updated += 1;
  } else {
    run(
      `INSERT INTO sources (id, name, type, feed_url, site_url, category_slug, locale, enabled, interval_minutes,
         trust, moderation, consecutive_failures, total_items, created_at, updated_at)
       VALUES (?,?,?,?,?,?,?,1,?,?,?,0,0,?,?)`,
      crypto.randomUUID(), source.name, "rss", source.feed, source.site,
      source.category, source.locale, source.interval, source.trust, source.moderation, now, now,
    );
    added += 1;
  }
}

setSetting("ingest_max_items_per_run", "50");
setSetting("ingest_interval_minutes", "60");

const total = all<{ c: number }>("SELECT COUNT(*) AS c FROM sources WHERE enabled = 1")[0]?.c ?? 0;
console.log(`Feeds: ${added} added, ${updated} updated, ${total} enabled sources.`);
console.log("Cadence: every source now collects hourly; per-run cap 50 items.");
