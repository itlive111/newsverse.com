import { adminGate } from "@/server/adminPage";
import { notFound } from "next/navigation";
import { isLocale, t } from "@/i18n";
import { listCategoriesAdmin } from "@/server/repo/admin";
import { CategoryForm } from "@/components/admin/category-form";
import { AdminSection, StatusBadge, Td, Th } from "@/components/admin/ui";

export const dynamic = "force-dynamic";

function names(json: string): Record<string, string> {
  try {
    return JSON.parse(json) as Record<string, string>;
  } catch {
    return {};
  }
}

export default async function AdminCategories({ params }: { params: Promise<{ locale: string }> }) {
  const { locale: raw } = await params;
  if (!isLocale(raw)) notFound();
  const locale = raw;
  await adminGate();
  const rows = listCategoriesAdmin();
  const categories = rows.map((row: Record<string, unknown>) => ({
    id: String(row.id),
    slug: String(row.slug),
    names: names(String(row.name_i18n ?? "{}")),
    icon: String(row.icon ?? "dot"),
    color: String(row.color ?? ""),
    orderIndex: Number(row.order_index ?? 0),
    isActive: Boolean(row.is_active),
  }));

  return (
    <div className="space-y-4">
      <h1 className="font-display text-2xl font-black tracking-tight">{t(locale, "admin.categories")}</h1>

      <AdminSection title={t(locale, "common.edit")}>
        <CategoryForm locale={locale} categories={categories} />
      </AdminSection>

      <AdminSection>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead><tr><Th>#</Th><Th>Slug</Th><Th>UZ / EN / RU</Th><Th>Icon</Th><Th>{t(locale, "admin.status")}</Th></tr></thead>
            <tbody>
              {categories.map((c) => (
                <tr key={c.id} className="border-t" style={{ borderColor: "var(--line)" }}>
                  <Td className="subtle">{c.orderIndex}</Td>
                  <Td className="font-mono">{c.slug}</Td>
                  <Td>{c.names.uz} / {c.names.en} / {c.names.ru}</Td>
                  <Td className="subtle">{c.icon}</Td>
                  <Td><StatusBadge status={c.isActive ? "active" : "archived"} /></Td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </AdminSection>
    </div>
  );
}
