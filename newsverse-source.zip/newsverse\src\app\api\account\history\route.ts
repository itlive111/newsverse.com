import { run } from "@/server/db";
import { requireUser } from "@/server/auth";
import { guardOrigin } from "@/server/adminGuard";
import { json, handleError } from "@/server/http";

export async function DELETE(request: Request) {
  try {
    guardOrigin(request);
    const user = await requireUser();
    run("DELETE FROM reading_history WHERE user_id = ?", user.id);
    return json({ ok: true });
  } catch (err) {
    return handleError(err);
  }
}
