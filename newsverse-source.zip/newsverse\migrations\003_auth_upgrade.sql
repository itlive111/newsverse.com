-- Account upgrade: usernames, email verification lifecycle, notifications.
-- ADD COLUMN keeps existing rows and data untouched.

ALTER TABLE users ADD COLUMN username TEXT;
ALTER TABLE users ADD COLUMN pending_email TEXT;
ALTER TABLE users ADD COLUMN notification_prefs TEXT NOT NULL DEFAULT '{}';
ALTER TABLE users ADD COLUMN email_verified_at TEXT;

-- Case-insensitive unique usernames (NULL allowed for legacy accounts).
CREATE UNIQUE INDEX IF NOT EXISTS idx_users_username ON users(username COLLATE NOCASE) WHERE username IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_users_email_lower ON users(email COLLATE NOCASE);

-- Verification tokens can carry a payload (e.g. the pending e-mail address).
ALTER TABLE auth_tokens ADD COLUMN meta TEXT;

CREATE INDEX IF NOT EXISTS idx_auth_tokens_kind ON auth_tokens(kind, expires_at);
