import type { Metadata } from "next";
import { resolveLocale, t, type Locale } from "@/i18n";
import { STATIC_PAGES } from "@/content/pages";
import { getSetting } from "@/server/repo/settings";

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const locale = resolveLocale((await params).locale);
  return { title: STATIC_PAGES.about[locale].title, description: STATIC_PAGES.about[locale].intro, alternates: { canonical: `/${locale}/about` } };
}

export default async function AboutPage({ params }: { params: Promise<{ locale: string }> }) {
  const locale = resolveLocale((await params).locale) as Locale;
  const page = STATIC_PAGES.about[locale];
  const contact = getSetting("contact_email", "hello@newsverse.example");
  return (
    <div className="container-nv max-w-3xl py-10">
      <p className="kicker">{t(locale, "footer.about")}</p>
      <h1 className="mt-2 font-display text-4xl font-extrabold tracking-tight">{page.title}</h1>
      <p className="mt-3 text-lg leading-relaxed subtle">{page.intro}</p>
      {page.sections.map((section) => (
        <section key={section.heading} className="mt-8">
          <h2 className="font-display text-xl font-bold">{section.heading}</h2>
          <div className="prose-nv mt-2 reader">
            {section.body.map((p, i) => <p key={i}>{p}</p>)}
          </div>
        </section>
      ))}
      <section id="contact" className="mt-10 rounded-2xl border p-5" style={{ borderColor: "var(--line)" }}>
        <h2 className="font-display text-lg font-bold">{t(locale, "footer.contact")}</h2>
        <a href={`mailto:${contact}`} className="mt-1 inline-block text-sm font-semibold text-brand hover:underline">{contact}</a>
      </section>
    </div>
  );
}
