import { adminGate } from "@/server/adminPage";
import Link from "next/link";
import { notFound } from "next/navigation";
import { formatDate, isLocale, t } from "@/i18n";
import { listReports } from "@/server/repo/admin";
import { ActionButton } from "@/components/admin/action-button";
import { AdminSection, EmptyRow, StatusBadge, Td, Th } from "@/components/admin/ui";

export const dynamic = "force-dynamic";

export default async function AdminReports({ params }: { params: Promise<{ locale: string }> }) {
  const { locale: raw } = await params;
  if (!isLocale(raw)) notFound();
  const locale = raw;
  await adminGate("moderator");
  const reports = listReports();

  return (
    <div className="space-y-4">
      <h1 className="font-display text-2xl font-black tracking-tight">{t(locale, "admin.reports")}</h1>
      <AdminSection>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead><tr><Th>{t(locale, "admin.title")}</Th><Th>Reason</Th><Th>Details</Th><Th>{t(locale, "admin.status")}</Th><Th>{t(locale, "admin.actions")}</Th></tr></thead>
            <tbody>
              {reports.map((r) => (
                <tr key={r.id} className="border-t" style={{ borderColor: "var(--line)" }}>
                  <Td><Link href={`/${locale}/admin/articles/${r.article_id}`} className="line-clamp-2 hover:text-brand">{r.title ?? r.article_id.slice(0, 8)}</Link></Td>
                  <Td className="whitespace-nowrap">{r.reason}</Td>
                  <Td className="max-w-sm"><span className="line-clamp-3 subtle">{r.details ?? "—"}</span></Td>
                  <Td>
                    <StatusBadge status={r.status === "open" ? "open" : "resolved"} />
                    <p className="mt-0.5 text-[10px] subtle">{formatDate(r.created_at, locale)}</p>
                  </Td>
                  <Td>
                    <div className="flex flex-wrap gap-1">
                      <ActionButton endpoint={`/api/admin/reports/${r.id}`} method="PATCH" body={{ status: "resolved" }} label="Resolve" />
                      <ActionButton endpoint={`/api/admin/reports/${r.id}`} method="PATCH" body={{ status: "dismissed" }} label="Dismiss" />
                    </div>
                  </Td>
                </tr>
              ))}
              {!reports.length && <EmptyRow colSpan={5} text={t(locale, "common.noResults")} />}
            </tbody>
          </table>
        </div>
        <p className="mt-3 text-[11px] subtle">
          Correction requests are published on the article once editors update it. Dismissing keeps the report for the record.
        </p>
      </AdminSection>
    </div>
  );
}
