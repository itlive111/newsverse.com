import { dbPath, getDb, migrationsAppliedThisBoot } from "../src/server/db";

getDb();
const applied = migrationsAppliedThisBoot();
console.log(`Database: ${dbPath()}`);
console.log(applied.length ? `Applied: ${applied.join(", ")}` : "Schema already up to date.");
