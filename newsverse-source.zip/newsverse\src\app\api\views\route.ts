import { clientIpFromHeaders, hashIp, rateLimit } from "@/server/auth";
import { json, parseBody, handleError } from "@/server/http";
import { viewSchema } from "@/lib/validation";
import { recordView } from "@/server/repo/content";

/** Records a real view event. One per reader per article per day. */
export async function POST(request: Request) {
  try {
    const ip = clientIpFromHeaders(request.headers) ?? "unknown";
    if (!rateLimit(`view:${ip}`, 120, 60 * 60 * 1000)) return json({ ok: false }, 429);
    const input = await parseBody(request, viewSchema);
    const visitorHash = hashIp(`${ip}:${request.headers.get("user-agent") ?? ""}`);
    const counted = recordView(input.articleId, visitorHash, input.locale ?? "uz");
    return json({ ok: true, counted });
  } catch (err) {
    return handleError(err);
  }
}
