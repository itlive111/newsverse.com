# Upgrade status — accounts, branding, platform

This file records what the **Infinity X** upgrade actually delivered, what is configured,
what remains, and which external services are still required. Nothing here claims a service is
connected unless it was verified in this environment.

## Delivered and verified

### Branding (Phase 3)

- The supplied PNG logo is now used directly, not recreated:
  `public/brand/newsverse-logo.png`, `newsverse-logo-sm.png`, `icon-192.png`, `icon-512.png`,
  `og.png` (generated from the supplied file, transparency preserved).
- Header, footer, mobile menu, login, registration, admin header, favicon and PWA manifest use it.
- Old `logo.svg`, `logo-mark.svg`, `og.svg`, `icon.svg` were deleted; no references remain.

### Accounts (Phase 1)

- Username (unique, case-insensitive), full name, e-mail, password + confirmation.
- Login with **e-mail or username**, password visibility toggle, persistent DB-backed sessions.
- E-mail verification tokens (single-use, hashed, 24 h) with resend; e-mail change only completes
  after the **new address** is verified.
- Change password (requires current password; revokes all other sessions) and change e-mail.
- Profile: name, username, avatar URL, bio, language, interests, notification preferences.
- Roles: `reader`, `author`, `moderator`, `editor`, `admin`, `super_admin` (rank-based checks).
- Privilege-escalation guards: nobody can change their own role/status; an actor can only manage
  accounts below their rank and cannot grant a role at or above their own; only `super_admin` can
  create another `super_admin`; the last administrator cannot be demoted.
- Admin pages call a per-page server gate; APIs re-check the role independently; the admin layout
  filters navigation by role.

### Database (Phase 4)

- Migration `003_auth_upgrade.sql` adds `username`, `pending_email`, `notification_prefs`,
  `email_verified_at`, token `meta`, and indexes — additive, existing rows untouched.
- Supabase/PostgreSQL is **not connected**: no project URL or keys exist in this environment.
  The data layer stays on SQLite with bound parameters and migrations. See
  [DEPLOYMENT.md](DEPLOYMENT.md#moving-to-postgresql) for the swap path.
- Row-level authorization is enforced in the server layer (every query is scoped by session/user),
  which is the SQLite equivalent of RLS until Postgres is connected.

### Languages (Phase 2)

- Public site, auth, account, errors and empty states are dictionary-driven; the newly added
  auth/security strings exist in Uzbek, English and Russian.
- Language choice persists via cookie **and** is written to the signed-in user's profile.
- Report reasons were the last hardcoded public strings and are translated now.
- **Admin panel is still English-only.** Its navigation/page titles use the dictionary, but table
  headers, form labels and helper text inside the CRUD screens are hardcoded English. This is the
  main remaining i18n gap (see below).

## Collection cadence and volume (latest iteration)

- Feed catalogue expanded from 14 to **30** verified publisher feeds (BBC sections, Guardian
  sections, The Verge, Wired, Engadget, Space.com, ESPN, Variety, UN News, France 24, DW,
  Euronews, plus the existing Uzbek/Russian sources).
- Every source now runs **hourly** (`interval_minutes = 60`); per-source daily cycles are possible
  by setting `1440`. The scheduler still ticks every 20 s and persists job state in SQLite.
- Per-run cap raised from 25 to **50** items (`ingest_max_items_per_run`).
- A live collection pass after the change took published articles from 255 to **767** (plus 214
  held in the moderation queue by the high-risk-category rule).
- `npm run sources:expand` applies the catalogue to an existing database idempotently.
- New wordmark: the supplied mark plus “News” (brand red) and “Verse” (theme text colour, so it
  flips between white on dark and near-black on light).

## Not implemented / not connected

| Item | State | What is required |
| --- | --- | --- |
| Transactional e-mail (verification, reset, digests) | Not connected | An email provider (Resend/Postmark/SES). Links are written to the server log (`[newsverse] verification link …`). |
| Supabase / PostgreSQL / Supabase Auth / Storage | Not connected | A Supabase project URL, anon key and service key; then port the driver and schema. |
| AI summaries, translation, assistant (Phases 5/7) | Optional, off | `AI_API_KEY` for an OpenAI-compatible endpoint; without it the deterministic fallback runs and is labelled. |
| Google sign-in | Off | OAuth client id/secret and callback configuration. |
| World news map, country pages, event timelines (Phase 8) | Not built | Needs geocoding/country metadata per article plus map tiles. |
| Audio summaries / TTS, galleries, infographics (Phase 10) | Not built | TTS provider or recorded audio; licensed media pipeline. |
| Comment replies, reactions (Phase 11) | Not built | Schema + UI; current comments are single-level with moderation. |
| Follow publishers/countries, custom collections (Phase 9) | Partial | Interests, bookmarks, history and personalization exist; follows/collections do not. |
| Payments / subscriptions (Phase 14) | Disabled by design | A payment provider and keys; no fake checkout is shown. |
| Admin translation (Phase 2 remainder) | Partial | Translate ~150 CRUD labels into uz/ru. |

## Required environment variables (full list)

See [.env.example](../.env.example). Operational keys: `NEXT_PUBLIC_SITE_URL`, `DATABASE_PATH`,
`APP_SECRET`, `INGEST_*`, `CRON_SECRET`, `AI_*`.
Optional next integrations: `RESEND_API_KEY` (or equivalent), `SUPABASE_URL`,
`SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`, `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`,
payment provider keys. None of these are present or referenced by the running code yet.

## Verification performed for this upgrade

See [TESTING.md](TESTING.md) for commands and results:

- Registration with username → account created, verification token logged.
- Verification link consumed → `email_verified = 1`, redirect `?verify=ok`.
- Login with **username** → 200; password change → old password 401, new password 200.
- E-mail change → link to new address verified → `email` updated, `pending_email` cleared.
- Role promotion by super admin → 200; admin attempting to grant `super_admin` → 403; self-demote → 403.
- Moderator: admin dashboard/comments/reports 200, settings/users/articles show no data and the
  settings API returns 403.
- Logo served from `/brand/…` on public pages; favicon/manifest updated.
- `tsc` clean; 34 unit tests pass; production build succeeds.
