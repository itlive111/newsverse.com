"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { t, locales, localeNames, type Locale } from "@/i18n";

type Category = { slug: string; name: string };

export function ProfileForm({
  locale,
  initial,
}: {
  locale: Locale;
  initial: {
    name: string;
    username: string;
    bio: string;
    avatar_url: string;
    locale: string;
    notify_email: boolean;
    notify_breaking: boolean;
    notify_comments: boolean;
  };
}) {
  const [form, setForm] = useState(initial);
  const [state, setState] = useState<"idle" | "busy" | "ok" | "error">("idle");
  const router = useRouter();

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setState("busy");
    const res = await fetch("/api/account", {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        name: form.name,
        username: form.username,
        bio: form.bio,
        avatar_url: form.avatar_url,
        locale: form.locale,
        notify_email: form.notify_email,
        notify_breaking: form.notify_breaking,
        notify_comments: form.notify_comments,
      }),
    }).catch(() => null);
    setState(res?.ok ? "ok" : "error");
    if (res?.ok) router.refresh();
  }

  return (
    <form onSubmit={submit} className="space-y-4">
      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <label htmlFor="acc-name" className="label">{t(locale, "auth.name")}</label>
          <input id="acc-name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="input" minLength={2} required />
        </div>
        <div>
          <label htmlFor="acc-username" className="label">{t(locale, "auth.username")}</label>
          <input
            id="acc-username"
            value={form.username}
            onChange={(e) => setForm({ ...form, username: e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, "") })}
            className="input"
            minLength={3}
            maxLength={24}
            required
          />
          <p className="mt-1 text-[10px] subtle">{t(locale, "auth.usernameHint")}</p>
        </div>
        <div>
          <label htmlFor="acc-locale" className="label">{t(locale, "nav.language")}</label>
          <select id="acc-locale" value={form.locale} onChange={(e) => setForm({ ...form, locale: e.target.value })} className="input">
            {locales.map((l) => <option key={l} value={l}>{localeNames[l]}</option>)}
          </select>
        </div>
      </div>
      <fieldset>
        <legend className="label">{t(locale, "account.notifications")}</legend>
        <div className="space-y-2 text-xs">
          {([
            ["notify_email", t(locale, "account.newsletter")],
            ["notify_breaking", t(locale, "home.breaking")],
            ["notify_comments", t(locale, "article.comments")],
          ] as const).map(([key, label]) => (
            <label key={key} className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={form[key]}
                onChange={(e) => setForm({ ...form, [key]: e.target.checked })}
              />
              {label}
            </label>
          ))}
        </div>
      </fieldset>
      <div>
        <label htmlFor="acc-avatar" className="label">{t(locale, "account.avatarUrl")}</label>
        <input id="acc-avatar" type="url" value={form.avatar_url} onChange={(e) => setForm({ ...form, avatar_url: e.target.value })} className="input" placeholder="https://…" />
      </div>
      <div>
        <label htmlFor="acc-bio" className="label">{t(locale, "account.bio")}</label>
        <textarea id="acc-bio" rows={3} maxLength={500} value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })} className="input" />
      </div>
      <div className="flex items-center gap-3">
        <button type="submit" className="btn-primary" disabled={state === "busy"}>{t(locale, "account.save")}</button>
        {state === "ok" && <span className="text-xs text-emerald-400">{t(locale, "account.saved")}</span>}
        {state === "error" && <span className="text-xs text-brand">{t(locale, "common.error")}</span>}
      </div>
    </form>
  );
}

export function InterestsForm({
  locale,
  categories,
  initial,
}: {
  locale: Locale;
  categories: Category[];
  initial: string[];
}) {
  const [selected, setSelected] = useState<string[]>(initial);
  const [state, setState] = useState<"idle" | "busy" | "ok" | "error">("idle");
  const router = useRouter();

  function toggle(slug: string) {
    setSelected((current) => (current.includes(slug) ? current.filter((s) => s !== slug) : [...current, slug]));
  }

  async function save() {
    setState("busy");
    const res = await fetch("/api/account", {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ interests: selected }),
    }).catch(() => null);
    setState(res?.ok ? "ok" : "error");
    if (res?.ok) router.refresh();
  }

  return (
    <div>
      <p className="text-xs subtle">{t(locale, "account.interestsHint")}</p>
      <div className="mt-3 flex flex-wrap gap-1.5">
        {categories.map((c) => {
          const active = selected.includes(c.slug);
          return (
            <button
              key={c.slug}
              type="button"
              onClick={() => toggle(c.slug)}
              aria-pressed={active}
              className={`chip transition ${active ? "!border-brand !bg-brand/10 !text-brand" : "hover:border-brand"}`}
            >
              {c.name}
            </button>
          );
        })}
      </div>
      <div className="mt-3 flex items-center gap-3">
        <button type="button" onClick={save} className="btn-primary !text-xs" disabled={state === "busy"}>{t(locale, "account.save")}</button>
        {state === "ok" && <span className="text-xs text-emerald-400">{t(locale, "account.saved")}</span>}
      </div>
    </div>
  );
}

export function DangerZone({ locale }: { locale: Locale }) {
  const router = useRouter();
  const [confirming, setConfirming] = useState(false);

  async function clearHistory() {
    await fetch("/api/account/history", { method: "DELETE" });
    router.refresh();
  }

  async function deleteAccount() {
    if (!confirming) {
      setConfirming(true);
      return;
    }
    const res = await fetch("/api/account/delete", { method: "POST" });
    if (res.ok) {
      router.push(`/${locale}`);
      router.refresh();
    }
  }

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-2">
        <a href="/api/account/export" className="btn-ghost !text-xs">{t(locale, "account.export")}</a>
        <button type="button" onClick={clearHistory} className="btn-ghost !text-xs">{t(locale, "account.clearHistory")}</button>
      </div>
      <p className="text-xs subtle">{t(locale, "account.dangerHint")}</p>
      <button type="button" onClick={deleteAccount} className="btn !bg-brand/10 !text-brand hover:!bg-brand hover:!text-white">
        {confirming ? t(locale, "account.deleteConfirm") : t(locale, "account.delete")}
      </button>
    </div>
  );
}

function Notice({ kind, children }: { kind: "ok" | "error"; children: React.ReactNode }) {
  return (
    <p className={`rounded-lg px-3 py-2 text-xs ${kind === "ok" ? "bg-emerald-500/10 text-emerald-400" : "bg-brand/10 text-brand"}`}>
      {children}
    </p>
  );
}

/** Email verification, password change and email change — all server-verified. */
export function SecuritySection({
  locale,
  verified,
  pendingEmail,
}: {
  locale: Locale;
  verified: boolean;
  pendingEmail: string | null;
}) {
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [pwState, setPwState] = useState<"idle" | "busy" | "ok" | "error">("idle");
  const [newEmail, setNewEmail] = useState("");
  const [emailPassword, setEmailPassword] = useState("");
  const [emailState, setEmailState] = useState<"idle" | "busy" | "ok" | "error">("idle");
  const [resendState, setResendState] = useState<"idle" | "busy" | "ok">("idle");

  async function changePassword(event: React.FormEvent) {
    event.preventDefault();
    setPwState("busy");
    const res = await fetch("/api/account/password", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ currentPassword: current, newPassword: next }),
    }).catch(() => null);
    if (!res?.ok) return setPwState("error");
    setPwState("ok");
    setCurrent("");
    setNext("");
  }

  async function changeEmail(event: React.FormEvent) {
    event.preventDefault();
    setEmailState("busy");
    const res = await fetch("/api/account/email", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ newEmail, password: emailPassword }),
    }).catch(() => null);
    if (!res?.ok) return setEmailState("error");
    setEmailState("ok");
    setEmailPassword("");
  }

  async function resend() {
    setResendState("busy");
    await fetch("/api/auth/resend-verification", { method: "POST" }).catch(() => {});
    setResendState("ok");
  }

  return (
    <div className="space-y-5">
      {!verified && (
        <div className="rounded-lg border border-amber-500/30 bg-amber-500/5 p-3 text-xs">
          <p className="font-semibold text-amber-300">{t(locale, "account.emailUnverified")}</p>
          <div className="mt-2 flex flex-wrap items-center gap-2">
            <button type="button" onClick={resend} disabled={resendState !== "idle"} className="btn-ghost !py-1 !text-[11px]">
              {t(locale, "auth.resend")}
            </button>
            {resendState === "ok" && <span className="text-emerald-400">{t(locale, "auth.resendSent")}</span>}
          </div>
        </div>
      )}
      {pendingEmail && (
        <p className="rounded-lg border p-3 text-xs subtle" style={{ borderColor: "var(--line)" }}>
          {t(locale, "auth.checkEmail")} <strong>{pendingEmail}</strong>
        </p>
      )}

      <form onSubmit={changePassword} className="space-y-3">
        <p className="text-xs font-bold uppercase tracking-wider subtle">{t(locale, "auth.changePassword")}</p>
        <div className="grid gap-3 sm:grid-cols-2">
          <div>
            <label htmlFor="pw-current" className="label">{t(locale, "auth.currentPassword")}</label>
            <input id="pw-current" type="password" required autoComplete="current-password" value={current} onChange={(e) => setCurrent(e.target.value)} className="input" />
          </div>
          <div>
            <label htmlFor="pw-new" className="label">{t(locale, "auth.newPassword")}</label>
            <input id="pw-new" type="password" required minLength={8} autoComplete="new-password" value={next} onChange={(e) => setNext(e.target.value)} className="input" />
          </div>
        </div>
        {pwState === "ok" && <Notice kind="ok">{t(locale, "auth.passwordChanged")}</Notice>}
        {pwState === "error" && <Notice kind="error">{t(locale, "auth.invalid")}</Notice>}
        <button type="submit" disabled={pwState === "busy"} className="btn-ghost !text-xs">{t(locale, "auth.changePassword")}</button>
      </form>

      <form onSubmit={changeEmail} className="space-y-3 border-t pt-4" style={{ borderColor: "var(--line)" }}>
        <p className="text-xs font-bold uppercase tracking-wider subtle">{t(locale, "auth.changeEmail")}</p>
        <div className="grid gap-3 sm:grid-cols-2">
          <div>
            <label htmlFor="email-new" className="label">{t(locale, "auth.email")}</label>
            <input id="email-new" type="email" required value={newEmail} onChange={(e) => setNewEmail(e.target.value)} className="input" />
          </div>
          <div>
            <label htmlFor="email-password" className="label">{t(locale, "auth.currentPassword")}</label>
            <input id="email-password" type="password" required autoComplete="current-password" value={emailPassword} onChange={(e) => setEmailPassword(e.target.value)} className="input" />
          </div>
        </div>
        {emailState === "ok" && <Notice kind="ok">{t(locale, "auth.checkEmail")}</Notice>}
        {emailState === "error" && <Notice kind="error">{t(locale, "auth.emailTaken")}</Notice>}
        <button type="submit" disabled={emailState === "busy"} className="btn-ghost !text-xs">{t(locale, "auth.changeEmail")}</button>
      </form>
    </div>
  );
}
