"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

/**
 * Small client mutation control used across the admin. Every request is
 * re-authorized server-side; the UI state here is cosmetic only.
 */
export function ActionButton({
  endpoint,
  method = "POST",
  body,
  label,
  busyLabel,
  confirmText,
  variant = "ghost",
  className = "",
}: {
  endpoint: string;
  method?: "POST" | "PATCH" | "DELETE";
  body?: Record<string, unknown>;
  label: string;
  busyLabel?: string;
  confirmText?: string;
  variant?: "ghost" | "primary" | "danger";
  className?: string;
}) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const router = useRouter();

  async function run() {
    if (confirmText && !window.confirm(confirmText)) return;
    setBusy(true);
    setError("");
    try {
      const res = await fetch(endpoint, {
        method,
        headers: { "content-type": "application/json" },
        body: body ? JSON.stringify(body) : undefined,
      });
      if (!res.ok) {
        const data = (await res.json().catch(() => ({}))) as { error?: string };
        setError(data.error ?? `HTTP ${res.status}`);
        return;
      }
      router.refresh();
    } catch {
      setError("network");
    } finally {
      setBusy(false);
    }
  }

  const styles =
    variant === "primary"
      ? "btn-primary !px-2.5 !py-1 !text-[11px]"
      : variant === "danger"
        ? "btn !bg-brand/10 !px-2.5 !py-1 !text-[11px] !text-brand hover:!bg-brand hover:!text-white"
        : "btn-ghost !px-2.5 !py-1 !text-[11px]";

  return (
    <span className={`inline-flex flex-col gap-0.5 ${className}`}>
      <button type="button" onClick={run} disabled={busy} className={styles}>
        {busy ? busyLabel ?? "…" : label}
      </button>
      {error && <span className="text-[9px] text-brand">{error}</span>}
    </span>
  );
}
