import { notFound } from "next/navigation";
import { isLocale } from "@/i18n";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";

/** Public reader chrome. The admin group below `(admin)` has its own shell. */
export default async function SiteLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: Promise<{ locale: string }>;
}) {
  const { locale: raw } = await params;
  if (!isLocale(raw)) notFound();
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader locale={raw} />
      <main id="main" className="flex-1">{children}</main>
      <SiteFooter locale={raw} />
    </div>
  );
}
