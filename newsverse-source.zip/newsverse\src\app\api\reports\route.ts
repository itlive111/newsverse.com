import { getCurrentUser } from "@/server/auth";
import { guardOrigin } from "@/server/adminGuard";
import { json, parseBody, fail, handleError } from "@/server/http";
import { reportSchema } from "@/lib/validation";
import { addReport } from "@/server/repo/content";

export async function POST(request: Request) {
  try {
    guardOrigin(request);
    const user = await getCurrentUser();
    const input = await parseBody(request, reportSchema);
    if (!input.details && !input.reason) return fail("Tell us what is wrong", 422);
    addReport(input.articleId, input.reason, input.details, user?.id ?? null);
    return json({ ok: true });
  } catch (err) {
    return handleError(err);
  }
}
