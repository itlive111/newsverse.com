# Deployment

NewsVerse is a stateful Node.js server: it serves the site **and** runs the collection scheduler in
the same process, backed by a SQLite file. Plan for one instance with a persistent disk. It cannot
run on edge/serverless runtimes (Workers, Vercel Edge) because it needs `node:sqlite` and a
long-lived process.

## Requirements

- Node.js **24+** (Node 22.5+ works with `--experimental-sqlite`)
- ~300 MB RAM for the server, plus room for the database
- A persistent volume for `data/`
- Optional: an AI provider key (OpenAI-compatible)

## Docker (recommended)

```bash
cp .env.example .env
# set APP_SECRET, NEXT_PUBLIC_SITE_URL, optionally AI_API_KEY
docker compose up -d --build
docker compose exec web env \
  ADMIN_EMAIL=you@example.com \
  ADMIN_PASSWORD='a-long-password' \
  ADMIN_NAME='Your Name' \
  npm run admin:create
```

`docker-compose.yml` mounts the named volume `newsverse-data` at `/app/data`. Without a volume the
database is lost when the container is recreated.

Health check: `GET /api/health` returns database, migration count, scheduler state and AI status.

## Plain server (systemd)

```ini
[Unit]
Description=NewsVerse
After=network.target

[Service]
Type=simple
WorkingDirectory=/srv/newsverse
EnvironmentFile=/srv/newsverse/.env
ExecStart=/usr/bin/npm start
Restart=always
RestartSec=5
User=newsverse

[Install]
WantedBy=multi-user.target
```

```bash
npm ci --no-audit --no-fund
npm run build
```

## Reverse proxy (nginx)

```nginx
server {
  listen 443 ssl http2;
  server_name news.example.com;

  client_max_body_size 2m;

  location / {
    proxy_pass http://127.0.0.1:3000;
    proxy_http_version 1.1;
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
  }
}
```

Set `NEXT_PUBLIC_SITE_URL=https://news.example.com` and (if you use another hostname) add it to
`ALLOWED_ORIGINS`. State-changing requests are rejected when the `Origin` header does not match.

## Scheduler

Two supported modes:

1. **In-process (default)** — `INGEST_AUTO_START=1`. Starts with the server and ticks every
   `INGEST_TICK_MS` (default 20s), enqueuing each enabled source when its interval is due. It keeps
   running with no visitors. Restarts are safe: jobs are rows in the `jobs` table with retry state.
2. **External** — `INGEST_AUTO_START=0`, then:

   ```bash
   curl -fsS -H "Authorization: Bearer $CRON_SECRET" https://news.example.com/api/cron/tick
   ```

   Run it every 5–15 minutes from system cron, GitHub Actions, Cloud Scheduler or cron-job.org.
   Without a configured `CRON_SECRET` the endpoint returns 503 (it is never open by default).

Timestamps are stored in UTC (`ISO 8601`) and rendered in the reader's language locale.

## Environment

See [.env.example](../.env.example) for every variable. Minimum production set:

| Variable | Notes |
| --- | --- |
| `NEXT_PUBLIC_SITE_URL` | Canonical origin, used for sitemap/RSS/OG |
| `DATABASE_PATH` | Use an absolute path on a persistent volume |
| `APP_SECRET` | 32+ random bytes; signs reset tokens and visitor hashes |
| `CRON_SECRET` | Only if you drive jobs externally |
| `AI_API_KEY` / `AI_MODEL` / `AI_BASE_URL` | Optional; enables summaries + translation drafts |

## Scaling

SQLite handles a news site's read traffic comfortably on one node (WAL mode, prepared statements,
indexed queries). It does not support multiple writers across processes, so:

- Keep **one** application instance. Behind a load balancer, use sticky routing to it.
- If you need several instances, move to PostgreSQL first (below), then run the web tier and a
  single worker that calls `schedulerTick()` (or the cron endpoint).

### Moving to PostgreSQL

The repositories are the only place that touches the driver:

1. Replace `src/server/db/index.ts` with a `pg` Pool exposing `all/get/run/tx` (same signatures).
2. Port `migrations/*.sql`: `TEXT` timestamps are fine; replace `node:sqlite` specifics
   (`AUTOINCREMENT`, `PRAGMA`) and keep the `_migrations` bookkeeping.
3. Keep bound parameters — never interpolate SQL.
4. Re-run the unit suite and the acceptance checks in [TESTING.md](TESTING.md).

## Media and images

The app stores remote image URLs and renders them directly (no re-hosting), which respects
publisher licensing. `images.unoptimized` is enabled so Next does not proxy third-party images.
If you later add an object-storage uploader, keep validation to `http(s)` URLs and size limits.

## Email

No mail provider is integrated. Password-reset links are written to the server log with a clear
`[newsverse]` prefix. To enable real email, add a provider SDK in a server-only module and send
from `src/app/api/auth/forgot/route.ts`; do not move provider keys to the client.

## First-day checklist

- [ ] `APP_SECRET` set to a random 32-byte value
- [ ] `NEXT_PUBLIC_SITE_URL` matches the public origin
- [ ] Administrator created and a **second** admin added
- [ ] Admin → Sources: test each feed, disable any that 404
- [ ] Admin → Automation: moderation mode and trust threshold chosen
- [ ] Backups scheduled ([BACKUPS.md](BACKUPS.md))
- [ ] `/api/health` monitored
