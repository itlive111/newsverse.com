import { get } from "@/server/db";
import { ensureBootstrapped } from "@/server/db/bootstrap";
import { audit, clientIpFromHeaders, createSession, hashIp, rateLimit, verifyPassword } from "@/server/auth";
import { json, fail, parseBody, handleError } from "@/server/http";
import { loginSchema } from "@/lib/validation";

export async function POST(request: Request) {
  try {
    ensureBootstrapped();
    const ip = clientIpFromHeaders(request.headers) ?? "unknown";
    const input = await parseBody(request, loginSchema);
    if (!rateLimit(`login:${ip}`, 12, 15 * 60 * 1000)) {
      return fail("rate_limited", 429);
    }
    const user = get<{ id: string; email: string; password_hash: string; status: string; role: string; locale: string }>(
      "SELECT id, email, password_hash, status, role, locale FROM users WHERE email = ? COLLATE NOCASE OR username = ? COLLATE NOCASE",
      input.email,
      input.email,
    );
    const ok = user && verifyPassword(input.password, user.password_hash);
    if (!ok) {
      // Uniform response and timing-ish-safe failure path.
      audit({ actor: user ? { id: user.id, email: user.email } : null, action: "auth.login_failed", ipHash: hashIp(ip) });
      return fail("invalid_credentials", 401);
    }
    if (user.status !== "active") return fail("account_suspended", 403);
    await createSession(user.id);
    audit({ actor: { id: user.id, email: user.email }, action: "auth.login", entity: "user", entityId: user.id, ipHash: hashIp(ip) });
    const isStaff = ["admin", "editor"].includes(user.role);
    return json({ ok: true, redirect: `/${user.locale}${isStaff ? "/admin" : "/account"}`, locale: user.locale });
  } catch (err) {
    return handleError(err);
  }
}
