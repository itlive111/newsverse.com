import type { Metadata } from "next";
import { resolveLocale, type Locale } from "@/i18n";
import { STATIC_PAGES } from "@/content/pages";

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const locale = resolveLocale((await params).locale);
  return { title: STATIC_PAGES.terms[locale].title, description: STATIC_PAGES.terms[locale].intro, alternates: { canonical: `/${locale}/terms` } };
}

export default async function TermsPage({ params }: { params: Promise<{ locale: string }> }) {
  const locale = resolveLocale((await params).locale) as Locale;
  const page = STATIC_PAGES.terms[locale];
  return (
    <div className="container-nv max-w-3xl py-10">
      <h1 className="font-display text-4xl font-extrabold tracking-tight">{page.title}</h1>
      <p className="mt-3 text-lg leading-relaxed subtle">{page.intro}</p>
      {page.sections.map((section) => (
        <section key={section.heading} className="mt-8">
          <h2 className="font-display text-xl font-bold">{section.heading}</h2>
          <div className="prose-nv mt-2 reader">
            {section.body.map((p, i) => <p key={i}>{p}</p>)}
          </div>
        </section>
      ))}
    </div>
  );
}
