"use client";

import { usePathname, useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { localeFlags, localeNames, locales, type Locale } from "@/i18n";
import { IconGlobe } from "@/components/icons";

export function LanguageSwitcher({ current, label }: { current: Locale; label: string }) {
  const pathname = usePathname() || `/${current}`;
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [pending, startTransition] = useTransition();

  function choose(locale: Locale) {
    const parts = pathname.split("/");
    parts[1] = locale;
    const target = parts.join("/") || `/${locale}`;
    document.cookie = `nv_locale=${locale};path=/;max-age=31536000;samesite=lax`;
    // Keep a signed-in user's profile language in sync with the UI choice.
    // Anonymous visitors simply get a 401, which is expected and ignored.
    void fetch("/api/account", {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ locale }),
    }).catch(() => {});
    setOpen(false);
    startTransition(() => router.push(target));
  }

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-haspopup="menu"
        aria-expanded={open}
        aria-label={`${label}: ${localeNames[current]}`}
        className="flex h-9 items-center gap-1.5 rounded-full border px-3 text-xs font-semibold text-[color:var(--muted)] transition hover:border-brand hover:text-brand"
        style={{ borderColor: "var(--line)", opacity: pending ? 0.6 : 1 }}
      >
        <IconGlobe size={15} />
        {localeFlags[current]}
      </button>
      {open && (
        <>
          <button className="fixed inset-0 z-40 cursor-default" aria-label="close" onClick={() => setOpen(false)} tabIndex={-1} />
          <div
            role="menu"
            className="absolute right-0 z-50 mt-2 w-44 overflow-hidden rounded-xl border shadow-card"
            style={{ background: "var(--surface)", borderColor: "var(--line)" }}
          >
            {locales.map((locale) => (
              <button
                key={locale}
                role="menuitem"
                onClick={() => choose(locale)}
                className="flex w-full items-center justify-between px-3 py-2.5 text-left text-sm transition hover:bg-brand/10"
              >
                <span className={locale === current ? "font-semibold text-brand" : ""}>{localeNames[locale]}</span>
                <span className="text-[10px] font-bold tracking-wider subtle">{localeFlags[locale]}</span>
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
