/**
 * Creates or promotes an administrator account.
 *
 * Usage:
 *   ADMIN_EMAIL=you@example.com ADMIN_PASSWORD='long-password' npm run admin:create
 *
 * Credentials are read from the environment so they never land in shell
 * history files committed to the repository.
 */
import crypto from "node:crypto";
import { get, run } from "../src/server/db";
import { hashPassword } from "../src/server/password";

function main() {
  const email = (process.env.ADMIN_EMAIL ?? "").trim().toLowerCase();
  const password = process.env.ADMIN_PASSWORD ?? "";
  const name = (process.env.ADMIN_NAME ?? "NewsVerse Admin").trim();
  const role = (process.env.ADMIN_ROLE ?? "admin").trim();
  if (!["admin", "super_admin"].includes(role)) {
    console.error("ADMIN_ROLE must be 'admin' or 'super_admin'.");
    process.exit(1);
  }

  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
    console.error("Set ADMIN_EMAIL to a valid email address.");
    process.exit(1);
  }
  if (password.length < 10) {
    console.error("Set ADMIN_PASSWORD to at least 10 characters.");
    process.exit(1);
  }

  const existing = get<{ id: string }>("SELECT id FROM users WHERE email = ?", email);
  const now = new Date().toISOString();

  if (existing) {
    run(
      "UPDATE users SET role = ?, status = 'active', password_hash = ?, updated_at = ? WHERE id = ?",
      role,
      hashPassword(password),
      now,
      existing.id,
    );
    console.log(`Promoted existing account ${email} to ${role} and reset its password.`);
    return;
  }

  run(
    `INSERT INTO users (id, email, name, password_hash, role, locale, status, interests, created_at, updated_at)
     VALUES (?,?,?,?,?,?,?,?,?,?)`,
    crypto.randomUUID(), email, name, hashPassword(password), role, "uz", "active", "[]", now, now,
  );
  console.log(`Created ${role} ${email}. Sign in at /uz/login and open /uz/admin.`);
}

main();
