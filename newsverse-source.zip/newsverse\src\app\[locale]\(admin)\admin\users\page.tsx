import { adminGate } from "@/server/adminPage";
import { notFound } from "next/navigation";
import { formatDate, isLocale, t } from "@/i18n";
import { listUsers } from "@/server/repo/admin";
import { getCurrentUser } from "@/server/auth";
import { UserActions } from "@/components/admin/user-actions";
import { AdminSection, EmptyRow, StatusBadge, Td, Th } from "@/components/admin/ui";

export const dynamic = "force-dynamic";

export default async function AdminUsers({
  params,
  searchParams,
}: {
  params: Promise<{ locale: string }>;
  searchParams: Promise<{ q?: string }>;
}) {
  const { locale: raw } = await params;
  if (!isLocale(raw)) notFound();
  const locale = raw;
  await adminGate("admin");
  const { q = "" } = await searchParams;
  const me = await getCurrentUser();
  const users = listUsers(q.slice(0, 80));

  return (
    <div className="space-y-4">
      <h1 className="font-display text-2xl font-black tracking-tight">{t(locale, "admin.users")}</h1>

      <AdminSection>
        <form method="get" className="flex flex-wrap items-end gap-2">
          <div className="min-w-[200px] flex-1">
            <label className="label" htmlFor="uq">{t(locale, "search.title")}</label>
            <input id="uq" name="q" defaultValue={q} className="input !py-1.5 !text-xs" placeholder="email or name" />
          </div>
          <button className="btn-ghost !py-1.5 !text-xs" type="submit">{t(locale, "common.filter")}</button>
        </form>
      </AdminSection>

      <AdminSection>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr>
                <Th>{t(locale, "auth.name")}</Th>
                <Th>{t(locale, "auth.email")}</Th>
                <Th>Role</Th>
                <Th>{t(locale, "admin.status")}</Th>
                <Th>{t(locale, "admin.comments")}</Th>
                <Th>Joined</Th>
                <Th>{t(locale, "admin.actions")}</Th>
              </tr>
            </thead>
            <tbody>
              {users.map((u) => (
                <tr key={u.id} className="border-t" style={{ borderColor: "var(--line)" }}>
                  <Td className="font-semibold">{u.name}</Td>
                  <Td className="break-all subtle">{u.email}</Td>
                  <Td className="uppercase">{u.role}</Td>
                  <Td><StatusBadge status={u.status} /></Td>
                  <Td>{u.comments}</Td>
                  <Td className="whitespace-nowrap subtle">{formatDate(u.created_at, locale)}</Td>
                  <Td>
                    <UserActions
                      locale={locale}
                      userId={u.id}
                      role={u.role}
                      status={u.status}
                      self={me?.id === u.id}
                    />
                  </Td>
                </tr>
              ))}
              {!users.length && <EmptyRow colSpan={7} text={t(locale, "common.noResults")} />}
            </tbody>
          </table>
        </div>
        <p className="mt-3 text-[11px] subtle">
          Role and status changes are limited to administrators and recorded in the audit log. Suspending an account revokes its sessions.
        </p>
      </AdminSection>
    </div>
  );
}
