"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { locales, t, type Locale } from "@/i18n";

type Row = {
  id: string;
  slug: string;
  names: Record<string, string>;
  icon: string;
  color: string;
  orderIndex: number;
  isActive: boolean;
};

const empty = (): Row => ({
  id: "",
  slug: "",
  names: { uz: "", en: "", ru: "" },
  icon: "dot",
  color: "#FF1538",
  orderIndex: 0,
  isActive: true,
});

export function CategoryForm({ locale, categories }: { locale: Locale; categories: Row[] }) {
  const [form, setForm] = useState<Row>(empty());
  const [state, setState] = useState<"idle" | "busy" | "ok" | "error">("idle");
  const [message, setMessage] = useState("");
  const router = useRouter();

  async function save() {
    setState("busy");
    setMessage("");
    const res = await fetch("/api/admin/categories", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        id: form.id || undefined,
        slug: form.slug,
        names: form.names,
        icon: form.icon,
        color: form.color,
        orderIndex: form.orderIndex,
        isActive: form.isActive,
      }),
    }).catch(() => null);
    const data = await res?.json().catch(() => ({}));
    if (!res?.ok) {
      setMessage(data?.issues?.map((i: { path: string; message: string }) => `${i.path}: ${i.message}`).join("; ") || data?.error || "error");
      setState("error");
      return;
    }
    setState("ok");
    setMessage(t(locale, "admin.saved"));
    router.refresh();
  }

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-2">
        <button type="button" className="btn-ghost !py-1 !text-xs" onClick={() => setForm(empty())}>
          + New category
        </button>
        {categories.map((c) => (
          <button
            key={c.id}
            type="button"
            onClick={() => setForm(c)}
            className={`rounded-full border px-2.5 py-1 text-[11px] ${form.id === c.id ? "border-brand text-brand" : "subtle"}`}
            style={{ borderColor: form.id === c.id ? "#FF1538" : "var(--line)" }}
          >
            {c.names[locale] || c.slug}{c.isActive ? "" : " (hidden)"}
          </button>
        ))}
      </div>

      <div className="grid gap-2 sm:grid-cols-2">
        <div>
          <label className="label" htmlFor="cat-slug">Slug *</label>
          <input id="cat-slug" className="input !py-1.5 !text-xs" value={form.slug} onChange={(e) => setForm({ ...form, slug: e.target.value.toLowerCase() })} placeholder="technology" />
        </div>
        <div>
          <label className="label" htmlFor="cat-icon">Icon key</label>
          <input id="cat-icon" className="input !py-1.5 !text-xs" value={form.icon} onChange={(e) => setForm({ ...form, icon: e.target.value })} />
        </div>
        {locales.map((l) => (
          <div key={l}>
            <label className="label" htmlFor={`cat-${l}`}>{l.toUpperCase()} *</label>
            <input
              id={`cat-${l}`}
              className="input !py-1.5 !text-xs"
              value={form.names[l] ?? ""}
              onChange={(e) => setForm({ ...form, names: { ...form.names, [l]: e.target.value } })}
            />
          </div>
        ))}
        <div className="grid grid-cols-3 gap-2">
          <div>
            <label className="label" htmlFor="cat-order">Order</label>
            <input id="cat-order" type="number" className="input !py-1.5 !text-xs" value={form.orderIndex} onChange={(e) => setForm({ ...form, orderIndex: Number(e.target.value) })} />
          </div>
          <div>
            <label className="label" htmlFor="cat-color">Color</label>
            <input id="cat-color" className="input !py-1.5 !text-xs" value={form.color} onChange={(e) => setForm({ ...form, color: e.target.value })} />
          </div>
          <label className="mt-5 flex items-center gap-2 text-[11px]">
            <input type="checkbox" checked={form.isActive} onChange={(e) => setForm({ ...form, isActive: e.target.checked })} />
            Visible
          </label>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <button type="button" onClick={save} disabled={state === "busy"} className="btn-primary !py-1.5 !text-xs">
          {state === "busy" ? t(locale, "common.loading") : t(locale, "common.save")}
        </button>
        {message && <span className={`text-[11px] ${state === "error" ? "text-brand" : "text-emerald-400"}`}>{message}</span>}
      </div>
    </div>
  );
}
