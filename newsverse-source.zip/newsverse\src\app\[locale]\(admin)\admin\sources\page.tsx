import { adminGate } from "@/server/adminPage";
import Link from "next/link";
import { notFound } from "next/navigation";
import { formatDate, formatNumber, isLocale, t } from "@/i18n";
import { sourceHealth } from "@/server/repo/admin";
import { listCategories } from "@/server/repo/content";
import { SourceManager } from "@/components/admin/source-manager";
import { ActionButton } from "@/components/admin/action-button";
import { AdminSection, EmptyRow, StatusBadge, Td, Th } from "@/components/admin/ui";

export const dynamic = "force-dynamic";

export default async function AdminSources({ params }: { params: Promise<{ locale: string }> }) {
  const { locale: raw } = await params;
  if (!isLocale(raw)) notFound();
  const locale = raw;
  await adminGate();
  const sources = sourceHealth();
  const categories = listCategories(locale, true).map((c) => ({ slug: c.slug, name: c.name }));

  return (
    <div className="space-y-4">
      <div>
        <h1 className="font-display text-2xl font-black tracking-tight">{t(locale, "admin.sources")}</h1>
        <p className="text-xs subtle">
          Only add feeds you are permitted to syndicate. NewsVerse stores short excerpts, attribution and a link to the publisher.
        </p>
      </div>

      <AdminSection title={t(locale, "common.save")}>
        <SourceManager locale={locale} categories={categories} />
      </AdminSection>

      <AdminSection>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr>
                <Th>{t(locale, "search.source")}</Th>
                <Th>{t(locale, "admin.status")}</Th>
                <Th>{t(locale, "search.category")}</Th>
                <Th>Items</Th>
                <Th>Last run</Th>
                <Th>{t(locale, "admin.actions")}</Th>
              </tr>
            </thead>
            <tbody>
              {sources.map((s) => (
                <tr key={s.id} className="border-t" style={{ borderColor: "var(--line)" }}>
                  <Td>
                    <Link href={s.feed_url} target="_blank" rel="noopener noreferrer" className="font-semibold hover:text-brand">{s.name}</Link>
                    <p className="text-[10px] subtle">trust {s.trust}/5 · {s.moderation} · every {s.interval_minutes}m · {s.locale.toUpperCase()}</p>
                  </Td>
                  <Td>
                    {s.consecutive_failures > 0 ? <span className="text-brand">failing ×{s.consecutive_failures}</span> : <StatusBadge status={s.enabled ? "active" : "archived"} />}
                    {s.last_error && <p className="mt-0.5 max-w-[220px] truncate text-[10px] text-brand" title={s.last_error}>{s.last_error}</p>}
                  </Td>
                  <Td className="uppercase subtle">{s.category_slug}</Td>
                  <Td>{formatNumber(s.total_items, locale)}</Td>
                  <Td className="subtle">{s.last_run_at ? formatDate(s.last_run_at, locale) : "never"}</Td>
                  <Td>
                    <div className="flex flex-wrap gap-1">
                      <ActionButton endpoint={`/api/admin/sources/${s.id}`} method="PATCH" body={{ enabled: !s.enabled }} label={s.enabled ? "Disable" : "Enable"} />
                      <ActionButton endpoint={`/api/admin/sources/${s.id}/run`} label={t(locale, "admin.runNow")} busyLabel="…" />
                    </div>
                  </Td>
                </tr>
              ))}
              {!sources.length && <EmptyRow colSpan={6} text={t(locale, "common.noResults")} />}
            </tbody>
          </table>
        </div>
      </AdminSection>
    </div>
  );
}
