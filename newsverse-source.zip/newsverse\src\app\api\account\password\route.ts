import { get, run, nowIso } from "@/server/db";
import {
  audit, clientIpFromHeaders, createSession, hashIp, hashPassword, rateLimit, requireUser, verifyPassword,
} from "@/server/auth";
import { guardOrigin } from "@/server/adminGuard";
import { json, fail, parseBody, handleError } from "@/server/http";
import { passwordChangeSchema } from "@/lib/validation";

export async function POST(request: Request) {
  try {
    guardOrigin(request);
    const user = await requireUser();
    const ip = clientIpFromHeaders(request.headers) ?? "unknown";
    if (!rateLimit(`pwchange:${user.id}:${ip}`, 6, 60 * 60 * 1000)) return fail("rate_limited", 429);

    const input = await parseBody(request, passwordChangeSchema);
    const row = get<{ password_hash: string }>("SELECT password_hash FROM users WHERE id = ?", user.id);
    if (!row || !verifyPassword(input.currentPassword, row.password_hash)) {
      return fail("invalid_credentials", 400);
    }
    run("UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?", hashPassword(input.newPassword), nowIso(), user.id);
    // Revoke every other session, then re-issue one for this browser.
    run("DELETE FROM sessions WHERE user_id = ?", user.id);
    await createSession(user.id);
    audit({ actor: user, action: "auth.password_changed", entity: "user", entityId: user.id, ipHash: hashIp(ip) });
    return json({ ok: true });
  } catch (err) {
    return handleError(err);
  }
}
