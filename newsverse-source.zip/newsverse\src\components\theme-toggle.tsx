"use client";

import { useEffect, useState } from "react";
import { IconMoon, IconSun } from "@/components/icons";

export function ThemeToggle({ label }: { label: string }) {
  const [light, setLight] = useState(false);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setLight(document.documentElement.classList.contains("light"));
    setMounted(true);
  }, []);

  function toggle() {
    const next = !light;
    setLight(next);
    document.documentElement.classList.toggle("light", next);
    try {
      localStorage.setItem("nv_theme", next ? "light" : "dark");
    } catch { /* storage may be blocked */ }
  }

  return (
    <button
      type="button"
      onClick={toggle}
      aria-label={label}
      title={label}
      className="flex h-9 w-9 items-center justify-center rounded-full border text-[color:var(--muted)] transition hover:border-brand hover:text-brand"
      style={{ borderColor: "var(--line)" }}
    >
      {mounted && light ? <IconSun size={17} /> : <IconMoon size={17} />}
    </button>
  );
}
