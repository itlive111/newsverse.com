"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import type { Locale } from "@/i18n";
import { t } from "@/i18n";
import { IconBookmark } from "@/components/icons";

export function BookmarkButton({
  articleId,
  initialSaved,
  locale,
  signedIn,
}: {
  articleId: string;
  initialSaved: boolean;
  locale: Locale;
  signedIn: boolean;
}) {
  const [saved, setSaved] = useState(initialSaved);
  const [busy, setBusy] = useState(false);
  const router = useRouter();

  async function toggle() {
    if (!signedIn) {
      router.push(`/${locale}/login?next=${encodeURIComponent(`/${locale}/saved`)}`);
      return;
    }
    setBusy(true);
    try {
      const res = await fetch("/api/bookmarks", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ articleId }),
      });
      if (res.ok) {
        const data = (await res.json()) as { saved: boolean };
        setSaved(data.saved);
        router.refresh();
      }
    } finally {
      setBusy(false);
    }
  }

  return (
    <button
      type="button"
      onClick={toggle}
      disabled={busy}
      aria-pressed={saved}
      className={`btn-ghost no-print !px-3 !py-1.5 text-xs ${saved ? "!border-brand !text-brand" : ""}`}
    >
      <IconBookmark size={15} filled={saved} />
      {saved ? t(locale, "article.saved") : t(locale, "article.save")}
    </button>
  );
}
