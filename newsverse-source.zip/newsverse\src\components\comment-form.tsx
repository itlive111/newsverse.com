"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { t, type Locale } from "@/i18n";

export function CommentForm({ articleId, locale }: { articleId: string; locale: Locale }) {
  const [body, setBody] = useState("");
  const [state, setState] = useState<"idle" | "loading" | "ok" | "error">("idle");
  const router = useRouter();

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    if (body.trim().length < 2) return;
    setState("loading");
    try {
      const res = await fetch("/api/comments", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ articleId, body }),
      });
      if (!res.ok) throw new Error("failed");
      setBody("");
      setState("ok");
      router.refresh();
    } catch {
      setState("error");
    }
  }

  return (
    <form onSubmit={submit} className="mt-4">
      <label htmlFor="comment-body" className="sr-only">{t(locale, "article.commentPlaceholder")}</label>
      <textarea
        id="comment-body"
        value={body}
        onChange={(e) => setBody(e.target.value)}
        rows={3}
        maxLength={2000}
        placeholder={t(locale, "article.commentPlaceholder")}
        className="input resize-y"
      />
      <div className="mt-2 flex items-center justify-between gap-3">
        <p className="text-[11px] subtle">{t(locale, "article.commentModeration")}</p>
        <button type="submit" className="btn-primary" disabled={state === "loading"}>
          {state === "loading" ? t(locale, "common.loading") : t(locale, "article.commentSubmit")}
        </button>
      </div>
      {state === "error" && <p className="mt-2 text-xs text-brand">{t(locale, "common.error")}</p>}
    </form>
  );
}
