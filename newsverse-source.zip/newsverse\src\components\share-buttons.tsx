"use client";

import { useState } from "react";
import { t, type Locale } from "@/i18n";
import { IconLink, IconShare } from "@/components/icons";

export function ShareButtons({ url, title, locale }: { url: string; title: string; locale: Locale }) {
  const [copied, setCopied] = useState(false);
  const encodedUrl = encodeURIComponent(url);
  const encodedTitle = encodeURIComponent(title);

  async function copy() {
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch { /* clipboard may be unavailable */ }
  }

  async function nativeShare() {
    if (navigator.share) {
      try {
        await navigator.share({ title, url });
        return;
      } catch { /* cancelled */ }
    }
    void copy();
  }

  const links = [
    { label: "Telegram", href: `https://t.me/share/url?url=${encodedUrl}&text=${encodedTitle}` },
    { label: "X", href: `https://twitter.com/intent/tweet?url=${encodedUrl}&text=${encodedTitle}` },
    { label: "Facebook", href: `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}` },
  ];

  return (
    <div className="no-print flex flex-wrap items-center gap-2">
      <span className="text-[11px] font-bold uppercase tracking-wider subtle">{t(locale, "article.share")}</span>
      {links.map((l) => (
        <a
          key={l.label}
          href={l.href}
          target="_blank"
          rel="noopener noreferrer"
          className="chip hover:border-brand hover:text-brand"
        >
          {l.label}
        </a>
      ))}
      <button type="button" onClick={nativeShare} className="chip hover:border-brand hover:text-brand">
        <IconShare size={12} /> {t(locale, "article.share")}
      </button>
      <button type="button" onClick={copy} className="chip hover:border-brand hover:text-brand">
        <IconLink size={12} /> {copied ? t(locale, "article.copied") : t(locale, "article.copyLink")}
      </button>
    </div>
  );
}
