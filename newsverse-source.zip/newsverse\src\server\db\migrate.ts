import fs from "node:fs";
import path from "node:path";
import type { DatabaseSync } from "node:sqlite";

export type MigrationResult = { applied: string[]; skipped: string[] };

/**
 * Applies every `migrations/NNN_*.sql` file in filename order exactly once.
 * Each migration runs inside a transaction; applied names are recorded in
 * `_migrations`, so repeat boots are safe (idempotent startup).
 */
export function applyMigrations(db: DatabaseSync, migrationsDir?: string): MigrationResult {
  const dir = migrationsDir ?? path.join(process.cwd(), "migrations");
  db.exec(
    "CREATE TABLE IF NOT EXISTS _migrations (name TEXT PRIMARY KEY, applied_at TEXT NOT NULL)",
  );
  const done = new Set(
    (db.prepare("SELECT name FROM _migrations").all() as { name: string }[]).map((r) => r.name),
  );
  const result: MigrationResult = { applied: [], skipped: [] };
  if (!fs.existsSync(dir)) {
    throw new Error(`Migrations directory not found: ${dir}`);
  }
  const files = fs
    .readdirSync(dir)
    .filter((f) => f.endsWith(".sql"))
    .sort((a, b) => a.localeCompare(b));

  for (const file of files) {
    if (done.has(file)) {
      result.skipped.push(file);
      continue;
    }
    const sql = fs.readFileSync(path.join(dir, file), "utf8");
    db.exec("BEGIN");
    try {
      db.exec(sql);
      db.prepare("INSERT INTO _migrations (name, applied_at) VALUES (?, ?)").run(
        file,
        new Date().toISOString(),
      );
      db.exec("COMMIT");
      result.applied.push(file);
    } catch (err) {
      db.exec("ROLLBACK");
      throw new Error(`Migration ${file} failed: ${(err as Error).message}`);
    }
  }
  return result;
}
