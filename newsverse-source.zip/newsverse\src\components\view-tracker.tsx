"use client";

import { useEffect } from "react";
import type { Locale } from "@/i18n";

/** Records a genuine view event server-side (deduped per visitor/day). */
export function ViewTracker({ articleId, locale }: { articleId: string; locale: Locale }) {
  useEffect(() => {
    const key = `nv_view_${articleId}`;
    try {
      if (sessionStorage.getItem(key)) return;
      sessionStorage.setItem(key, "1");
    } catch { /* ignore */ }
    const controller = new AbortController();
    fetch("/api/views", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ articleId, locale }),
      signal: controller.signal,
      keepalive: true,
    }).catch(() => {});
    return () => controller.abort();
  }, [articleId, locale]);
  return null;
}
