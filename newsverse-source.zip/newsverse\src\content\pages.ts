import type { Locale } from "@/i18n";

type Section = { heading: string; body: string[] };
type PageText = { title: string; intro: string; sections: Section[] };

export const STATIC_PAGES: Record<"about" | "privacy" | "terms", Record<Locale, PageText>> = {
  about: {
    en: {
      title: "About NewsVerse",
      intro:
        "NewsVerse is an independent, multilingual news aggregator. It collects headlines from publishers’ public RSS feeds and APIs, summarises them, and links readers back to the original reporting.",
      sections: [
        {
          heading: "How the platform works",
          body: [
            "A background scheduler polls each configured source on its own interval. Duplicate URLs and near-duplicate titles are filtered, so the same wire story does not flood the feed.",
            "Summaries are written for NewsVerse. Full articles are never copied: every item shows the publisher name and links to the original page. Where a source permits excerpts, a short excerpt is shown with attribution.",
            "Articles can be reviewed by an editor before publication. High-risk topics — elections, health, finance and emergencies — are routed to manual review by default.",
          ],
        },
        {
          heading: "Artificial intelligence",
          body: [
            "AI is used, when configured, to draft summaries, suggest categories and produce machine translations. AI summaries are labelled. Machine translations are labelled and are not presented as human-verified.",
            "AI is never used to invent quotations, statistics or events, and it does not decide that an allegation is true.",
          ],
        },
        {
          heading: "Corrections and contact",
          body: [
            "Every article has a “Report an error” link. Reports reach the editorial dashboard and are tracked to resolution.",
            "Contact the newsroom using the address in the footer. We publish our source list, including trust level and moderation rule for each outlet.",
          ],
        },
      ],
    },
    uz: {
      title: "NewsVerse haqida",
      intro:
        "NewsVerse — mustaqil, ko‘p tilli yangiliklar agregatori. U nashrlarning ochiq RSS lentalari va API’laridan sarlavhalarni yig‘adi, xulosa tayyorlaydi va o‘quvchini asl manbaga qaytaradi.",
      sections: [
        {
          heading: "Platforma qanday ishlaydi",
          body: [
            "Fon jadvali har bir manbani o‘z intervali bo‘yicha tekshiradi. Takroriy havolalar va deyarli bir xil sarlavhalar filtrlanadi — bir xil xabar lentani to‘ldirmaydi.",
            "Xulosalar NewsVerse uchun yoziladi. To‘liq maqola hech qachon ko‘chirilmaydi: har bir materialda nashr nomi va asl sahifaga havola ko‘rsatiladi.",
            "Maqolalar chop etishdan oldin muharrir ko‘rigidan o‘tishi mumkin. Yuqori xavfli mavzular — saylov, sog‘liq, moliya va favqulodda holatlar — standart bo‘yicha qo‘lda ko‘rikka yuboriladi.",
          ],
        },
        {
          heading: "Sun’iy intellekt",
          body: [
            "AI sozlanganda xulosa, kategoriya taklifi va mashina tarjimasi uchun ishlatiladi. AI xulosalari belgilanadi. Mashina tarjimalari ham belgilanadi va inson tekshirgan tarjima sifatida ko‘rsatilmaydi.",
            "AI iqtibos, statistika yoki voqealarni o‘ylab topmaydi va da’voning to‘g‘riligini o‘zi tasdiqlamaydi.",
          ],
        },
        {
          heading: "Tuzatishlar va aloqa",
          body: [
            "Har bir maqolada “Xatolik haqida xabar berish” havolasi bor. Xabarlar tahririyat paneliga tushadi va hal qilinishigacha kuzatiladi.",
            "Tahririyat bilan sayt pastidagi manzil orqali bog‘laning. Manbalar ro‘yxatini, ularning ishonch darajasi va moderatsiya qoidasi bilan birga e’lon qilamiz.",
          ],
        },
      ],
    },
    ru: {
      title: "О NewsVerse",
      intro:
        "NewsVerse — независимый многоязычный агрегатор новостей. Он собирает заголовки из открытых RSS-лент и API изданий, готовит резюме и возвращает читателя к оригинальной публикации.",
      sections: [
        {
          heading: "Как работает платформа",
          body: [
            "Фоновый планировщик опрашивает каждый источник с его собственным интервалом. Повторяющиеся ссылки и почти одинаковые заголовки отфильтровываются.",
            "Резюме пишутся для NewsVerse. Полные статьи не копируются: у каждого материала указано издание и ссылка на оригинал.",
            "Материалы могут проходить проверку редактора. Темы высокого риска — выборы, здоровье, финансы и ЧС — по умолчанию идут на ручную проверку.",
          ],
        },
        {
          heading: "Искусственный интеллект",
          body: [
            "ИИ используется для черновиков резюме, подсказок категорий и машинного перевода. Резюме ИИ помечаются. Машинный перевод помечается и не выдаётся за проверенный человеком.",
            "ИИ не придумывает цитаты, статистику и события и не подтверждает истинность обвинений.",
          ],
        },
        {
          heading: "Исправления и контакты",
          body: [
            "В каждой статье есть ссылка «Сообщить об ошибке». Сообщения попадают в редакционную панель и отслеживаются до решения.",
            "Связаться с редакцией можно по адресу в подвале сайта. Мы публикуем список источников с уровнем доверия и правилом модерации.",
          ],
        },
      ],
    },
  },
  privacy: {
    en: {
      title: "Privacy policy",
      intro:
        "We collect the minimum needed to run a news site: an account you create, the preferences you save, and aggregate usage data. Public reading needs no account.",
      sections: [
        {
          heading: "What we store",
          body: [
            "Account: name, email, password hash (scrypt), preferred language, chosen interests, bookmarks, reading history and comments.",
            "Usage: view events are stored with a one-way visitor fingerprint and a day key, used only to rank “most read” and “trending”. They are not linked to your account.",
            "Security: session records (hashed token, expiry, user agent, hashed IP) and audit entries for administrative actions.",
          ],
        },
        {
          heading: "Cookies",
          body: [
            "nv_session keeps you signed in. nv_locale remembers your language. No advertising or cross-site tracking cookies are used.",
            "Theme and font size preferences are stored in your browser’s local storage, not on the server.",
          ],
        },
        {
          heading: "Your rights",
          body: [
            "You can export your data and delete your account from the account page. Deleting an account removes bookmarks, history, comments and sessions.",
            "Analytics rows are retained for one year by default, then pruned. Server logs are kept only as long as needed to operate the service.",
          ],
        },
      ],
    },
    uz: {
      title: "Maxfiylik siyosati",
      intro:
        "Biz faqat yangiliklar saytini yuritish uchun zarur bo‘lgan minimal ma’lumotni yig‘amiz: siz yaratgan hisob, saqlangan sozlamalar va umumiy foydalanish statistikasi. Ochiq yangiliklarni o‘qish uchun hisob shart emas.",
      sections: [
        {
          heading: "Qanday ma’lumot saqlanadi",
          body: [
            "Hisob: ism, email, parol xeshi (scrypt), tanlangan til, qiziqishlar, saqlangan maqolalar, o‘qish tarixi va izohlar.",
            "Foydalanish: ko‘rish hodisalari bir tomonlama visitor hash va kun kaliti bilan saqlanadi, faqat “eng ko‘p o‘qilgan” va “trendda” ro‘yxatlarini tuzish uchun. Ular hisobingizga bog‘lanmaydi.",
            "Xavfsizlik: sessiya yozuvlari (xeshlangan token, muddat, user agent, xeshlangan IP) va administrator amallari uchun audit yozuvlari.",
          ],
        },
        {
          heading: "Cookie fayllar",
          body: [
            "nv_session sizni tizimda ushlab turadi. nv_locale tilni eslab qoladi. Reklama yoki saytlararo kuzatuv cookie’lari ishlatilmaydi.",
            "Mavzu va shrift sozlamalari brauzeringizning lokal xotirasida saqlanadi, serverda emas.",
          ],
        },
        {
          heading: "Sizning huquqlaringiz",
          body: [
            "Profil sahifasidan ma’lumotlaringizni yuklab olish va hisobni o‘chirish mumkin. Hisob o‘chirilganda saqlanganlar, tarix, izohlar va sessiyalar ham o‘chadi.",
            "Statistika yozuvlari standart bo‘yicha bir yil saqlanadi, so‘ng tozalanadi. Server jurnallari xizmatni yuritish uchun zarur muddatdagina saqlanadi.",
          ],
        },
      ],
    },
    ru: {
      title: "Политика конфиденциальности",
      intro:
        "Мы собираем минимум, необходимый для работы новостного сайта: созданный вами аккаунт, сохранённые настройки и обезличенную статистику. Для чтения новостей аккаунт не нужен.",
      sections: [
        {
          heading: "Что хранится",
          body: [
            "Аккаунт: имя, email, хеш пароля (scrypt), язык, интересы, закладки, история чтения и комментарии.",
            "Использование: просмотры хранятся с односторонним отпечатком посетителя и ключом дня — только для рейтингов «самое читаемое» и «в тренде». Они не связываются с аккаунтом.",
            "Безопасность: записи сессий (хеш токена, срок, user agent, хеш IP) и аудит действий администраторов.",
          ],
        },
        {
          heading: "Cookie",
          body: [
            "nv_session поддерживает вход. nv_locale запоминает язык. Рекламных и межсайтовых трекинговых cookie нет.",
            "Тема и размер шрифта хранятся в локальном хранилище браузера, а не на сервере.",
          ],
        },
        {
          heading: "Ваши права",
          body: [
            "В разделе аккаунта можно выгрузить данные и удалить аккаунт. Удаление убирает закладки, историю, комментарии и сессии.",
            "Строки аналитики по умолчанию хранятся год, затем удаляются. Серверные журналы хранятся только необходимый для работы срок.",
          ],
        },
      ],
    },
  },
  terms: {
    en: {
      title: "Terms of use",
      intro:
        "By using NewsVerse you agree to these terms. The service links to third-party publishers; their content remains their responsibility and property.",
      sections: [
        {
          heading: "Content and attribution",
          body: [
            "NewsVerse publishes summaries, headlines and excerpts with clear attribution to the publisher and a link to the original. Copyright in the underlying reporting stays with the publisher.",
            "If you believe a summary misrepresents your publication or infringes your rights, contact us and we will correct or remove it.",
          ],
        },
        {
          heading: "Accounts and conduct",
          body: [
            "You are responsible for your account credentials. Do not post unlawful, abusive or spam comments; comments are moderated and can be removed.",
            "Automated scraping of this site, attempts to bypass authorization, and abuse of the ingestion endpoints are prohibited.",
          ],
        },
        {
          heading: "No professional advice",
          body: [
            "News reporting is not medical, legal or financial advice. Verify critical information with the original publisher before acting on it.",
            "The service is provided as-is; availability may be interrupted for maintenance or upstream outages.",
          ],
        },
      ],
    },
    uz: {
      title: "Foydalanish shartlari",
      intro:
        "NewsVerse’dan foydalanib, siz ushbu shartlarga rozilik bildirasiz. Xizmat uchinchi tomon nashrlariga havola qiladi; ularning mazmuni nashrning o‘z javobgarligi va mulki hisoblanadi.",
      sections: [
        {
          heading: "Mazmun va atributsiya",
          body: [
            "NewsVerse xulosalar, sarlavhalar va parchalarni nashr nomi va asl havola bilan chop etadi. Asosiy reportajga bo‘lgan mualliflik huquqi nashrda qoladi.",
            "Agar xulosa nashringizni noto‘g‘ri aks ettirsa yoki huquqlaringizni buzsa, biz bilan bog‘laning — tuzatamiz yoki olib tashlaymiz.",
          ],
        },
        {
          heading: "Hisoblar va odob-axloq",
          body: [
            "Hisob ma’lumotlari uchun siz javobgarsiz. Noqonuniy, haqoratli yoki spam izohlar yozmang; izohlar moderatsiyadan o‘tadi va olib tashlanishi mumkin.",
            "Saytni avtomatik skanerlash, avtorizatsiyani chetlab o‘tish va import endpointlarini suiiste’mol qilish taqiqlanadi.",
          ],
        },
        {
          heading: "Professional maslahat emas",
          body: [
            "Yangiliklar tibbiy, huquqiy yoki moliyaviy maslahat emas. Muhim ma’lumotni amalda qo‘llashdan oldin asl manbadan tekshiring.",
            "Xizmat “bor holicha” taqdim etiladi; texnik ishlar yoki tashqi uzilishlar sabab vaqtincha ishlamasligi mumkin.",
          ],
        },
      ],
    },
    ru: {
      title: "Условия использования",
      intro:
        "Используя NewsVerse, вы соглашаетесь с этими условиями. Сервис ссылается на сторонние издания; их контент остаётся их ответственностью и собственностью.",
      sections: [
        {
          heading: "Контент и атрибуция",
          body: [
            "NewsVerse публикует резюме, заголовки и фрагменты с указанием издания и ссылкой на оригинал. Авторские права на репортаж сохраняются за изданием.",
            "Если резюме искажает вашу публикацию или нарушает ваши права, свяжитесь с нами — мы исправим или удалим материал.",
          ],
        },
        {
          heading: "Аккаунты и поведение",
          body: [
            "Вы отвечаете за данные своего аккаунта. Не публикуйте незаконные, оскорбительные или спам-комментарии; комментарии модерируются.",
            "Автоматический скрейпинг сайта, обход авторизации и злоупотребление endpoint’ами импорта запрещены.",
          ],
        },
        {
          heading: "Не является профессиональной консультацией",
          body: [
            "Новости не являются медицинской, юридической или финансовой консультацией. Проверяйте критичную информацию в первоисточнике.",
            "Сервис предоставляется «как есть»; возможны перерывы из-за обслуживания или сбоев у источников.",
          ],
        },
      ],
    },
  },
};
