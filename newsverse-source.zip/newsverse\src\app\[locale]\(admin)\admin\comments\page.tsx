import { adminGate } from "@/server/adminPage";
import Link from "next/link";
import { notFound } from "next/navigation";
import { formatDate, isLocale, t } from "@/i18n";
import { listCommentsAdmin } from "@/server/repo/admin";
import { ActionButton } from "@/components/admin/action-button";
import { AdminSection, EmptyRow, StatusBadge, Td, Th } from "@/components/admin/ui";

export const dynamic = "force-dynamic";

const TABS = ["pending", "approved", "rejected", "all"];

export default async function AdminComments({
  params,
  searchParams,
}: {
  params: Promise<{ locale: string }>;
  searchParams: Promise<{ status?: string }>;
}) {
  const { locale: raw } = await params;
  if (!isLocale(raw)) notFound();
  const locale = raw;
  await adminGate("moderator");
  const sp = await searchParams;
  const status = TABS.includes(sp.status ?? "") ? (sp.status as string) : "pending";
  const comments = listCommentsAdmin(status);

  return (
    <div className="space-y-4">
      <h1 className="font-display text-2xl font-black tracking-tight">{t(locale, "admin.comments")}</h1>

      <div className="flex flex-wrap gap-1">
        {TABS.map((tab) => (
          <Link
            key={tab}
            href={`?status=${tab}`}
            className={`rounded-full border px-3 py-1 text-[11px] font-bold uppercase ${tab === status ? "border-brand text-brand" : "subtle"}`}
            style={{ borderColor: tab === status ? "#FF1538" : "var(--line)" }}
          >
            {tab}
          </Link>
        ))}
      </div>

      <AdminSection>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead><tr><Th>{t(locale, "admin.title")}</Th><Th>{t(locale, "auth.name")}</Th><Th>{t(locale, "admin.status")}</Th><Th>Date</Th><Th>{t(locale, "admin.actions")}</Th></tr></thead>
            <tbody>
              {comments.map((c) => (
                <tr key={c.id} className="border-t" style={{ borderColor: "var(--line)" }}>
                  <Td>
                    <p className="max-w-md">{c.body}</p>
                    <Link href={`/${locale}/news/${c.slug}`} target="_blank" className="mt-1 block text-[10px] underline subtle">
                      {c.article_title}
                    </Link>
                  </Td>
                  <Td className="subtle">{c.author}<br /><span className="text-[10px]">{c.email}</span></Td>
                  <Td><StatusBadge status={c.status} /></Td>
                  <Td className="whitespace-nowrap subtle">{formatDate(c.created_at, locale)}</Td>
                  <Td>
                    <div className="flex flex-wrap gap-1">
                      <ActionButton endpoint={`/api/admin/comments/${c.id}`} method="PATCH" body={{ status: "approved" }} label={t(locale, "admin.approve")} />
                      <ActionButton endpoint={`/api/admin/comments/${c.id}`} method="PATCH" body={{ status: "rejected" }} label={t(locale, "admin.reject")} variant="danger" />
                    </div>
                  </Td>
                </tr>
              ))}
              {!comments.length && <EmptyRow colSpan={5} text={t(locale, "common.noResults")} />}
            </tbody>
          </table>
        </div>
      </AdminSection>
    </div>
  );
}
