import { run } from "@/server/db";
import { requireUser, destroySession, audit } from "@/server/auth";
import { guardOrigin } from "@/server/adminGuard";
import { json, handleError } from "@/server/http";

export async function POST(request: Request) {
  try {
    guardOrigin(request);
    const user = await requireUser();
    // Personal rows cascade via foreign keys; newsletter entry is anonymised.
    run("UPDATE newsletter_subscribers SET user_id = NULL WHERE user_id = ?", user.id);
    run("DELETE FROM users WHERE id = ?", user.id);
    audit({ actor: { id: user.id, email: user.email }, action: "account.delete", entity: "user", entityId: user.id });
    await destroySession();
    return json({ ok: true });
  } catch (err) {
    return handleError(err);
  }
}
