"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { t, type Locale } from "@/i18n";

const ROLES = ["reader", "author", "moderator", "editor", "admin", "super_admin"];

export function UserActions({
  locale,
  userId,
  role,
  status,
  self,
}: {
  locale: Locale;
  userId: string;
  role: string;
  status: string;
  self: boolean;
}) {
  const [nextRole, setNextRole] = useState(role);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const router = useRouter();

  async function patch(payload: Record<string, string>) {
    setBusy(true);
    setError("");
    const res = await fetch(`/api/admin/users/${userId}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(payload),
    }).catch(() => null);
    if (!res?.ok) {
      const data = (await res?.json().catch(() => ({}))) as { error?: string };
      setError(data?.error ?? "error");
    } else {
      router.refresh();
    }
    setBusy(false);
  }

  if (self) return <span className="text-[10px] subtle">you</span>;

  return (
    <div className="flex flex-wrap items-center gap-1">
      <select
        value={nextRole}
        onChange={(e) => setNextRole(e.target.value)}
        className="input !w-auto !px-2 !py-1 !text-[11px]"
        aria-label="Role"
      >
        {ROLES.map((r) => <option key={r} value={r}>{r}</option>)}
      </select>
      <button type="button" disabled={busy || nextRole === role} onClick={() => patch({ role: nextRole })} className="btn-ghost !px-2 !py-1 !text-[11px]">
        {t(locale, "common.save")}
      </button>
      <button
        type="button"
        disabled={busy}
        onClick={() => patch({ status: status === "active" ? "suspended" : "active" })}
        className={`btn !px-2 !py-1 !text-[11px] ${status === "active" ? "!bg-brand/10 !text-brand" : "!bg-emerald-500/10 !text-emerald-400"}`}
      >
        {status === "active" ? t(locale, "admin.suspend") : t(locale, "admin.reactivate")}
      </button>
      {error && <span className="text-[9px] text-brand">{error}</span>}
    </div>
  );
}
