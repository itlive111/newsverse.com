import { guardAdmin } from "@/server/adminGuard";
import { json, parseBody, handleError } from "@/server/http";
import { commentModerationSchema } from "@/lib/validation";
import { moderateComment } from "@/server/repo/admin";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(request: Request, ctx: Ctx) {
  try {
    const user = await guardAdmin(request, "moderator");
    const { id } = await ctx.params;
    const input = await parseBody(request, commentModerationSchema);
    moderateComment(id, input.status, user);
    return json({ ok: true });
  } catch (err) {
    return handleError(err);
  }
}
