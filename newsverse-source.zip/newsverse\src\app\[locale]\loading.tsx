export default function Loading() {
  return (
    <div className="container-nv py-6" aria-busy="true" aria-live="polite">
      <div className="grid gap-5 lg:grid-cols-12">
        <div className="space-y-4 lg:col-span-8">
          <div className="skeleton aspect-[16/9] w-full rounded-2xl" />
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="skeleton h-56 rounded-2xl" />
            <div className="skeleton h-56 rounded-2xl" />
          </div>
        </div>
        <div className="space-y-4 lg:col-span-4">
          {[0, 1, 2, 3, 4].map((i) => (
            <div key={i} className="flex gap-3">
              <div className="skeleton h-16 w-24 rounded-lg" />
              <div className="flex-1 space-y-2 py-1">
                <div className="skeleton h-3 w-full rounded" />
                <div className="skeleton h-3 w-3/4 rounded" />
                <div className="skeleton h-2 w-1/2 rounded" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
