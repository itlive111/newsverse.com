#!/usr/bin/env node
/**
 * Consistent online backup of the SQLite database using VACUUM INTO.
 * Safe to run while the server is live.
 *
 *   node scripts/backup.js [outputDirectory]
 */
const fs = require("node:fs");
const path = require("node:path");
const { DatabaseSync } = require("node:sqlite");

const dbPath = process.env.DATABASE_PATH || "./data/newsverse.db";
const outDir = path.resolve(process.argv[2] || "./backups");

if (!fs.existsSync(dbPath)) {
  console.error(`Database not found: ${dbPath}`);
  process.exit(1);
}

fs.mkdirSync(outDir, { recursive: true });
const stamp = new Date().toISOString().replace(/[:.]/g, "-");
const target = path.join(outDir, `newsverse-${stamp}.db`);

const db = new DatabaseSync(dbPath);
db.prepare("VACUUM INTO ?").run(target);
db.close();

const size = fs.statSync(target).size;
console.log(`Backup written: ${target} (${(size / 1024).toFixed(0)} KB)`);
