"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

export function AdminNav({ locale, items }: { locale: string; items: { href: string; label: string }[] }) {
  const pathname = usePathname();
  return (
    <nav className="flex gap-1 overflow-x-auto lg:flex-col lg:overflow-visible" aria-label="Admin">
      {items.map((item) => {
        const active = item.href === `/${locale}/admin` ? pathname === item.href : pathname.startsWith(item.href);
        return (
          <Link
            key={item.href}
            href={item.href}
            className={`whitespace-nowrap rounded-lg px-3 py-2 text-xs font-semibold transition ${
              active ? "bg-brand text-white" : "text-[color:var(--muted)] hover:bg-white/5 hover:text-white"
            }`}
          >
            {item.label}
          </Link>
        );
      })}
    </nav>
  );
}
