import type { Metadata } from "next";
import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { getCurrentUser, hasRole, isAdmin } from "@/server/auth";
import { isLocale, t } from "@/i18n";
import { AdminNav } from "@/components/admin/nav";
import { LogoutButton } from "@/components/logout-button";
import { LanguageSwitcher } from "@/components/language-switcher";
import { BrandLogo } from "@/components/brand-logo";

export const metadata: Metadata = {
  title: "Admin · NewsVerse",
  robots: { index: false, follow: false, nocache: true },
};

/** Admin pages never render for unauthorised visitors, regardless of links. */
export default async function AdminLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: Promise<{ locale: string }>;
}) {
  const { locale: raw } = await params;
  if (!isLocale(raw)) notFound();
  const locale = raw;
  const user = await getCurrentUser();
  if (!user) redirect(`/${locale}/login?next=/${locale}/admin`);

  if (!isAdmin(user)) {
    return (
      <div className="mx-auto flex min-h-screen max-w-md flex-col items-center justify-center px-6 text-center">
        <p className="font-display text-5xl font-black text-brand">403</p>
        <h1 className="mt-2 text-xl font-bold">{t(locale, "admin.forbidden")}</h1>
        <p className="mt-2 text-sm subtle">{t(locale, "admin.forbiddenBody")}</p>
        <Link href={`/${locale}`} className="btn-primary mt-5">{t(locale, "admin.backToSite")}</Link>
      </div>
    );
  }

  const allItems: { href: string; label: string; min: "moderator" | "editor" | "admin" }[] = [
    { href: `/${locale}/admin`, label: t(locale, "admin.overview"), min: "moderator" },
    { href: `/${locale}/admin/articles`, label: t(locale, "admin.articles"), min: "editor" },
    { href: `/${locale}/admin/sources`, label: t(locale, "admin.sources"), min: "editor" },
    { href: `/${locale}/admin/automation`, label: t(locale, "admin.automation"), min: "editor" },
    { href: `/${locale}/admin/categories`, label: t(locale, "admin.categories"), min: "editor" },
    { href: `/${locale}/admin/comments`, label: t(locale, "admin.comments"), min: "moderator" },
    { href: `/${locale}/admin/reports`, label: t(locale, "admin.reports"), min: "moderator" },
    { href: `/${locale}/admin/users`, label: t(locale, "admin.users"), min: "admin" },
    { href: `/${locale}/admin/newsletter`, label: t(locale, "admin.newsletter"), min: "admin" },
    { href: `/${locale}/admin/audit`, label: t(locale, "admin.audit"), min: "admin" },
    { href: `/${locale}/admin/settings`, label: t(locale, "admin.settings"), min: "admin" },
  ];
  const items = allItems.filter((item) => hasRole(user, item.min));

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-40 border-b backdrop-blur" style={{ borderColor: "var(--line)", background: "color-mix(in srgb, var(--bg) 88%, transparent)" }}>
        <div className="mx-auto flex max-w-[1400px] items-center gap-4 px-4 py-3">
          <Link href={`/${locale}/admin`} className="flex items-center gap-2">
            <BrandLogo size="sm" />
            <span className="font-display text-xs font-extrabold uppercase tracking-wider text-brand">Admin</span>
          </Link>
          <div className="ml-auto flex items-center gap-2">
            <LanguageSwitcher current={locale} label={t(locale, "nav.language")} />
            <Link href={`/${locale}`} className="btn-ghost !text-[11px]">{t(locale, "admin.backToSite")}</Link>
            <LogoutButton locale={locale} />
          </div>
        </div>
      </header>
      <div className="mx-auto flex max-w-[1400px] flex-col gap-4 px-4 py-4 lg:flex-row">
        <aside className="lg:w-48 lg:shrink-0">
          <AdminNav locale={locale} items={items} />
          <div className="mt-4 hidden rounded-lg border p-3 text-[10px] subtle lg:block" style={{ borderColor: "var(--line)" }}>
            <p className="font-bold uppercase tracking-wider">{user.name}</p>
            <p className="mt-0.5 break-all">{user.email}</p>
            <p className="mt-1 uppercase text-brand">{user.role}</p>
          </div>
        </aside>
        <main id="main" className="min-w-0 flex-1 pb-10">{children}</main>
      </div>
    </div>
  );
}
