import { guardAdmin } from "@/server/adminGuard";
import { json, parseBody, handleError } from "@/server/http";
import { sourceSchema } from "@/lib/validation";
import { createSource } from "@/server/repo/admin";
import { audit } from "@/server/auth";

export async function POST(request: Request) {
  try {
    const user = await guardAdmin(request);
    const input = await parseBody(request, sourceSchema);
    const id = createSource(input);
    audit({ actor: user, action: "source.create", entity: "source", entityId: id, meta: { name: input.name } });
    return json({ ok: true, id }, 201);
  } catch (err) {
    return handleError(err);
  }
}
