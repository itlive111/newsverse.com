import type { Role, SessionUser } from "@/server/auth";
import { isSameOrigin, requireAdmin } from "@/server/auth";
import { HttpError } from "@/server/http";

/**
 * Server-side authorization for every admin mutation. Hiding a link is never
 * the security boundary: the role is re-checked from the database session here.
 * Pass the minimum role the operation requires (moderator / editor / admin).
 */
export async function guardAdmin(request?: Request, minRole: Role = "editor"): Promise<SessionUser> {
  if (request && request.method !== "GET" && !isSameOrigin(request)) {
    throw new HttpError(403, "Cross-origin request rejected");
  }
  return requireAdmin(minRole);
}

export function guardOrigin(request: Request): void {
  if (request.method !== "GET" && !isSameOrigin(request)) {
    throw new HttpError(403, "Cross-origin request rejected");
  }
}
