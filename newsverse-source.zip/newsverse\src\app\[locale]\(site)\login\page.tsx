import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { resolveLocale, t, type Locale } from "@/i18n";
import { getCurrentUser } from "@/server/auth";
import { LoginForm } from "@/components/auth-forms";
import { BrandLogo } from "@/components/brand-logo";

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const locale = resolveLocale((await params).locale);
  return { title: t(locale, "auth.loginTitle"), robots: { index: false } };
}

export default async function LoginPage({
  params,
  searchParams,
}: {
  params: Promise<{ locale: string }>;
  searchParams: Promise<{ next?: string }>;
}) {
  const locale = resolveLocale((await params).locale) as Locale;
  const user = await getCurrentUser();
  if (user) redirect(`/${locale}/account`);
  const next = (await searchParams).next;
  const safeNext = next && next.startsWith("/") ? next : undefined;

  return (
    <div className="container-nv grid max-w-4xl gap-8 py-12 md:grid-cols-2 md:items-center">
      <div>
        <p className="kicker">NewsVerse</p>
        <h1 className="mt-2 font-display text-3xl font-extrabold leading-tight">{t(locale, "auth.loginTitle")}</h1>
        <p className="mt-3 text-sm leading-relaxed subtle">{t(locale, "brand.tagline")}</p>
        <div className="mt-6 hidden md:block">
          <BrandLogo size="lg" />
        </div>
      </div>
      <div className="card p-6">
        <LoginForm locale={locale} next={safeNext} />
        <p className="mt-4 text-center text-xs subtle">
          <Link href={`/${locale}`} className="hover:text-brand">← {t(locale, "nav.home")}</Link>
        </p>
      </div>
    </div>
  );
}
