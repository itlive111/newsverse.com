import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { resolveLocale, t, type Locale } from "@/i18n";
import { getCurrentUser } from "@/server/auth";
import { listBookmarks } from "@/server/repo/content";
import { ArticleCard } from "@/components/article-card";
import { EmptyState, SectionHeader } from "@/components/layout-parts";
import { IconBookmark } from "@/components/icons";

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const locale = resolveLocale((await params).locale);
  return { title: t(locale, "bookmarks.title"), robots: { index: false } };
}

export default async function SavedPage({ params }: { params: Promise<{ locale: string }> }) {
  const locale = resolveLocale((await params).locale) as Locale;
  const user = await getCurrentUser();
  if (!user) redirect(`/${locale}/login?next=${encodeURIComponent(`/${locale}/saved`)}`);
  const bookmarks = listBookmarks(user.id, locale);

  return (
    <div className="container-nv py-8">
      <SectionHeader title={t(locale, "bookmarks.title")} hint={`${bookmarks.length}`} />
      {bookmarks.length === 0 ? (
        <EmptyState
          title={t(locale, "bookmarks.empty")}
          body={t(locale, "state.emptyBody")}
          actionHref={`/${locale}/latest`}
          actionLabel={t(locale, "home.latest")}
          icon={<IconBookmark size={22} />}
        />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {bookmarks.map((article) => (
            <ArticleCard key={article.id} article={article} locale={locale} />
          ))}
        </div>
      )}
    </div>
  );
}
