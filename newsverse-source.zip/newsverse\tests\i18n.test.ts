import { describe, expect, test } from "vitest";
import { formatDate, formatNumber, locales, resolveLocale, strings, t } from "@/i18n";

describe("translation catalogue", () => {
  test("every key exists in all three languages", () => {
    for (const [key, value] of Object.entries(strings)) {
      for (const locale of locales) {
        expect(value[locale], `${key} missing ${locale}`).toBeTruthy();
      }
    }
  });

  test("no key is left in English for Uzbek/Russian by accident", () => {
    const untranslated = Object.entries(strings).filter(([, value]) => {
      const v = value as Record<string, string>;
      return v.uz === v.en && v.ru === v.en && v.en.split(" ").length > 2;
    });
    // Short identical strings ("RSS", "Email") are expected; report the rest.
    expect(untranslated.map(([key]) => key)).toEqual([]);
  });

  test("falls back to the default locale for unknown input", () => {
    expect(resolveLocale("de")).toBe("uz");
    expect(resolveLocale("ru")).toBe("ru");
    expect(t("en", "nav.home")).toBe("Home");
  });
});

describe("formatting", () => {
  test("formats numbers per locale", () => {
    expect(formatNumber(1234567, "en")).not.toBe(formatNumber(1234567, "ru"));
  });

  test("formats dates without throwing", () => {
    for (const locale of locales) {
      expect(formatDate("2026-10-30T10:00:00.000Z", locale)).toMatch(/2026/);
    }
  });
});
