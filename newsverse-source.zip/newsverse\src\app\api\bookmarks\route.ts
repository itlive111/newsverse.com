import { requireUser } from "@/server/auth";
import { guardOrigin } from "@/server/adminGuard";
import { json, parseBody, handleError } from "@/server/http";
import { bookmarkSchema } from "@/lib/validation";
import { toggleBookmark } from "@/server/repo/content";

export async function POST(request: Request) {
  try {
    guardOrigin(request);
    const user = await requireUser();
    const input = await parseBody(request, bookmarkSchema);
    const saved = toggleBookmark(user.id, input.articleId, input.folder || "default");
    return json({ ok: true, saved });
  } catch (err) {
    return handleError(err);
  }
}
