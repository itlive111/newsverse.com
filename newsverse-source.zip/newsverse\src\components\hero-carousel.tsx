"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import type { ArticleCard } from "@/server/repo/content";
import { relativeTime, t, type Locale } from "@/i18n";
import { articlePath } from "@/lib/ui";
import { IconChevronLeft, IconChevronRight, IconClock } from "@/components/icons";

export function HeroCarousel({ articles, locale }: { articles: ArticleCard[]; locale: Locale }) {
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const reduceMotion = useRef(false);

  useEffect(() => {
    reduceMotion.current = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  }, []);

  const next = useCallback(() => setIndex((i) => (i + 1) % Math.max(articles.length, 1)), [articles.length]);
  const prev = useCallback(() => setIndex((i) => (i - 1 + articles.length) % Math.max(articles.length, 1)), [articles.length]);

  useEffect(() => {
    if (articles.length < 2 || paused || reduceMotion.current) return;
    const timer = setInterval(next, 7000);
    return () => clearInterval(timer);
  }, [articles.length, next, paused]);

  if (!articles.length) return null;
  const active = articles[index];

  return (
    <section
      aria-roledescription="carousel"
      aria-label={t(locale, "home.featured")}
      className="relative"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      onFocusCapture={() => setPaused(true)}
      onBlurCapture={() => setPaused(false)}
      onKeyDown={(e) => {
        if (e.key === "ArrowRight") next();
        if (e.key === "ArrowLeft") prev();
      }}
      tabIndex={0}
    >
      <div className="relative overflow-hidden rounded-2xl border" style={{ borderColor: "var(--line)" }}>
        <Link href={articlePath(locale, active.slug)} className="group block">
          <div className="relative aspect-[16/10] w-full sm:aspect-[16/9]">
            {active.image_url ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={active.image_url}
                alt=""
                className="h-full w-full object-cover transition duration-700 group-hover:scale-[1.02]"
                referrerPolicy="no-referrer"
                fetchPriority="high"
              />
            ) : (
              <div
                className="h-full w-full"
                style={{
                  background: `radial-gradient(120% 120% at 15% 5%, ${active.category_color ?? "#FF1538"}66, #09090d 60%)`,
                }}
              />
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-[#09090d] via-[#09090d]/50 to-transparent" />
            <div className="absolute inset-x-0 bottom-0 p-5 sm:p-8">
              <div className="flex flex-wrap items-center gap-2">
                {active.is_breaking && (
                  <span className="badge-breaking">
                    <span className="h-1.5 w-1.5 animate-pulseDot rounded-full bg-white" />
                    {t(locale, "home.breaking")}
                  </span>
                )}
                {active.is_demo && <span className="chip !border-white/20 !text-white/70">{t(locale, "common.demo")}</span>}
                <span className="kicker">{active.category_name}</span>
              </div>
              <h1 className="mt-2 max-w-3xl font-display text-[26px] font-extrabold leading-[1.1] text-white sm:text-4xl lg:text-[44px]">
                {active.title}
              </h1>
              <p className="mt-2.5 hidden max-w-2xl text-sm leading-relaxed text-white/75 sm:line-clamp-2">
                {active.summary}
              </p>
              <div className="mt-3 flex flex-wrap items-center gap-2 text-[11px] text-white/60">
                {active.source_name && <span className="font-semibold text-white/85">{active.source_name}</span>}
                <span aria-hidden>·</span>
                <time dateTime={active.published_at}>{relativeTime(active.published_at, locale)}</time>
                <span aria-hidden>·</span>
                <span className="inline-flex items-center gap-1">
                  <IconClock size={12} />
                  {active.reading_minutes} {t(locale, "common.minRead")}
                </span>
              </div>
            </div>
          </div>
        </Link>

        {articles.length > 1 && (
          <>
            <div className="absolute right-3 top-3 flex gap-1.5">
              <button
                type="button"
                onClick={prev}
                aria-label={t(locale, "common.prev")}
                className="flex h-8 w-8 items-center justify-center rounded-full bg-black/50 text-white backdrop-blur transition hover:bg-brand"
              >
                <IconChevronLeft size={16} />
              </button>
              <button
                type="button"
                onClick={next}
                aria-label={t(locale, "common.next")}
                className="flex h-8 w-8 items-center justify-center rounded-full bg-black/50 text-white backdrop-blur transition hover:bg-brand"
              >
                <IconChevronRight size={16} />
              </button>
            </div>
            <div className="absolute bottom-3 right-4 flex gap-1.5">
              {articles.map((a, i) => (
                <button
                  key={a.id}
                  type="button"
                  onClick={() => setIndex(i)}
                  aria-label={`${i + 1} / ${articles.length}`}
                  aria-current={i === index}
                  className={`h-1.5 rounded-full transition-all ${i === index ? "w-6 bg-brand" : "w-2.5 bg-white/40 hover:bg-white/70"}`}
                />
              ))}
            </div>
          </>
        )}
      </div>
    </section>
  );
}
