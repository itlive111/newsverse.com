import Link from "next/link";
import { notFound } from "next/navigation";
import { formatDate, isLocale, locales, t } from "@/i18n";
import { getCurrentUser, isAdmin } from "@/server/auth";
import { getAdminArticle } from "@/server/repo/admin";
import { paragraphs } from "@/lib/ui";

export const dynamic = "force-dynamic";

/** Draft preview. Admin-only, never indexed, never cached. */
export default async function PreviewArticle({
  params,
}: {
  params: Promise<{ locale: string; id: string }>;
}) {
  const { locale: raw, id } = await params;
  if (!isLocale(raw)) notFound();
  const locale = raw;
  const user = await getCurrentUser();
  if (!isAdmin(user)) notFound();
  const data = getAdminArticle(id);
  if (!data) notFound();
  const { article, translations } = data;
  const tr = translations.find((x: Record<string, string>) => x.locale === locale) ?? translations[0];
  const original = translations.find((x: Record<string, string>) => x.locale === article.original_locale);
  const view = tr ?? original;
  const isFallback = view?.locale !== locale;

  return (
    <div className="space-y-3">
      <div className="rounded-lg border border-amber-500/40 bg-amber-500/5 px-3 py-2 text-[11px] text-amber-200">
        {t(locale, "admin.preview")} · {t(locale, "admin.status")}: {article.status} ·{" "}
        <Link href={`/${locale}/admin/articles/${id}`} className="underline">{t(locale, "common.edit")}</Link>
      </div>

      <article className="card mx-auto max-w-3xl p-6">
        <p className="text-[11px] font-bold uppercase tracking-wider text-brand">
          {article.category_slug ?? "story"} {isFallback && <span className="ml-2 text-amber-300">({view?.locale?.toUpperCase()})</span>}
        </p>
        <h1 className="mt-2 font-display text-3xl font-black leading-tight">{view?.title || "—"}</h1>
        {view?.subtitle && <p className="mt-2 text-lg subtle">{view.subtitle}</p>}
        <p className="mt-3 text-[11px] subtle">
          {article.source_name ?? "NewsVerse"} · {article.published_at ? formatDate(article.published_at, locale) : t(locale, "common.unverifiedTranslation")}
        </p>
        {article.image_url && (
          <div className="mt-4">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={article.image_url} alt={article.image_credit ?? view?.title ?? ""} className="w-full rounded-xl object-cover" />
            {article.image_credit && <p className="mt-1 text-[10px] subtle">{article.image_credit}</p>}
          </div>
        )}
        <p className="mt-4 border-l-2 border-brand pl-3 text-sm font-medium">{view?.summary}</p>
        <div className="prose-article mt-4 space-y-3 text-sm leading-relaxed">
          {paragraphs(view?.content ?? "").map((p: string, i: number) => <p key={i}>{p}</p>)}
        </div>
        <p className="mt-6 border-t pt-3 text-[11px] subtle" style={{ borderColor: "var(--line)" }}>
          {t(locale, "article.aiNotice")} · {locales.map((l) => `${l.toUpperCase()}: ${translations.some((x: Record<string, string>) => x.locale === l) ? "✓" : "—"}`).join("  ")}
        </p>
      </article>
    </div>
  );
}
