import crypto from "node:crypto";
import { get, run, nowIso } from "@/server/db";
import { ensureBootstrapped } from "@/server/db/bootstrap";
import { createSession, hashPassword, hashIp, rateLimit } from "@/server/auth";
import { json, fail, parseBody, handleError } from "@/server/http";
import { registerSchema } from "@/lib/validation";
import { audit } from "@/server/auth";
import { clientIpFromHeaders } from "@/server/auth";
import { issueToken, logVerificationLink, verificationLink } from "@/server/lib/verification";

export async function POST(request: Request) {
  try {
    ensureBootstrapped();
    const ip = clientIpFromHeaders(request.headers) ?? "unknown";
    if (!rateLimit(`register:${ip}`, 8, 60 * 60 * 1000)) {
      return fail("Too many attempts. Please try again later.", 429);
    }
    const input = await parseBody(request, registerSchema);

    if (get("SELECT id FROM users WHERE email = ?", input.email)) return fail("email_taken", 409);
    if (get("SELECT id FROM users WHERE username = ? COLLATE NOCASE", input.username)) {
      return fail("username_taken", 409);
    }

    const id = crypto.randomUUID();
    const now = nowIso();
    run(
      `INSERT INTO users (id, email, username, password_hash, name, role, locale, interests, notification_prefs, email_verified, status, created_at, updated_at)
       VALUES (?,?,?,?,?, 'reader', ?, '[]', ?, 0, 'active', ?, ?)`,
      id,
      input.email,
      input.username,
      hashPassword(input.password),
      input.name,
      input.locale,
      JSON.stringify({ email: true, breaking: false, comments: true }),
      now,
      now,
    );

    const token = issueToken(id, "verify");
    logVerificationLink(input.email, verificationLink(token));

    await createSession(id);
    audit({ actor: { id, email: input.email }, action: "auth.register", entity: "user", entityId: id, ipHash: hashIp(ip) });
    return json({ ok: true, redirect: `/${input.locale}/account`, verificationSent: true });
  } catch (err) {
    return handleError(err);
  }
}
