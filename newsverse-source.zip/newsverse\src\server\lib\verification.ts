import crypto from "node:crypto";
import { run, nowIso } from "@/server/db";
import { siteUrl } from "@/lib/ui";

/**
 * Issues a single-use, expiring token for e-mail verification or an e-mail
 * change. Only the SHA-256 hash is stored, so a database leak cannot be used
 * to take over accounts.
 *
 * No mail provider is configured in this deployment, so the link is written to
 * the server log (the same pattern as password reset). Wire a provider in
 * `verificationLinkFor` to actually deliver it.
 */
export function issueToken(
  userId: string,
  kind: "verify" | "email_change",
  meta: Record<string, unknown> | null = null,
  ttlMs = 24 * 60 * 60 * 1000,
): string {
  const token = crypto.randomBytes(32).toString("base64url");
  const hash = crypto.createHash("sha256").update(token).digest("hex");
  run(
    "INSERT INTO auth_tokens (id, user_id, kind, token_hash, expires_at, meta, created_at) VALUES (?,?,?,?,?,?,?)",
    crypto.randomUUID(),
    userId,
    kind,
    hash,
    new Date(Date.now() + ttlMs).toISOString(),
    meta ? JSON.stringify(meta) : null,
    nowIso(),
  );
  return token;
}

export function verificationLink(token: string): string {
  return siteUrl(`/api/auth/verify?token=${encodeURIComponent(token)}`);
}

/** Logs the link until a transactional e-mail provider is configured. */
export function logVerificationLink(email: string, link: string): void {
  console.log(`[newsverse] verification link for ${email}: ${link}`);
}
