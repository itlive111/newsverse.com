"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { t, type Locale } from "@/i18n";

export type SettingField = {
  key: string;
  label: string;
  type?: "text" | "number" | "textarea" | "checkbox" | "select";
  options?: { value: string; label: string }[];
  hint?: string;
  placeholder?: string;
};

export function SettingsForm({
  locale,
  fields,
  initial,
}: {
  locale: Locale;
  fields: SettingField[];
  initial: Record<string, string>;
}) {
  const [values, setValues] = useState<Record<string, string>>(() => {
    const base: Record<string, string> = {};
    for (const field of fields) base[field.key] = initial[field.key] ?? (field.type === "checkbox" ? "false" : "");
    return base;
  });
  const [state, setState] = useState<"idle" | "busy" | "ok" | "error">("idle");
  const [message, setMessage] = useState("");
  const router = useRouter();

  async function save() {
    setState("busy");
    setMessage("");
    const res = await fetch("/api/admin/settings", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(values),
    }).catch(() => null);
    if (!res?.ok) {
      const data = (await res?.json().catch(() => ({}))) as { error?: string };
      setMessage(data?.error ?? "error");
      setState("error");
      return;
    }
    setState("ok");
    setMessage(t(locale, "admin.saved"));
    router.refresh();
  }

  return (
    <div className="space-y-3">
      <div className="grid gap-3 sm:grid-cols-2">
        {fields.map((field) => {
          const value = values[field.key] ?? "";
          return (
            <div key={field.key} className={field.type === "textarea" ? "sm:col-span-2" : ""}>
              <label className="label" htmlFor={`set-${field.key}`}>{field.label}</label>
              {field.type === "checkbox" ? (
                <label className="flex items-center gap-2 text-xs">
                  <input
                    id={`set-${field.key}`}
                    type="checkbox"
                    checked={value === "true"}
                    onChange={(e) => setValues({ ...values, [field.key]: String(e.target.checked) })}
                  />
                  {field.hint ?? field.label}
                </label>
              ) : field.type === "select" ? (
                <select id={`set-${field.key}`} className="input !py-1.5 !text-xs" value={value} onChange={(e) => setValues({ ...values, [field.key]: e.target.value })}>
                  {(field.options ?? []).map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                </select>
              ) : field.type === "textarea" ? (
                <textarea id={`set-${field.key}`} rows={3} className="input !py-1.5 !text-xs" value={value} placeholder={field.placeholder} onChange={(e) => setValues({ ...values, [field.key]: e.target.value })} />
              ) : (
                <input
                  id={`set-${field.key}`}
                  type={field.type === "number" ? "number" : "text"}
                  className="input !py-1.5 !text-xs"
                  value={value}
                  placeholder={field.placeholder}
                  onChange={(e) => setValues({ ...values, [field.key]: e.target.value })}
                />
              )}
              {field.hint && field.type !== "checkbox" && <p className="mt-0.5 text-[10px] subtle">{field.hint}</p>}
            </div>
          );
        })}
      </div>
      <div className="flex items-center gap-3">
        <button type="button" onClick={save} disabled={state === "busy"} className="btn-primary !py-1.5 !text-xs">
          {state === "busy" ? t(locale, "common.loading") : t(locale, "admin.saveSettings")}
        </button>
        {message && <span className={`text-[11px] ${state === "error" ? "text-brand" : "text-emerald-400"}`}>{message}</span>}
      </div>
    </div>
  );
}
