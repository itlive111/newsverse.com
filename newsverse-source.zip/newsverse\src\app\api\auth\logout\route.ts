import { destroySession, getCurrentUser, audit } from "@/server/auth";
import { json, handleError } from "@/server/http";

export async function POST() {
  try {
    const user = await getCurrentUser();
    await destroySession();
    if (user) audit({ actor: { id: user.id, email: user.email }, action: "auth.logout", entity: "user", entityId: user.id });
    return json({ ok: true });
  } catch (err) {
    return handleError(err);
  }
}
