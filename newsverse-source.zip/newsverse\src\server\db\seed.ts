import crypto from "node:crypto";
import { get, run, tx, nowIso } from "@/server/db";
import { recordingTimeMinutes } from "@/server/lib/text";

type Tri = { uz: string; en: string; ru: string };

export const CATEGORY_SEED: {
  slug: string;
  icon: string;
  color: string;
  name: Tri;
}[] = [
  { slug: "uzbekistan", icon: "flag", color: "#1FB6A8", name: { uz: "O‘zbekiston", en: "Uzbekistan", ru: "Узбекистан" } },
  { slug: "world", icon: "globe", color: "#4A7CFF", name: { uz: "Dunyo", en: "World", ru: "Мир" } },
  { slug: "politics", icon: "landmark", color: "#B08CFF", name: { uz: "Siyosat", en: "Politics", ru: "Политика" } },
  { slug: "economy", icon: "chart", color: "#2FBF71", name: { uz: "Iqtisodiyot", en: "Economy", ru: "Экономика" } },
  { slug: "business", icon: "rocket", color: "#FFB020", name: { uz: "Biznes va startaplar", en: "Business & startups", ru: "Бизнес и стартапы" } },
  { slug: "technology", icon: "cpu", color: "#3FB6FF", name: { uz: "Texnologiya", en: "Technology", ru: "Технологии" } },
  { slug: "ai", icon: "brain", color: "#FF6B9A", name: { uz: "Sun’iy intellekt", en: "Artificial intelligence", ru: "Искусственный интеллект" } },
  { slug: "science", icon: "atom", color: "#8C9EFF", name: { uz: "Fan", en: "Science", ru: "Наука" } },
  { slug: "space", icon: "planet", color: "#C77DFF", name: { uz: "Koinot va astronomiya", en: "Space & astronomy", ru: "Космос и астрономия" } },
  { slug: "sports", icon: "trophy", color: "#FF8A3D", name: { uz: "Sport", en: "Sports", ru: "Спорт" } },
  { slug: "football", icon: "ball", color: "#37D67A", name: { uz: "Futbol", en: "Football", ru: "Футбол" } },
  { slug: "gaming", icon: "gamepad", color: "#FF4FA3", name: { uz: "Gaming va esport", en: "Gaming & esports", ru: "Игры и киберспорт" } },
  { slug: "entertainment", icon: "star", color: "#FFD166", name: { uz: "Ko‘ngilochar", en: "Entertainment", ru: "Развлечения" } },
  { slug: "cinema", icon: "film", color: "#F4A261", name: { uz: "Kino va yulduzlar", en: "Cinema & celebrities", ru: "Кино и звёзды" } },
  { slug: "culture", icon: "palette", color: "#E76F51", name: { uz: "Madaniyat", en: "Culture", ru: "Культура" } },
  { slug: "education", icon: "book", color: "#6C8BF4", name: { uz: "Ta’lim", en: "Education", ru: "Образование" } },
  { slug: "health", icon: "heart", color: "#FF5C7C", name: { uz: "Salomatlik va turmush", en: "Health & lifestyle", ru: "Здоровье и образ жизни" } },
  { slug: "travel", icon: "plane", color: "#48CAE4", name: { uz: "Sayohat", en: "Travel", ru: "Путешествия" } },
  { slug: "environment", icon: "leaf", color: "#52B788", name: { uz: "Atrof-muhit", en: "Environment", ru: "Экология" } },
  { slug: "auto", icon: "car", color: "#9AA5B1", name: { uz: "Avtomobil", en: "Automotive", ru: "Авто" } },
  { slug: "security", icon: "shield", color: "#FF6B6B", name: { uz: "Xavfsizlik va kiberxavfsizlik", en: "Security & cybersecurity", ru: "Безопасность и кибербезопасность" } },
  { slug: "breaking", icon: "bolt", color: "#FF1538", name: { uz: "Shoshilinch xabarlar", en: "Breaking news", ru: "Срочные новости" } },
  { slug: "other", icon: "grid", color: "#7C8190", name: { uz: "Boshqa", en: "Other", ru: "Другое" } },
];

/** Real, publicly documented RSS endpoints. Ingestion is what creates articles. */
export const SOURCE_SEED: {
  name: string;
  feed: string;
  site: string;
  category: string;
  locale: string;
  trust: number;
  moderation: string;
  interval: number;
}[] = [
  { name: "BBC News — World", feed: "https://feeds.bbci.co.uk/news/world/rss.xml", site: "https://www.bbc.com/news/world", category: "world", locale: "en", trust: 5, moderation: "auto", interval: 60 },
  { name: "BBC News — Business", feed: "https://feeds.bbci.co.uk/news/business/rss.xml", site: "https://www.bbc.com/news/business", category: "economy", locale: "en", trust: 5, moderation: "auto", interval: 60 },
  { name: "BBC News — Technology", feed: "https://feeds.bbci.co.uk/news/technology/rss.xml", site: "https://www.bbc.com/news/technology", category: "technology", locale: "en", trust: 5, moderation: "auto", interval: 60 },
  { name: "The Guardian — World", feed: "https://www.theguardian.com/world/rss", site: "https://www.theguardian.com/world", category: "world", locale: "en", trust: 5, moderation: "auto", interval: 60 },
  { name: "The Guardian — Technology", feed: "https://www.theguardian.com/uk/technology/rss", site: "https://www.theguardian.com/uk/technology", category: "technology", locale: "en", trust: 5, moderation: "auto", interval: 90 },
  { name: "Al Jazeera — All news", feed: "https://www.aljazeera.com/xml/rss/all.xml", site: "https://www.aljazeera.com/", category: "world", locale: "en", trust: 4, moderation: "hybrid", interval: 60 },
  { name: "TechCrunch", feed: "https://techcrunch.com/feed/", site: "https://techcrunch.com/", category: "business", locale: "en", trust: 4, moderation: "hybrid", interval: 90 },
  { name: "Ars Technica", feed: "https://feeds.arstechnica.com/arstechnica/index", site: "https://arstechnica.com/", category: "technology", locale: "en", trust: 4, moderation: "hybrid", interval: 120 },
  { name: "NASA — Breaking news", feed: "https://www.nasa.gov/rss/dyn/breaking_news.rss", site: "https://www.nasa.gov/", category: "space", locale: "en", trust: 5, moderation: "auto", interval: 60 },
  { name: "Gazeta.uz", feed: "https://www.gazeta.uz/ru/rss/", site: "https://www.gazeta.uz/", category: "uzbekistan", locale: "ru", trust: 4, moderation: "hybrid", interval: 60 },
  { name: "Daryo.uz", feed: "https://daryo.uz/rss", site: "https://daryo.uz/", category: "uzbekistan", locale: "uz", trust: 4, moderation: "hybrid", interval: 60 },
  { name: "UzA — O‘zbekiston", feed: "https://uza.uz/rss", site: "https://uza.uz/", category: "uzbekistan", locale: "uz", trust: 5, moderation: "hybrid", interval: 60 },
  { name: "Meduza", feed: "https://meduza.io/rss/all", site: "https://meduza.io/", category: "world", locale: "ru", trust: 3, moderation: "review", interval: 60 },
  { name: "BBC News — Sport", feed: "https://feeds.bbci.co.uk/sport/rss.xml", site: "https://www.bbc.com/sport", category: "sports", locale: "en", trust: 5, moderation: "auto", interval: 60 },
  { name: "BBC News — Politics", feed: "https://feeds.bbci.co.uk/news/politics/rss.xml", site: "https://www.bbc.com/news/politics", category: "politics", locale: "en", trust: 5, moderation: "hybrid", interval: 60 },
  { name: "BBC News — Science & Environment", feed: "https://feeds.bbci.co.uk/news/science_and_environment/rss.xml", site: "https://www.bbc.com/news/science_and_environment", category: "science", locale: "en", trust: 5, moderation: "hybrid", interval: 60 },
  { name: "BBC News — Health", feed: "https://feeds.bbci.co.uk/news/health/rss.xml", site: "https://www.bbc.com/news/health", category: "health", locale: "en", trust: 5, moderation: "hybrid", interval: 60 },
  { name: "The Guardian — Business", feed: "https://www.theguardian.com/uk/business/rss", site: "https://www.theguardian.com/uk/business", category: "economy", locale: "en", trust: 5, moderation: "hybrid", interval: 60 },
  { name: "The Guardian — Sport", feed: "https://www.theguardian.com/uk/sport/rss", site: "https://www.theguardian.com/uk/sport", category: "sports", locale: "en", trust: 5, moderation: "hybrid", interval: 60 },
  { name: "The Guardian — Science", feed: "https://www.theguardian.com/science/rss", site: "https://www.theguardian.com/science", category: "science", locale: "en", trust: 5, moderation: "hybrid", interval: 60 },
  { name: "The Verge", feed: "https://www.theverge.com/rss/index.xml", site: "https://www.theverge.com/", category: "technology", locale: "en", trust: 4, moderation: "hybrid", interval: 60 },
  { name: "Wired", feed: "https://www.wired.com/feed/rss", site: "https://www.wired.com/", category: "technology", locale: "en", trust: 4, moderation: "hybrid", interval: 60 },
  { name: "Space.com", feed: "https://www.space.com/feeds/all", site: "https://www.space.com/", category: "space", locale: "en", trust: 4, moderation: "hybrid", interval: 60 },
  { name: "ESPN — Top news", feed: "https://www.espn.com/espn/rss/news", site: "https://www.espn.com/", category: "sports", locale: "en", trust: 4, moderation: "hybrid", interval: 60 },
  { name: "Variety", feed: "https://variety.com/feed/", site: "https://variety.com/", category: "entertainment", locale: "en", trust: 4, moderation: "hybrid", interval: 60 },
  { name: "Engadget", feed: "https://www.engadget.com/rss.xml", site: "https://www.engadget.com/", category: "technology", locale: "en", trust: 3, moderation: "hybrid", interval: 60 },
  { name: "UN News", feed: "https://news.un.org/feed/subscribe/en/news/all/rss.xml", site: "https://news.un.org/", category: "world", locale: "en", trust: 5, moderation: "hybrid", interval: 60 },
  { name: "France 24", feed: "https://www.france24.com/en/rss", site: "https://www.france24.com/en/", category: "world", locale: "en", trust: 4, moderation: "hybrid", interval: 60 },
  { name: "Deutsche Welle", feed: "https://rss.dw.com/rdf/rss-en-all", site: "https://www.dw.com/en/", category: "world", locale: "en", trust: 4, moderation: "hybrid", interval: 60 },
  { name: "Euronews", feed: "https://www.euronews.com/rss?level=theme&name=news", site: "https://www.euronews.com/", category: "world", locale: "en", trust: 4, moderation: "hybrid", interval: 60 },
];

export const DEFAULT_SETTINGS: Record<string, string> = {
  site_name: "NewsVerse",
  default_locale: "uz",
  moderation_mode: "hybrid",
  ingest_enabled: "1",
  ingest_interval_minutes: "60",
  ingest_max_items_per_run: "50",
  auto_publish_trust: "4",
  ai_enabled: "1",
  comments_enabled: "1",
  newsletter_enabled: "1",
  ads_enabled: "0",
  payments_enabled: "0",
  notify_on_failure: "1",
  failure_alert_threshold: "3",
  contact_email: "hello@newsverse.example",
  breaking_keywords: "breaking,shoshilinch,срочно,urgent,just in,dead,major,halok,portlash",
  seo_title: "NewsVerse — Dunyodagi eng so‘nggi yangiliklar bir joyda",
  seo_description:
    "O‘zbekiston va dunyo bo‘yicha so‘nggi yangiliklar: siyosat, iqtisod, texnologiya, sport, fan va madaniyat. Manbalar ochiq ko‘rsatiladi.",
  weather_widget: "0",
  markets_widget: "0",
  sports_widget: "0",
  analytics_retention_days: "365",
};

export function seedBase(): { categories: number; sources: number; settings: number } {
  const now = nowIso();
  let categories = 0;
  let sources = 0;
  let settings = 0;
  tx(() => {
    CATEGORY_SEED.forEach((c, index) => {
      const desc: Tri = {
        uz: `${c.name.uz} bo‘yicha so‘nggi yangiliklar va tahlillar.`,
        en: `Latest ${c.name.en.toLowerCase()} news and analysis.`,
        ru: `Последние новости и аналитика: ${c.name.ru.toLowerCase()}.`,
      };
      const existing = get<{ id: string }>("SELECT id FROM categories WHERE slug = ?", c.slug);
      if (existing) {
        run(
          "UPDATE categories SET name_i18n = ?, description_i18n = ?, icon = ?, color = ?, order_index = ?, updated_at = ? WHERE id = ?",
          JSON.stringify(c.name), JSON.stringify(desc), c.icon, c.color, index, now, existing.id,
        );
      } else {
        run(
          `INSERT INTO categories (id, slug, name_i18n, description_i18n, icon, color, order_index, is_active, created_at, updated_at)
           VALUES (?,?,?,?,?,?,?,1,?,?)`,
          crypto.randomUUID(), c.slug, JSON.stringify(c.name), JSON.stringify(desc), c.icon, c.color, index, now, now,
        );
        categories += 1;
      }
    });

    for (const s of SOURCE_SEED) {
      if (get("SELECT id FROM sources WHERE feed_url = ?", s.feed)) continue;
      run(
        `INSERT INTO sources (id, name, type, feed_url, site_url, category_slug, locale, enabled, interval_minutes,
           trust, moderation, consecutive_failures, total_items, created_at, updated_at)
         VALUES (?,?,?,?,?,?,?,1,?,?,?,0,0,?,?)`,
        crypto.randomUUID(), s.name, "rss", s.feed, s.site, s.category, s.locale, s.interval, s.trust, s.moderation, now, now,
      );
      sources += 1;
    }

    for (const [key, value] of Object.entries(DEFAULT_SETTINGS)) {
      if (get("SELECT key FROM settings WHERE key = ?", key)) continue;
      run("INSERT INTO settings (key, value, updated_at) VALUES (?,?,?)", key, value, now);
      settings += 1;
    }
  });
  return { categories, sources, settings };
}

const DEMO_ARTICLES: {
  category: string;
  hoursAgo: number;
  breaking?: boolean;
  title: Tri;
  summary: Tri;
  body: Record<"uz" | "en" | "ru", string[]>;
  tags: string[];
}[] = [
  {
    category: "technology",
    hoursAgo: 1,
    breaking: true,
    title: {
      uz: "Namuna: NewsVerse avtomatik yangilik yig‘ish qanday ishlaydi",
      en: "Demo: how NewsVerse collects news automatically",
      ru: "Демо: как NewsVerse собирает новости автоматически",
    },
    summary: {
      uz: "Bu namuna maqola. Platforma RSS va API manbalarini jadval bo‘yicha tekshiradi, dublikatlarni filtrlaydi va tayyor materialni nashr etadi.",
      en: "This is demonstration content. The platform polls RSS and API sources on a schedule, filters duplicates and publishes the result.",
      ru: "Это демонстрационный материал. Платформа по расписанию опрашивает RSS и API, отсекает дубликаты и публикует результат.",
    },
    body: {
      uz: [
        "Bu matn namuna sifatida yaratilgan va real voqeani tasvirlamaydi. U faqat platforma interfeysi va ish jarayonini ko‘rsatish uchun xizmat qiladi.",
        "Ingestion dvigateli har bir manbani o‘z intervali bo‘yicha tekshiradi. Topilgan maqolalar kanonik havola, sarlavha xeshi va o‘xshashlik bo‘yicha taqqoslanadi.",
        "Administrator panelida har bir ish holati, xatolar va manba salomatligi kuzatiladi. Har bir yangilikda asl nashrga havola va manba nomi saqlanadi.",
      ],
      en: [
        "This text is demonstration content and does not describe a real event. It exists only to exercise the interface and publishing workflow.",
        "The ingestion engine polls each source on its own interval. Incoming items are compared by canonical URL, title hash and token similarity before insertion.",
        "The admin dashboard exposes job state, error detail and source health. Every story keeps its publisher name and a link to the original report.",
      ],
      ru: [
        "Этот текст создан как демонстрационный и не описывает реальное событие. Он нужен только для проверки интерфейса и процесса публикации.",
        "Движок импорта опрашивает каждый источник с собственным интервалом. Материалы сравниваются по каноническому URL, хешу заголовка и схожести слов.",
        "В админке видны статусы задач, ошибки и состояние источников. У каждой новости сохраняются имя издания и ссылка на оригинал.",
      ],
    },
    tags: ["platforma", "ingestion", "demo"],
  },
  {
    category: "ai",
    hoursAgo: 4,
    title: {
      uz: "Namuna: sun’iy intellekt xulosalari qanday belgilanadi",
      en: "Demo: how AI summaries are labelled",
      ru: "Демо: как помечаются AI-резюме",
    },
    summary: {
      uz: "AI yordamida tayyorlangan xulosalar alohida belgi bilan ko‘rsatiladi va tahririyat tasdig‘ini talab qiladi.",
      en: "Summaries produced with AI are visibly labelled and routed through editorial review.",
      ru: "Резюме, созданные с помощью ИИ, заметно помечаются и проходят редакционную проверку.",
    },
    body: {
      uz: [
        "Namuna matn. AI xizmati sozlanmagan bo‘lsa, tizim ekstraktiv xulosa rejimida ishlaydi va buni interfeysda ko‘rsatadi.",
        "Har bir tarjima “mashina tarjimasi” deb belgilanadi. Inson tekshiruvi o‘tkazilmagan tarjima hech qachon tasdiqlangan deb ko‘rsatilmaydi.",
        "Yuqori xavfli mavzular — saylov, sog‘liq, moliya va favqulodda holatlar — qo‘lda ko‘rikdan o‘tadi.",
      ],
      en: [
        "Demonstration text. When no AI provider is configured the system falls back to extractive summarisation and says so in the interface.",
        "Every machine translation is tagged as such. A translation is never presented as human-verified until an editor approves it.",
        "High-risk topics — elections, health, finance and emergencies — are routed to manual review by default.",
      ],
      ru: [
        "Демонстрационный текст. Без настроенного AI-провайдера система использует экстрактивное резюме и сообщает об этом в интерфейсе.",
        "Каждый машинный перевод помечается. Он не считается проверенным человеком, пока редактор его не одобрит.",
        "Темы высокого риска — выборы, здоровье, финансы и ЧС — по умолчанию идут на ручную проверку.",
      ],
    },
    tags: ["ai", "translation", "demo"],
  },
  {
    category: "uzbekistan",
    hoursAgo: 7,
    title: {
      uz: "Namuna: mahalliy va xalqaro yangiliklar bir lentada",
      en: "Demo: local and international news in one feed",
      ru: "Демо: местные и мировые новости в одной ленте",
    },
    summary: {
      uz: "O‘zbekiston bo‘limi mahalliy manbalarni, “Dunyo” bo‘limi xalqaro nashrlarni birlashtiradi.",
      en: "The Uzbekistan section aggregates local outlets while World pulls from international publishers.",
      ru: "Раздел «Узбекистан» собирает местные издания, «Мир» — международные.",
    },
    body: {
      uz: [
        "Namuna matn. Kategoriyalar administrator tomonidan boshqariladi: nomlar uch tilda, tartib va ko‘rinish sozlanadi.",
        "Har bir kategoriya sahifasida filtrlar, SEO metama’lumotlari va ixtiyoriy muqova tasviri mavjud.",
        "Manba tili asl til sifatida saqlanadi; tarjima mavjud bo‘lmasa, foydalanuvchiga asl matn ko‘rsatiladi.",
      ],
      en: [
        "Demonstration text. Categories are managed by administrators with names in three languages, ordering and visibility controls.",
        "Each category page has filters, its own SEO metadata and an optional cover image.",
        "The source language is stored as the original; when a translation is missing the reader sees the original text, clearly marked.",
      ],
      ru: [
        "Демонстрационный текст. Категориями управляют администраторы: названия на трёх языках, порядок и видимость.",
        "У каждой категории есть фильтры, собственные SEO-метаданные и необязательное изображение.",
        "Язык источника сохраняется как оригинал; если перевода нет, читатель видит оригинальный текст с пометкой.",
      ],
    },
    tags: ["uzbekistan", "categories", "demo"],
  },
  {
    category: "security",
    hoursAgo: 11,
    title: {
      uz: "Namuna: xavfsizlik va maxfiylik yondashuvi",
      en: "Demo: the security and privacy approach",
      ru: "Демо: подход к безопасности и приватности",
    },
    summary: {
      uz: "Sessiyalar serverda saqlanadi, parollar scrypt bilan xeshlanadi, har bir administrator amali audit jurnaliga yoziladi.",
      en: "Sessions live server-side, passwords are scrypt-hashed, and every admin action is written to an audit log.",
      ru: "Сессии хранятся на сервере, пароли хешируются scrypt, каждое действие администратора попадает в аудит.",
    },
    body: {
      uz: [
        "Namuna matn. Kirish cookie’lari HttpOnly va SameSite=Lax bo‘lib, serverdagi sessiya yozuvi bilan bog‘lanadi.",
        "Mutatsiya qiluvchi so‘rovlar Origin tekshiruvidan o‘tadi; barcha SQL so‘rovlar bog‘langan parametrlar bilan bajariladi.",
        "Import qilingan matn ishonchsiz deb qaraladi: HTML tozalanadi va faqat oddiy matn ko‘rinishida chiqariladi.",
      ],
      en: [
        "Demonstration text. Session cookies are HttpOnly and SameSite=Lax, bound to a server-side session record.",
        "State-changing requests pass an Origin check; every SQL statement uses bound parameters.",
        "Imported text is treated as untrusted: HTML is stripped and rendered as plain text only.",
      ],
      ru: [
        "Демонстрационный текст. Cookie сессии — HttpOnly и SameSite=Lax, привязаны к серверной записи.",
        "Запросы, меняющие состояние, проходят проверку Origin; все SQL-запросы используют связанные параметры.",
        "Импортированный текст считается недоверенным: HTML удаляется, вывод — только простой текст.",
      ],
    },
    tags: ["security", "privacy", "demo"],
  },
  {
    category: "sports",
    hoursAgo: 18,
    title: {
      uz: "Namuna: sport bo‘limi qanday to‘ldiriladi",
      en: "Demo: how the sport section fills up",
      ru: "Демо: как наполняется раздел спорта",
    },
    summary: {
      uz: "Sport va futbol manbalari alohida sozlanadi; har bir manba uchun ishonch darajasi va moderatsiya tanlanadi.",
      en: "Sport and football feeds are configured independently, each with its own trust level and moderation rule.",
      ru: "Спортивные источники настраиваются отдельно — со своим уровнем доверия и правилом модерации.",
    },
    body: {
      uz: [
        "Namuna matn. Har bir manba uchun interval, kategoriya va til belgilanadi.",
        "Ishonch darajasi yuqori manbalar avtomatik chop etilishi mumkin, qolganlari ko‘rikka tushadi.",
        "Xato bo‘lsa, tizim eksponensial kutish bilan qayta urinadi va administratorga ogohlantirish yuboradi.",
      ],
      en: [
        "Demonstration text. Each source defines its interval, category and language.",
        "High-trust sources can publish automatically; the rest enter the review queue.",
        "On failure the system retries with exponential backoff and raises an administrator alert.",
      ],
      ru: [
        "Демонстрационный текст. Для каждого источника задаются интервал, категория и язык.",
        "Источники с высоким доверием могут публиковаться автоматически, остальные попадают на проверку.",
        "При ошибке система повторяет попытку с экспоненциальной задержкой и уведомляет администратора.",
      ],
    },
    tags: ["sport", "sources", "demo"],
  },
  {
    category: "culture",
    hoursAgo: 26,
    title: {
      uz: "Namuna: uch tilidagi o‘qish tajribasi",
      en: "Demo: a reading experience in three languages",
      ru: "Демо: чтение на трёх языках",
    },
    summary: {
      uz: "Til almashtirgich tanlangan tilni eslab qoladi; sana va raqamlar har bir til uchun to‘g‘ri formatlanadi.",
      en: "The language switcher remembers your choice, and dates and numbers use locale-correct formatting.",
      ru: "Переключатель языка запоминает выбор, а даты и числа форматируются по правилам локали.",
    },
    body: {
      uz: [
        "Namuna matn. O‘quv rejimi, katta-kichik shrift va bosma ko‘rinish barcha maqolalarda mavjud.",
        "Qorong‘i va yorug‘ mavzular tizim sozlamasini hisobga oladi; harakatni kamaytirish rejimi qo‘llab-quvvatlanadi.",
        "Saqlangan maqolalar, o‘qish tarixi va qiziqishlar faqat hisobga kirgan foydalanuvchilar uchun saqlanadi.",
      ],
      en: [
        "Demonstration text. Reader mode, adjustable font size and print layout are available on every article.",
        "Dark and light themes respect the system preference, and reduced-motion settings are honoured.",
        "Bookmarks, reading history and interests are stored only for signed-in accounts.",
      ],
      ru: [
        "Демонстрационный текст. Режим чтения, размер шрифта и печать доступны в каждой статье.",
        "Тёмная и светлая темы учитывают системные настройки, а режим уменьшенной анимации поддерживается.",
        "Закладки, история чтения и интересы хранятся только для авторизованных пользователей.",
      ],
    },
    tags: ["culture", "i18n", "demo"],
  },
];

/** Inserts clearly-labelled demonstration articles (idempotent). */
export function seedDemoArticles(): number {
  const now = Date.now();
  let inserted = 0;
  const demoSource = get<{ id: string }>("SELECT id FROM sources LIMIT 1");
  for (const demo of DEMO_ARTICLES) {
    const existing = get(
      "SELECT a.id FROM articles a JOIN article_translations t ON t.article_id = a.id WHERE t.title = ?",
      demo.title.uz,
    );
    if (existing) continue;
    const category = get<{ id: string }>("SELECT id FROM categories WHERE slug = ?", demo.category);
    const id = crypto.randomUUID();
    const publishedAt = new Date(now - demo.hoursAgo * 3600000).toISOString();
    const iso = nowIso();
    const bodyText = demo.body.uz.join("\n\n");
    tx(() => {
      run(
        `INSERT INTO articles (id, category_id, source_id, status, published_at, original_locale, source_name,
           is_breaking, is_demo, is_ai_assisted, reading_minutes, quality_score, created_at, updated_at)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        id, category?.id ?? null, demoSource?.id ?? null, "published", publishedAt, "uz",
        "NewsVerse Demo Desk", demo.breaking ? 1 : 0, 1, 0, recordingTimeMinutes(bodyText), 60, iso, iso,
      );
      (["uz", "en", "ru"] as const).forEach((locale) => {
        const title = demo.title[locale];
        const slugBase = slugBaseForTitle(title);
        run(
          `INSERT INTO article_translations (id, article_id, locale, slug, title, summary, content, is_machine, is_original, created_at, updated_at)
           VALUES (?,?,?,?,?,?,?,0,?,?,?)`,
          crypto.randomUUID(), id, locale, `${slugBase}-demo-${id.slice(0, 4)}`, title,
          demo.summary[locale], demo.body[locale].join("\n\n"),
          locale === "uz" ? 1 : 0, iso, iso,
        );
      });
      for (const tag of demo.tags) {
        const tagId = get<{ id: string }>("SELECT id FROM tags WHERE slug = ?", tag)?.id ?? addTag(tag);
        run("INSERT OR IGNORE INTO article_tags (article_id, tag_id) VALUES (?,?)", id, tagId);
      }
    });
    inserted += 1;
  }
  return inserted;
}

function slugBaseForTitle(title: string): string {
  return title
    .toLowerCase()
    .replace(/[‘’ʻ`]/g, "")
    .replace(/[^\p{L}\p{N}]+/gu, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 70);
}

function addTag(name: string): string {
  const id = crypto.randomUUID();
  run("INSERT INTO tags (id, slug, name) VALUES (?,?,?)", id, name, name);
  return id;
}

/** Runs at boot: base taxonomy always, demo articles only on a fresh install. */
export function seedIfEmpty(): void {
  seedBase();
  if (process.env.SEED_DEMO === "0") return;
  const hasArticles = get<{ c: number }>("SELECT COUNT(*) AS c FROM articles");
  if (!hasArticles || hasArticles.c === 0) seedDemoArticles();
}
