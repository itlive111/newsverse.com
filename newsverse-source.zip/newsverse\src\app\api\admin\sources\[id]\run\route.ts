import { guardAdmin } from "@/server/adminGuard";
import { json, fail, handleError } from "@/server/http";
import { ingestSource } from "@/server/ingest/pipeline";
import { audit } from "@/server/auth";

type Ctx = { params: Promise<{ id: string }> };

/** Manual collection: runs immediately and returns the real result. */
export async function POST(request: Request, ctx: Ctx) {
  try {
    const user = await guardAdmin(request);
    const { id } = await ctx.params;
    const result = await ingestSource(id);
    audit({ actor: user, action: "source.run", entity: "source", entityId: id, meta: result as unknown as Record<string, unknown> });
    return json({ ok: true, result });
  } catch (err) {
    return fail((err as Error).message, 502);
  }
}
