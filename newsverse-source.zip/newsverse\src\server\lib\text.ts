import crypto from "node:crypto";

const CYRILLIC: Record<string, string> = {
  а: "a", б: "b", в: "v", г: "g", д: "d", е: "e", ё: "yo", ж: "j", з: "z", и: "i",
  й: "y", к: "k", л: "l", м: "m", н: "n", о: "o", п: "p", р: "r", с: "s", т: "t",
  у: "u", ф: "f", х: "x", ц: "ts", ч: "ch", ш: "sh", щ: "sh", ъ: "", ы: "i", ь: "",
  э: "e", ю: "yu", я: "ya", ў: "o", қ: "q", ғ: "g", ҳ: "h",
};

const LATIN_EXTRA: Record<string, string> = {
  á: "a", à: "a", ä: "a", â: "a", å: "a", ã: "a",
  é: "e", è: "e", ë: "e", ê: "e",
  í: "i", ì: "i", ï: "i", î: "i",
  ó: "o", ò: "o", ö: "o", ô: "o", õ: "o",
  ú: "u", ù: "u", ü: "u", û: "u",
  ç: "c", ñ: "n", ş: "s", ğ: "g", ž: "z", š: "s", č: "c", ý: "y",
};

export function slugify(input: string, maxLength = 90): string {
  const lower = input.toLowerCase().trim();
  let out = "";
  for (const ch of lower) {
    if (CYRILLIC[ch] !== undefined) out += CYRILLIC[ch];
    else if (LATIN_EXTRA[ch] !== undefined) out += LATIN_EXTRA[ch];
    else if (/[a-z0-9]/.test(ch)) out += ch;
    else if (ch === "'" || ch === "’" || ch === "ʻ" || ch === "`" || ch === "‘") out += "";
    else out += " ";
  }
  return (
    out
      .replace(/\s+/g, "-")
      .replace(/-+/g, "-")
      .replace(/^-|-$/g, "")
      .slice(0, maxLength)
      .replace(/-$/, "") || "story"
  );
}

export function sha256(value: string): string {
  return crypto.createHash("sha256").update(value).digest("hex");
}

export function randomToken(bytes = 32): string {
  return crypto.randomBytes(bytes).toString("base64url");
}

/** Removes HTML tags/entities from feed content. Feed text is untrusted input. */
export { stripHtml } from "@/lib/html";

/** Normalizes a URL for dedupe: drops tracking params, fragments and trailing slashes. */
export function canonicalizeUrl(raw: string): string {
  try {
    const url = new URL(raw.trim());
    const drop = [
      "utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content",
      "fbclid", "gclid", "ref", "ref_src", "at_medium", "at_campaign", "output",
    ];
    for (const key of drop) url.searchParams.delete(key);
    url.hash = "";
    url.hostname = url.hostname.replace(/^www\./, "").toLowerCase();
    url.protocol = url.protocol.toLowerCase();
    if (url.pathname !== "/" && url.pathname.endsWith("/")) url.pathname = url.pathname.slice(0, -1);
    return url.toString();
  } catch {
    return raw.trim();
  }
}

export function recordingTimeMinutes(text: string): number {
  const words = text.trim().split(/\s+/).filter(Boolean).length;
  return Math.max(1, Math.round(words / 200));
}

export function truncate(text: string, max = 240): string {
  const clean = text.replace(/\s+/g, " ").trim();
  if (clean.length <= max) return clean;
  const cut = clean.slice(0, max);
  const lastSpace = cut.lastIndexOf(" ");
  return `${(lastSpace > max * 0.6 ? cut.slice(0, lastSpace) : cut).replace(/[,;:.-]$/, "")}…`;
}

export function escapeXml(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

export function uniqueSlug(base: string, exists: (slug: string) => boolean): string {
  let slug = base;
  let i = 2;
  while (exists(slug)) {
    slug = `${base}-${i}`;
    i += 1;
    if (i > 500) return `${base}-${crypto.randomBytes(3).toString("hex")}`;
  }
  return slug;
}
